# Phase 1 — KitNET Replication on Kitsune Dataset

## What this is

Faithful replication of the original KitNET/Kitsune anomaly detector (Mirsky et al., NDSS 2018) on the 9-scenario Kitsune dataset. Features are pre-extracted 115-dimensional Kitsune AfterImage vectors provided as paired `*_dataset.csv` / `*_labels.csv` files.

### Attack scenarios

| Scenario | Attack type |
|----------|-------------|
| ARP MitM | ARP poisoning / Man-in-the-middle |
| Active Wiretap | Active tap on network link |
| Fuzzing | Protocol fuzzing |
| Mirai Botnet | IoT botnet C&C + scanning |
| OS Scan | Operating system fingerprinting |
| SSDP Flood | UDP amplification DDoS |
| SSL Renegotiation | TLS renegotiation attack |
| SYN DoS | SYN flood denial of service |
| Video Injection | RTSP stream injection |

---

## Prerequisites

### 1. Install dependencies
```bash
pip install numpy pandas
# Optional (for plots):
pip install matplotlib
```

### 2. Prepare dataset

Download the Kitsune dataset and place each scenario's files under:
```
dataset/
    ARP_MitM_20pct/
        ARP_MitM_dataset.csv
        ARP_MitM_labels.csv
    Active_Wiretap_20pct/
        Active_Wiretap_dataset.csv
        Active_Wiretap_labels.csv
    ...
```

Each `*_dataset.csv` contains 115 numeric feature columns. Each `*_labels.csv` contains a single binary label column (0 = benign, 1 = attack).

---

## How to run

Always run from the **project root** directory.

### Run all 9 scenarios
```bash
python phase1/run_replication.py
```

### Run a single scenario
```bash
python phase1/run_replication.py --scenario ARP_MitM_20pct
```

### Custom dataset location
```bash
python phase1/run_replication.py \
    --data_dir   dataset \
    --output_dir results
```

### All options
| Flag | Default | Description |
|------|---------|-------------|
| `--data_dir` | `dataset` | Root directory containing scenario sub-folders |
| `--output_dir` | `results` | Where results are saved |
| `--scenario` | all | Run only the named scenario |
| `--m` | `10` | KitNET max cluster size |
| `--beta` | `0.75` | Feature-mapper decay ratio |
| `--lr` | `0.1` | Autoencoder learning rate |
| `--fm_grace` | `5000` | Feature-mapper warmup rows |
| `--ad_grace` | `20000` | Anomaly-detector warmup rows |
| `--skip_plots` | off | Pass to skip matplotlib output |

---

## Output files

```
results/
    ARP_MitM_20pct/
        scores.csv       — (index, score)
        labels.npy       — binary labels array
        scores.npy       — anomaly score array
        metrics.json     — AUC, AUPRC, F1, EER, runtime
        roc_curve.csv    — fpr, tpr
        pr_curve.csv     — precision, recall
    Active_Wiretap_20pct/
        ...
    ...
    summary_metrics.csv  — all scenarios in one table
    summary_metrics.json
    _plots/
        combined_roc.png
        combined_pr.png
        summary_auc.png
        ...
```

---

## Implementation notes

- `dataset_reader.py` — streams (feature_vector, label) pairs from paired CSVs; expects exactly 115 features
- `run_replication.py` — orchestrates FM warmup → AD warmup → inference for each scenario
- Shared KitNET core lives in `core/` (unchanged from original)
- If scipy is unavailable, `core/_scipy_shim.py` provides pure-numpy fallback clustering
