# Phase 2 — Web Attack Detection Extension

## Overview

Phase 2 extends KitNET to detect web-layer attacks (Brute Force-Web, Brute Force-XSS, SQL Injection) from the CIC-IDS-2018 dataset. Three experiments are run on the same traffic — **Thursday 22-Feb-2018** and **Friday 23-Feb-2018** — to compare feature strategies:

| Folder | Experiment | Feature source | Dims |
|--------|------------|----------------|------|
| `traditional/` | A — Baseline | Kitsune network AfterImage | 115 |
| `http_only/` | B — Novel | HTTP application AfterImage | 85 |
| `hybrid/` | C — Combined | Network + HTTP concatenated | 200 |
| `csv_baseline/` | CSV quick-run | CICFlowMeter per-flow CSV | 78 |
| `comparison/` | Cross-experiment report | Reads results from A/B/C | — |

---

## Directory layout

```
phase2/
├── README.md                  ← you are here
├── reader.py                  ← CICFlowMeter CSV reader (shared)
├── pipeline.py                ← shared KitNET pipeline (used by A/B/C)
│
├── http/                      ← HTTP feature extraction library
│   ├── http_feature_engine.py ← 85-dim AfterImage feature computation
│   ├── http_transaction.py    ← HTTPTransaction dataclass
│   ├── http_label_mapper.py   ← dual-source labeling (PCAP + CSV)
│   ├── pcap_dual_extractor.py ← PCAP → (kitsune, http, hybrid) CSVs
│   ├── pcap_http_extractor.py ← dpkt fallback HTTP extractor
│   └── pcap_http_extractor.sh ← tshark one-liner
│
├── traditional/               ← Experiment A runner + README
├── http_only/                 ← Experiment B runner + README
├── hybrid/                    ← Experiment C runner + README
├── csv_baseline/              ← CSV quick-run + README
└── comparison/                ← Comparison report + README
```

---

## Data pipeline

### With raw PCAPs (recommended for experiments A/B/C)

```
PCAPs (103 GB)
    │
    ▼ phase2/http/pcap_dual_extractor.py
    │
    ├─ *_kitsune_115.csv  ──► phase2/traditional/run_traditional.py
    ├─ *_http_85.csv      ──► phase2/http_only/run_http.py
    └─ *_hybrid_200.csv   ──► phase2/hybrid/run_hybrid.py
                                        │
                                        ▼
                          phase2/comparison/run_comparison.py
```

### Without PCAPs (CSV baseline only)

```
CICFlowMeter CSVs (already in dataset/)
    │
    ▼ phase2/csv_baseline/run_csv_baseline.py
    │
    └─ results_phase2/csv_baseline/
```

---

## Shared modules

### `phase2/reader.py`
CICFlowMeter CSV reader. Drops Timestamp and Label columns, maps labels to binary, computes warmup parameters, and streams `(row_index, day, feature_vector, binary_label, attack_type)` tuples.

### `phase2/pipeline.py`
Shared KitNET experiment runner. Implements the three-phase FM warmup → AD warmup → inference loop, per-day and combined evaluation, and output saving. Used by experiments A, B, and C through the `run_experiment()` function.

### `phase2/http/` package
HTTP feature extraction. `pcap_dual_extractor.py` reads raw PCAPs (via tshark or dpkt), assigns labels using `http_label_mapper.py`, computes Kitsune network features using `core/feature_extractor.py` and HTTP AfterImage features using `http_feature_engine.py`, and writes the three CSV variants.

---

## Running the full Phase 2 pipeline

```bash
# Step 1 — extract features (requires PCAPs)
python phase2/http/pcap_dual_extractor.py \
    --pcap_dir /path/to/pcaps --day Thursday-22-02-2018 \
    --output_dir dataset/cse-cic-ids2018/http_transactions
# repeat for Friday

# Step 2 — run the three experiments
python phase2/traditional/run_traditional.py
python phase2/http_only/run_http.py
python phase2/hybrid/run_hybrid.py

# Step 3 — compare results
python phase2/comparison/run_comparison.py
```

See each sub-folder's README for full flag reference and output details.

---

## Warmup policy

Warmup uses only the benign prefix of each day's stream (rows before the first attack):

```
fm_grace = min(5000,  15% of benign_prefix_len)
ad_grace = min(20000, 60% of benign_prefix_len)
```

This ensures no attack traffic contaminates KitNET's training distribution.
