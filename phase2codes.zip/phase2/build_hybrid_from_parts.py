"""
from __future__ import annotations

import argparse
import logging
import sys
from pathlib import Path

import pandas as pd

logging.basicConfig(
    format="%(asctime)s | %(levelname)-7s | %(message)s",
    datefmt="%H:%M:%S",
    level=logging.INFO,
)
_log = logging.getLogger(__name__)

META_COLS = ["timestamp", "binary_label", "attack_type", "label_source", "day"]
CHUNKSIZE = 100_000


def build_hybrid(combined_dir: Path, day: str) -> None:
    kit_path    = combined_dir / f"{day}_kitsune_115.csv"
    http_path   = combined_dir / f"{day}_http_85.csv"
    hybrid_path = combined_dir / f"{day}_hybrid_200.csv"

    if not kit_path.exists():
        _log.error("Missing: %s", kit_path)
        sys.exit(1)
    if not http_path.exists():
        _log.error("Missing: %s", http_path)
        sys.exit(1)

    _log.info("Building %s …", hybrid_path.name)

    # Figure out column names
    kit_header  = pd.read_csv(kit_path,  nrows=0)
    http_header = pd.read_csv(http_path, nrows=0)

    kit_feat_cols  = [c for c in kit_header.columns  if c not in META_COLS]
    http_feat_cols = [c for c in http_header.columns if c not in META_COLS]
    _log.info("  kitsune features: %d", len(kit_feat_cols))
    _log.info("  http features:    %d", len(http_feat_cols))

    total_rows = 0
    first_chunk = True

    kit_reader  = pd.read_csv(kit_path,  chunksize=CHUNKSIZE, low_memory=False)
    http_reader = pd.read_csv(http_path, chunksize=CHUNKSIZE, low_memory=False)

    with open(hybrid_path, "w", newline="") as out_f:
        for chunk_k, chunk_h in zip(kit_reader, http_reader):
            # Sanity check
            if not (chunk_k["timestamp"].values == chunk_h["timestamp"].values).all():
                _log.error("Timestamp mismatch at row ~%d!", total_rows)
                sys.exit(1)

            hybrid_chunk = pd.concat(
                [
                    chunk_k[META_COLS],
                    chunk_k[kit_feat_cols].astype("float32"),
                    chunk_h[http_feat_cols].astype("float32"),
                ],
                axis=1,
            )

            hybrid_chunk.to_csv(out_f, index=False, header=first_chunk)
            first_chunk = False
            total_rows += len(hybrid_chunk)

            if total_rows % 500_000 == 0:
                _log.info("  Wrote %d rows …", total_rows)

    _log.info("Done: %s  (%d rows)", hybrid_path.name, total_rows)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--combined_dir", type=Path,
                        default=Path("dataset/CSV_Data/combined"))
    parser.add_argument("--day", nargs="+", default=["friday", "thursday"],
                        choices=["friday", "thursday"])
    args = parser.parse_args()

    for day in args.day:
        build_hybrid(args.combined_dir, day)


if __name__ == "__main__":
    main()
