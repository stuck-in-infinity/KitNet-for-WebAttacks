"""
from __future__ import annotations

import argparse
import logging
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd

logging.basicConfig(
    format="%(asctime)s | %(levelname)-7s | %(message)s",
    datefmt="%H:%M:%S",
    level=logging.INFO,
)
_log = logging.getLogger(__name__)

FEATURE_TYPES = ["kitsune_115", "http_85", "hybrid_200"]

DAY_CFG = [
    ("Friday-23-02-2018",   "friday"),
    ("Thursday-22-02-2018", "thursday"),
]


# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------

def build_attack_index(flow_csv: Path) -> np.ndarray:
    """
    Return a sorted numpy array of Unix timestamps for ALL attack flows
    (any port). Also returns a matching array of attack_type strings.
    """
    """
    t0 = time.time()

    df = pd.read_csv(
        flow_csv,
        usecols=["Timestamp", "Label"],
        low_memory=False,
    )
    _log.info("  Loaded %d total flows (%.1fs)", len(df), time.time() - t0)

    attacks = df[df["Label"] != "Benign"].copy()
    _log.info("  Attack flows (all ports): %d", len(attacks))

    if attacks.empty:
        return np.array([], dtype=np.float64), np.array([], dtype=str)

    ts_epoch = (
        pd.to_datetime(attacks["Timestamp"], format="%d/%m/%Y %H:%M:%S", dayfirst=True)
        .astype("int64") / 1e9
    )
    atypes = attacks["Label"].values

    # Sort by timestamp
    order = np.argsort(ts_epoch.values)
    ts_sorted    = ts_epoch.values[order]
    atypes_sorted = atypes[order]

    _log.info("  Attack timestamp range: %.0f .. %.0f", ts_sorted[0], ts_sorted[-1])
    return ts_sorted, atypes_sorted


# ---------------------------------------------------------------------------
# Step 2: Vectorized relabeling using searchsorted
# ---------------------------------------------------------------------------

def relabel_vectorized(
    ts: np.ndarray,
    attack_ts: np.ndarray,
    attack_types: np.ndarray,
    tolerance_s: float = 5.0,
) -> tuple[np.ndarray, np.ndarray]:
    """
    labels = np.zeros(n, dtype=np.int8)
    atypes = np.full(n, "Benign", dtype=object)

    if len(attack_ts) == 0:
        return labels, atypes

    # searchsorted gives insertion point; check neighbours
    idx = np.searchsorted(attack_ts, ts)

    # Left neighbour
    left_idx  = np.clip(idx - 1, 0, len(attack_ts) - 1)
    right_idx = np.clip(idx,     0, len(attack_ts) - 1)

    diff_left  = np.abs(attack_ts[left_idx]  - ts)
    diff_right = np.abs(attack_ts[right_idx] - ts)

    # Best neighbour
    use_left = diff_left <= diff_right
    best_idx  = np.where(use_left, left_idx, right_idx)
    best_diff = np.where(use_left, diff_left, diff_right)

    matched = best_diff <= tolerance_s
    labels[matched] = 1
    atypes[matched] = attack_types[best_idx[matched]]

    return labels, atypes


# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------

def process_one(
    day_dir:      Path,
    ftype:        str,
    canonical:    str,
    day_label:    str,
    attack_ts:    np.ndarray,
    attack_types: np.ndarray,
    output_dir:   Path,
    tolerance_s:  float = 5.0,
) -> dict:
    t0 = time.time()

    # ── 1. Collect files ────────────────────────────────────────────────────
    files = sorted(day_dir.glob(f"*_{ftype}.csv"))
    if not files:
        _log.warning("[%s][%s] No files found — skipping.", canonical, ftype)
        return {}

    _log.info("[%s][%s] Combining %d files …", canonical, ftype, len(files))

    # ── 2. Concatenate ──────────────────────────────────────────────────────
    chunks = []
    for f in files:
        try:
            df = pd.read_csv(f, low_memory=False)
            if len(df) > 0:
                chunks.append(df)
        except Exception as e:
            _log.warning("  Skipping %s: %s", f.name, e)

    if not chunks:
        _log.warning("[%s][%s] All files empty — skipping.", canonical, ftype)
        return {}

    combined = pd.concat(chunks, ignore_index=True)
    _log.info("  Combined: %d rows", len(combined))

    if "timestamp" in combined.columns:
        combined.sort_values("timestamp", inplace=True)
        combined.reset_index(drop=True, inplace=True)
        _log.info("  Sorted by timestamp.")
    else:
        _log.warning("  No 'timestamp' column — order not guaranteed.")

    # ── 4. Vectorized relabeling ────────────────────────────────────────────
    if "timestamp" in combined.columns:
        ts_vals = combined["timestamp"].values.astype(np.float64)
    else:
        ts_vals = np.zeros(len(combined))

    new_labels, new_atypes = relabel_vectorized(
        ts_vals, attack_ts, attack_types, tolerance_s
    )

    prev_attacks = int(combined["binary_label"].sum()) if "binary_label" in combined.columns else 0

    combined["binary_label"]  = new_labels.astype(int)
    combined["attack_type"]   = new_atypes
    combined["label_source"]  = np.where(new_labels == 1, "csv", "default")
    combined["day"]           = day_label

    new_attacks = int(new_labels.sum())
    _log.info("  Relabeling: %d → %d attack rows  (%.1fs so far)",
              prev_attacks, new_attacks, time.time() - t0)

    # Show attack type breakdown
    if new_attacks > 0:
        vc = combined.loc[combined["binary_label"] == 1, "attack_type"].value_counts()
        for atype, cnt in vc.items():
            _log.info("    %-30s %d", atype, cnt)

    # ── 5. Save ─────────────────────────────────────────────────────────────
    output_dir.mkdir(parents=True, exist_ok=True)
    out_path = output_dir / f"{canonical}_{ftype}.csv"
    combined.to_csv(out_path, index=False)
    elapsed = time.time() - t0
    _log.info("  Saved → %s  (%.1fs total)", out_path.name, elapsed)

    return {
        "day":          day_label,
        "feature_type": ftype,
        "total":        len(combined),
        "attacks":      new_attacks,
        "benign":       len(combined) - new_attacks,
        "elapsed_s":    elapsed,
    }


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(
        description="Combine per-PCAP feature CSVs and relabel with CICFlowMeter UTC CSV."
    )
    parser.add_argument("--friday_dir",   type=Path,
                        default=Path("dataset/CSV_Data/Friday-23-02-2018"))
    parser.add_argument("--thursday_dir", type=Path,
                        default=Path("dataset/CSV_Data/Thursday-22-02-2018"))
    parser.add_argument("--friday_csv",   type=Path,
                        default=Path("dataset/Friday-23-02-2018_TrafficForML_UTC.csv"))
    parser.add_argument("--thursday_csv", type=Path,
                        default=Path("dataset/Thursday-22-02-2018_TrafficForML_UTC.csv"))
    parser.add_argument("--output_dir",   type=Path,
                        default=Path("dataset/CSV_Data/combined"))
    parser.add_argument("--tolerance",    type=float, default=5.0,
                        help="Timestamp matching tolerance in seconds (default 5).")
    parser.add_argument("--days", nargs="+", default=["friday", "thursday"],
                        choices=["friday", "thursday"],
                        help="Which days to process.")
    parser.add_argument("--feature_types", nargs="+", default=FEATURE_TYPES,
                        help="Feature types to process.")
    args = parser.parse_args()

    day_map = {
        "friday":   (args.friday_dir,   args.friday_csv,   "Friday-23-02-2018"),
        "thursday": (args.thursday_dir, args.thursday_csv, "Thursday-22-02-2018"),
    }

    all_stats = []
    for day_key in args.days:
        day_dir, flow_csv, day_label = day_map[day_key]

        if not flow_csv.exists():
            _log.error("Flow CSV not found: %s", flow_csv)
            sys.exit(1)
        if not day_dir.exists():
            _log.error("Day directory not found: %s", day_dir)
            sys.exit(1)

        _log.info("=" * 60)
        _log.info("Day: %s", day_label)
        attack_ts, attack_types = build_attack_index(flow_csv)
        _log.info("  Attack index: %d flows", len(attack_ts))

        for ftype in args.feature_types:
            _log.info("-" * 40)
            stats = process_one(
                day_dir      = day_dir,
                ftype        = ftype,
                canonical    = day_key,
                day_label    = day_label,
                attack_ts    = attack_ts,
                attack_types = attack_types,
                output_dir   = args.output_dir,
                tolerance_s  = args.tolerance,
            )
            if stats:
                all_stats.append(stats)

    _log.info("=" * 60)
    _log.info("Summary:")
    for s in all_stats:
        _log.info(
            "  %-20s %-14s  total=%7d  attacks=%5d  benign=%7d",
            s["day"], s["feature_type"], s["total"], s["attacks"], s["benign"]
        )

    _log.info("Output directory: %s", args.output_dir)
    _log.info("Next steps:")
    _log.info("  python phase2/traditional/run_traditional.py --data_dir %s", args.output_dir)
    _log.info("  python phase2/http_only/run_http.py          --data_dir %s", args.output_dir)
    _log.info("  python phase2/hybrid/run_hybrid.py           --data_dir %s", args.output_dir)


if __name__ == "__main__":
    main()
