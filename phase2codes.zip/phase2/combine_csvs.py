"""
import argparse
import re
import sys
from pathlib import Path

import pandas as pd


FEATURE_TYPES = ["kitsune_115", "http_85", "hybrid_200"]

DAY_ALIASES = {
    "thursday": "thursday",
    "thu":      "thursday",
    "friday":   "friday",
    "fri":      "friday",
}


def extract_timestamp(path: Path) -> int:
    """Pull the numeric timestamp out of a filename like Day_1723167126_http_85.csv."""
    match = re.search(r"_(\d+)_", path.stem)
    if match:
        return int(match.group(1))
    return 0


def find_files(input_dir: Path, day_alias: str, feature_type: str) -> list[Path]:
    """
    Find all CSVs for a given day and feature type, sorted chronologically.
    Matches case-insensitively on the day prefix.
    """
    """
    candidates = []
    for f in input_dir.rglob(pattern):
        if f.stem.lower().startswith(day_alias.lower()):
            candidates.append(f)
    # Sort by embedded timestamp
    candidates.sort(key=extract_timestamp)
    return candidates


def combine(files: list[Path], output_path: Path) -> int:
    """Concatenate CSVs in order, write to output_path. Returns total row count."""
    if not files:
        return 0

    chunks = []
    for f in files:
        try:
            df = pd.read_csv(f, low_memory=False)
            chunks.append(df)
        except Exception as e:
            print(f"  [WARN] Could not read {f.name}: {e}", file=sys.stderr)

    if not chunks:
        return 0

    combined = pd.concat(chunks, ignore_index=True)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    combined.to_csv(output_path, index=False)
    return len(combined)


def main():
    parser = argparse.ArgumentParser(description="Combine per-PCAP-part CSVs into one file per day per feature type.")
    parser.add_argument("--input_dir",  required=True,
                        help="Root folder containing the per-part CSVs (searched recursively).")
    parser.add_argument("--output_dir", required=True,
                        help="Where to write the combined CSVs.")
    parser.add_argument("--days", nargs="+",
                        default=["thursday", "friday"],
                        help="Day names to process (default: thursday friday).")
    parser.add_argument("--feature_types", nargs="+",
                        default=FEATURE_TYPES,
                        help=f"Feature types to combine (default: {FEATURE_TYPES}).")
    parser.add_argument("--dry_run", action="store_true",
                        help="Print what would be combined without writing files.")
    args = parser.parse_args()

    input_dir  = Path(args.input_dir)
    output_dir = Path(args.output_dir)

    if not input_dir.exists():
        sys.exit(f"ERROR: input_dir does not exist: {input_dir}")

    print(f"Input  : {input_dir}")
    print(f"Output : {output_dir}")
    print()

    for day in args.days:
        canonical = DAY_ALIASES.get(day.lower(), day.lower())

        for ftype in args.feature_types:
            files = find_files(input_dir, day, ftype)

            if not files:
                print(f"[{canonical}][{ftype}]  No files found — skipping.")
                continue

            output_path = output_dir / f"{canonical}_{ftype}.csv"

            print(f"[{canonical}][{ftype}]  {len(files)} parts → {output_path.name}")
            for f in files:
                ts = extract_timestamp(f)
                print(f"    {ts:>12}  {f.name}")

            if args.dry_run:
                print("    [dry-run] skipping write.\n")
                continue

            rows = combine(files, output_path)
            print(f"    Combined: {rows:,} rows written.\n")

    if not args.dry_run:
        print("Done. You can now run the experiments:")
        print(f"  python phase2/traditional/run_traditional.py --data_dir {output_dir}")
        print(f"  python phase2/http_only/run_http.py          --data_dir {output_dir}")
        print(f"  python phase2/hybrid/run_hybrid.py           --data_dir {output_dir}")


if __name__ == "__main__":
    main()
