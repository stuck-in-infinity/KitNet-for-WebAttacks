# Phase 2 — Comparison Runner

## What this is

Aggregates results from all three PCAP-based Phase 2 experiments and produces a unified comparison report. Run this **after** all three experiments (traditional, http_only, hybrid) have completed.

| Experiment | Script | Features | Dims |
|------------|--------|----------|------|
| A: Traditional | `phase2/traditional/run_traditional.py` | Kitsune network AfterImage | 115 |
| B: HTTP-only | `phase2/http_only/run_http.py` | HTTP application AfterImage | 85 |
| C: Hybrid | `phase2/hybrid/run_hybrid.py` | Network + HTTP concatenated | 200 |

---

## Prerequisites

All three experiments must have produced results. The comparison script reads their `metrics.json` and `attack_breakdown.csv` files.

---

## How to run

Always run from the **project root** directory.

### Default run (reads standard result paths)
```bash
python phase2/comparison/run_comparison.py
```

### Custom result paths
```bash
python phase2/comparison/run_comparison.py \
    --exp_a results_phase2/traditional \
    --exp_b results_phase2/http_only \
    --exp_c results_phase2/hybrid \
    --output results_phase2/comparison
```

### All options
| Flag | Default | Description |
|------|---------|-------------|
| `--exp_a` | `results_phase2/traditional` | Traditional experiment results |
| `--exp_b` | `results_phase2/http_only` | HTTP-only experiment results |
| `--exp_c` | `results_phase2/hybrid` | Hybrid experiment results |
| `--output` | `results_phase2/comparison` | Where comparison outputs are saved |

---

## Output files

```
results_phase2/comparison/
    comparison_table.csv     — AUC / AUPRC / F1 / EER for all experiments × days
    attack_comparison.csv    — per-attack-type detection rates by experiment
    summary.json             — full metrics as machine-readable JSON
    roc_overlay.png          — overlaid ROC curves (requires matplotlib)
```

### comparison_table.csv columns
`experiment, dataset, AUC, AUPRC, EER, F1_optimal, Precision_opt, Recall_opt, TPR_at_FPR_0, TPR_at_FPR_0001, n_total, n_malicious, n_features`

### attack_comparison.csv columns
`experiment, day, attack_type, total_rows, attack_rows, detected, missed, detection_rate, threshold_p95`

---

## Interpreting results

- **AUC** — overall ranking quality (1.0 = perfect, 0.5 = random)
- **AUPRC** — precision–recall tradeoff, more informative for imbalanced attack data
- **F1_optimal** — best harmonic mean of precision and recall at any threshold
- **detection_rate per attack type** — fraction of attack rows flagged at the p95 benign threshold

A higher AUC/AUPRC for Experiment B (HTTP-only) vs A (Traditional) validates the novel HTTP feature contribution. Experiment C (Hybrid) showing improvement over both confirms that cross-layer correlations add value.
