"""
from __future__ import annotations

import argparse
import json
import logging
import sys
from pathlib import Path
from typing import Dict, List, Optional

import numpy as np
import pandas as pd

logging.basicConfig(
    format="%(asctime)s | %(levelname)-7s | %(message)s",
    datefmt="%H:%M:%S",
    level=logging.INFO,
)
_log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Load metrics from an experiment directory
# ---------------------------------------------------------------------------

def load_experiment_metrics(exp_dir: Path, exp_label: str) -> List[Dict]:
    """Load per-day metrics.json files from an experiment results directory."""
    results = []
    if not exp_dir.exists():
        _log.warning("Experiment dir not found: %s (skipping)", exp_dir)
        return results

    for day_dir in sorted(exp_dir.iterdir()):
        if not day_dir.is_dir():
            continue
        mfile = day_dir / "metrics.json"
        if mfile.exists():
            with open(mfile) as f:
                m = json.load(f)
            m["experiment"] = exp_label
            results.append(m)

    # Fallback: try summary file
    summary_file = exp_dir / "summary_metrics.json"
    if summary_file.exists() and not results:
        with open(summary_file) as f:
            data = json.load(f)
        for m in data:
            m["experiment"] = exp_label
            results.append(m)

    return results


def load_attack_breakdown(exp_dir: Path, exp_label: str) -> Optional[pd.DataFrame]:
    """Load combined attack breakdown if available."""
    combined = exp_dir / "attack_breakdown_combined.csv"
    if combined.exists():
        df = pd.read_csv(combined)
        df.insert(0, "experiment", exp_label)
        return df

    parts = []
    for day_dir in sorted(exp_dir.iterdir()):
        if not day_dir.is_dir():
            continue
        bd = day_dir / "attack_breakdown.csv"
        if bd.exists():
            df = pd.read_csv(bd)
            df.insert(0, "day", day_dir.name)
            df.insert(0, "experiment", exp_label)
            parts.append(df)
    return pd.concat(parts, ignore_index=True) if parts else None


# ---------------------------------------------------------------------------
# ROC overlay plot
# ---------------------------------------------------------------------------

def plot_roc_overlay(exp_dirs: Dict[str, Path], output_path: Path) -> None:
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        _log.warning("matplotlib not available — skipping ROC overlay plot.")
        return

    fig, ax = plt.subplots(figsize=(8, 6))
    colors = {
        "A: Traditional (115)": "#1f77b4",
        "B: HTTP-only (85)":    "#ff7f0e",
        "C: Hybrid (200)":      "#2ca02c",
    }

    for label, exp_dir in exp_dirs.items():
        if not exp_dir.exists():
            continue
        for day_dir in sorted(exp_dir.iterdir()):
            if not day_dir.is_dir():
                continue
            roc_file = day_dir / "roc_curve.csv"
            if roc_file.exists():
                roc = pd.read_csv(roc_file)
                ax.plot(
                    roc["fpr"], roc["tpr"],
                    label=f"{label} ({day_dir.name})",
                    color=colors.get(label),
                    alpha=0.8,
                )

    ax.plot([0, 1], [0, 1], "k--", alpha=0.3, label="Random")
    ax.set_xlabel("False Positive Rate")
    ax.set_ylabel("True Positive Rate")
    ax.set_title("Phase 2 — ROC Curve Comparison (Traditional vs HTTP-only vs Hybrid)")
    ax.legend(fontsize=8)
    ax.grid(True, alpha=0.3)
    fig.tight_layout()
    fig.savefig(output_path, dpi=150)
    plt.close(fig)
    _log.info("ROC overlay → %s", output_path)


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main(argv: Optional[List[str]] = None) -> None:
    parser = argparse.ArgumentParser(description="Phase 2 comparative analysis.")
    parser.add_argument("--exp_a",  type=Path, default=Path("results_phase2/traditional"),
                        help="Traditional KitNET results (115-dim network).")
    parser.add_argument("--exp_b",  type=Path, default=Path("results_phase2/http_only"),
                        help="HTTP-only results (85-dim HTTP).")
    parser.add_argument("--exp_c",  type=Path, default=Path("results_phase2/hybrid"),
                        help="Hybrid results (200-dim network+HTTP).")
    parser.add_argument("--output", type=Path, default=Path("results_phase2/comparison"))
    args = parser.parse_args(argv)
    args.output.mkdir(parents=True, exist_ok=True)

    all_metrics = []
    all_metrics.extend(load_experiment_metrics(args.exp_a, "A: Traditional (115)"))
    all_metrics.extend(load_experiment_metrics(args.exp_b, "B: HTTP-only (85)"))
    all_metrics.extend(load_experiment_metrics(args.exp_c, "C: Hybrid (200)"))

    if not all_metrics:
        _log.error("No experiment results found. Run the three experiments first.")
        sys.exit(1)

    key_cols = [
        "experiment", "dataset", "AUC", "AUPRC", "EER",
        "F1_optimal", "Precision_opt", "Recall_opt",
        "TPR_at_FPR_0", "TPR_at_FPR_0001",
        "n_total", "n_malicious", "n_features",
    ]
    comp_rows = [{k: m.get(k, "") for k in key_cols} for m in all_metrics]
    comp_df = pd.DataFrame(comp_rows)
    comp_df.to_csv(args.output / "comparison_table.csv", index=False)
    _log.info("Comparison table:\n%s", comp_df.to_string(index=False))

    bd_parts = []
    for label, path in [
        ("A: Traditional (115)", args.exp_a),
        ("B: HTTP-only (85)",    args.exp_b),
        ("C: Hybrid (200)",      args.exp_c),
    ]:
        bd = load_attack_breakdown(path, label)
        if bd is not None:
            bd_parts.append(bd)
    if bd_parts:
        attack_comp = pd.concat(bd_parts, ignore_index=True)
        attack_comp.to_csv(args.output / "attack_comparison.csv", index=False)
        _log.info("Attack comparison:\n%s", attack_comp.to_string(index=False))

    with open(args.output / "summary.json", "w") as fh:
        json.dump(all_metrics, fh, indent=2)

    plot_roc_overlay(
        {"A: Traditional (115)": args.exp_a, "B: HTTP-only (85)": args.exp_b, "C: Hybrid (200)": args.exp_c},
        args.output / "roc_overlay.png",
    )

    _log.info("Comparison complete → %s", args.output)


if __name__ == "__main__":
    main()
