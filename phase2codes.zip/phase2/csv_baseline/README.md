# Phase 2 — CSV Baseline (78-dim CICFlowMeter)

## What this is

A standalone baseline that runs KitNET directly on the **official CICFlowMeter per-flow CSV features** (78 numeric dimensions after dropping Timestamp and Label). This uses the already-available CSVs without needing raw PCAPs, making it the easiest experiment to run immediately.

**Important caveat:** CICFlowMeter features are per-flow aggregates, not per-request. This pipeline is labelled `feature_source = "cicflowmeter_csv"` in all output and is documented as *dataset-correct but not HTTP-feature-faithful*. The PCAP-based experiments (traditional, http_only, hybrid) are the primary experimental track.

**Known limitation:** The benign prefix before the first attack on Thursday is only ~295 rows, giving `fm_grace=44` and `ad_grace=177`. This severely limits warmup quality. Results are documented as-is.

Attack types: **Brute Force-Web**, **Brute Force-XSS**, **SQL Injection**
Days: Thursday 22-Feb-2018, Friday 23-Feb-2018

---

## Prerequisites

### 1. Install dependencies
```bash
pip install numpy pandas
# Optional (for plots):
pip install matplotlib
```

### 2. Download CICFlowMeter CSVs

Place the two official CSVs in `dataset/cse-cic-ids2018/`:
- `Thursday-22-02-2018_TrafficForML_CICFlowMeter.csv`
- `Friday-23-02-2018_TrafficForML_CICFlowMeter.csv`

These are available from the CIC-IDS-2018 dataset page at the Canadian Institute for Cybersecurity.

---

## How to run

Always run from the **project root** directory.

### Run both days
```bash
python phase2/csv_baseline/run_csv_baseline.py
```

### Run one day only
```bash
python phase2/csv_baseline/run_csv_baseline.py --day Thursday-22-02-2018
python phase2/csv_baseline/run_csv_baseline.py --day Friday-23-02-2018
```

### Custom paths
```bash
python phase2/csv_baseline/run_csv_baseline.py \
    --data_dir   dataset/cse-cic-ids2018 \
    --output_dir results_phase2/csv_baseline
```

### All options
| Flag | Default | Description |
|------|---------|-------------|
| `--data_dir` | `dataset/cse-cic-ids2018` | Directory containing the CICFlowMeter CSVs |
| `--output_dir` | `results_phase2/csv_baseline` | Where results are saved |
| `--day` | all | Limit to one day by name |
| `--m` | `10` | KitNET max cluster size |
| `--beta` | `0.75` | Feature-mapper decay ratio |
| `--lr` | `0.1` | Autoencoder learning rate |
| `--skip_plots` | off | Pass to skip matplotlib output |

---

## Output files

```
results_phase2/csv_baseline/
    Thursday-22-02-2018/
        scores.csv           — row_index, day, label, score, attack_type
        metrics.json         — AUC, AUPRC, F1, EER, n_features=78, feature_source
        roc_curve.csv
        pr_curve.csv
        attack_breakdown.csv — per-subtype detection rates at p95 threshold
    Friday-23-02-2018/
        ...same structure...
    summary_metrics.csv      — two-day summary
    summary_metrics.json
    attack_breakdown_combined.csv
    _plots/
```

---

## Expected performance note

Due to the very short benign prefix, AUC will be low (measured ~0.61 on Thursday). This is a known limitation of the CICFlowMeter CSV labelling order and is documented in the project report. Use the PCAP-based experiments for meaningful detection performance numbers.
