"""
from __future__ import annotations

import argparse
import json
import logging
import sys
import time
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

_project_root = str(Path(__file__).resolve().parent.parent.parent)
if _project_root not in sys.path:
    sys.path.insert(0, _project_root)

from core.feature_mapper import FeatureMapper
from core.kitnet import KitNET
from evaluation.metrics import build_curve_frames, compute_metrics, print_metrics
from evaluation.plot_results import make_all_plots
from phase2.reader import Phase2CSVReader, Phase2Day, discover_phase2_datasets

logging.basicConfig(
    format="%(asctime)s | %(levelname)-7s | %(message)s",
    datefmt="%H:%M:%S",
    level=logging.INFO,
)
_log = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Anomaly-detection pipeline (feature-width agnostic)
# ---------------------------------------------------------------------------


class AnomalyDetectionPipeline:
    """Three-phase pipeline: FM warmup → AD warmup → inference."""

    def __init__(
        self,
        fm_grace:         int,
        ad_grace:         int,
        n_features:       int,
        max_cluster_size: int   = 10,
        beta_ratio:       float = 0.75,
        step_size:        float = 0.1,
    ) -> None:
        self.fm_grace  = fm_grace
        self.ad_grace  = ad_grace

        self.feat_mapper = FeatureMapper(
            n_features=n_features,
            max_cluster_size=max_cluster_size,
        )
        self.detector: Optional[KitNET] = None
        self._mapper_ready = False
        self._rows_seen    = 0
        self.peak_train_score: float = 0.0
        self._beta = beta_ratio
        self._lr   = step_size

    @property
    def warmup_length(self) -> int:
        return self.fm_grace + self.ad_grace

    def step(
        self, feature_vec: np.ndarray
    ) -> Tuple[Optional[float], str]:
        idx = self._rows_seen
        self._rows_seen += 1

        if idx < self.fm_grace:
            self.feat_mapper.update(feature_vec)
            return None, "fm_train"

        if not self._mapper_ready:
            _log.info("Fitting FeatureMapper on %d rows…", self.fm_grace)
            self.feat_mapper.fit()
            self.detector = KitNET(
                cluster_sizes=self.feat_mapper.cluster_sizes,
                beta=self._beta,
                lr=self._lr,
            )
            self._mapper_ready = True
            _log.info(
                "FeatureMapper ready — k=%d clusters: %s",
                self.feat_mapper.n_clusters,
                self.feat_mapper.cluster_sizes,
            )

        sub_vecs = self.feat_mapper.transform(feature_vec)

        if idx < self.warmup_length:
            score = float(self.detector.train(sub_vecs))
            self.peak_train_score = max(self.peak_train_score, score)
            return None, "ad_train"

        return float(self.detector.execute(sub_vecs)), "exec"


# ---------------------------------------------------------------------------
# Per-attack-subtype breakdown
# ---------------------------------------------------------------------------

def build_attack_breakdown(scored_df: pd.DataFrame) -> pd.DataFrame:
    threshold = float(np.percentile(
        scored_df.loc[scored_df["label"] == 0, "score"], 95
    )) if (scored_df["label"] == 0).any() else 0.0

    rows = []
    for atype, grp in scored_df.groupby("attack_type"):
        total    = len(grp)
        is_atk   = grp["label"].sum()
        detected = int((grp["score"] > threshold).sum())
        rows.append({
            "attack_type":    atype,
            "total_rows":     total,
            "attack_rows":    int(is_atk),
            "detected":       detected,
            "missed":         total - detected,
            "detection_rate": round(detected / total, 4) if total else 0.0,
            "threshold_p95":  round(threshold, 6),
        })
    return pd.DataFrame(rows).sort_values("attack_type").reset_index(drop=True)


# ---------------------------------------------------------------------------
# Single-day evaluation
# ---------------------------------------------------------------------------

def evaluate_day(
    day:           Phase2Day,
    output_root:   Path,
    cluster_limit: int,
    beta:          float,
    learn_rate:    float,
    log_every:     int = 100_000,
) -> Dict:
    _log.info("=" * 70)
    _log.info("Phase 2 day : %s", day.name)
    _log.info("CSV         : %s", day.csv_path.name)

    reader     = Phase2CSVReader(day)
    n_feats    = reader.feature_width()
    fm_grace, ad_grace = reader.warmup_params()
    total_rows = reader.count_rows()

    _log.info("feature_width=%d  total_rows=%d", n_feats, total_rows)
    _log.info("fm_grace=%d  ad_grace=%d", fm_grace, ad_grace)

    pipeline = AnomalyDetectionPipeline(
        fm_grace=fm_grace,
        ad_grace=ad_grace,
        n_features=n_feats,
        max_cluster_size=cluster_limit,
        beta_ratio=beta,
        step_size=learn_rate,
    )

    phase_counts: Dict[str, int] = {"fm_train": 0, "ad_train": 0, "exec": 0}
    scored_rows:  List[Dict]     = []
    t_start = time.time()

    for row_idx, day_name, feat_vec, bin_label, attack_type in reader:
        if pipeline._rows_seen < pipeline.warmup_length and bin_label == 1:
            score = None
            phase = "exec_skip"
        else:
            score, phase = pipeline.step(feat_vec)

        phase_counts[phase if phase in phase_counts else "exec"] += 1

        if phase in ("exec", "exec_skip"):
            scored_rows.append({
                "row_index":   row_idx,
                "day":         day_name,
                "label":       int(bin_label),
                "score":       float(score) if score is not None else 0.0,
                "attack_type": attack_type,
            })

        if row_idx > 0 and row_idx % log_every == 0:
            _log.info(
                "Row %d / %d  |  fm=%d  ad=%d  exec=%d",
                row_idx, total_rows,
                phase_counts["fm_train"], phase_counts["ad_train"],
                phase_counts["exec"],
            )

    elapsed = time.time() - t_start

    if not scored_rows:
        _log.warning("No scored rows for day '%s'.", day.name)
        return {"dataset": day.name, "error": "no_eval_rows"}

    scored_df = pd.DataFrame(scored_rows)
    score_arr = scored_df["score"].to_numpy(dtype=np.float64)
    label_arr = scored_df["label"].to_numpy(dtype=np.int32)

    metrics = compute_metrics(
        scores=score_arr,
        labels=label_arr,
        dataset_name=day.name,
        runtime_sec=elapsed,
        extra={
            "feature_source":   "cicflowmeter_csv",
            "n_features":       int(n_feats),
            "total_rows":       int(total_rows),
            "fm_grace":         int(fm_grace),
            "ad_grace":         int(ad_grace),
            "warmup_rows":      int(pipeline.warmup_length),
            "max_cluster_size": int(cluster_limit),
            "n_clusters":       int(pipeline.feat_mapper.n_clusters),
            "cluster_sizes":    pipeline.feat_mapper.cluster_sizes,
            "fm_train_rows":    int(phase_counts["fm_train"]),
            "ad_train_rows":    int(phase_counts["ad_train"]),
            "exec_rows":        int(phase_counts["exec"]),
            "peak_train_score": round(float(pipeline.peak_train_score), 6),
            "note": (
                "CICFlowMeter-feature web-attack detection on correct Phase 2 days. "
                "Not yet HTTP-feature-faithful; raw PCAPs required for that."
            ),
        },
    )
    print_metrics(metrics)

    target_dir = output_root / day.name.replace(" ", "_")
    target_dir.mkdir(parents=True, exist_ok=True)

    scored_df.to_csv(target_dir / "scores.csv", index=False)

    roc_df, pr_df = build_curve_frames(scores=score_arr, labels=label_arr)
    roc_df.to_csv(target_dir / "roc_curve.csv", index=False)
    pr_df.to_csv( target_dir / "pr_curve.csv",  index=False)

    with open(target_dir / "metrics.json", "w") as fh:
        json.dump(metrics, fh, indent=2)

    breakdown_df = build_attack_breakdown(scored_df)
    breakdown_df.to_csv(target_dir / "attack_breakdown.csv", index=False)
    _log.info("Attack breakdown:\n%s", breakdown_df.to_string(index=False))
    _log.info("Artefacts written → %s", target_dir)
    return metrics


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main(argv: Optional[List[str]] = None) -> None:
    parser = argparse.ArgumentParser(
        description=(
            "Phase 2 CSV Baseline: KitNET on CIC-IDS-2018 web-attack days "
            "(CICFlowMeter CSV features)."
        )
    )
    parser.add_argument(
        "--data_dir", type=Path,
        default=Path("dataset/cse-cic-ids2018"),
        help="Directory containing Phase 2 CICFlowMeter CSVs.",
    )
    parser.add_argument(
        "--output_dir", type=Path,
        default=Path("results_phase2/csv_baseline"),
        help="Root output directory.",
    )
    parser.add_argument("--m",    type=int,   default=10,   help="Max cluster size.")
    parser.add_argument("--beta", type=float, default=0.75, help="KitNET beta ratio.")
    parser.add_argument("--lr",   type=float, default=0.1,  help="KitNET learning rate.")
    parser.add_argument("--skip_plots", action="store_true")
    parser.add_argument(
        "--day", type=str, default=None,
        help="Run only this day (e.g. 'Thursday-22-02-2018'). Default: all days.",
    )

    args = parser.parse_args(argv)
    args.output_dir.mkdir(parents=True, exist_ok=True)

    days = discover_phase2_datasets(args.data_dir)
    if not days:
        _log.error("No Phase 2 CSVs found in '%s'. Exiting.", args.data_dir)
        sys.exit(1)

    if args.day:
        days = [d for d in days if d.name == args.day]
        if not days:
            _log.error("Day '%s' not found in '%s'.", args.day, args.data_dir)
            sys.exit(1)

    _log.info("Phase 2 days to process: %d", len(days))
    all_metrics: List[Dict] = []
    all_breakdowns: List[pd.DataFrame] = []

    for day in days:
        result = evaluate_day(
            day=day,
            output_root=args.output_dir,
            cluster_limit=args.m,
            beta=args.beta,
            learn_rate=args.lr,
        )
        all_metrics.append(result)

        bd_path = args.output_dir / day.name.replace(" ", "_") / "attack_breakdown.csv"
        if bd_path.exists():
            bd = pd.read_csv(bd_path)
            bd.insert(0, "day", day.name)
            all_breakdowns.append(bd)

    summary_df = pd.DataFrame(all_metrics)
    summary_df.to_csv(args.output_dir / "summary_metrics.csv", index=False)
    with open(args.output_dir / "summary_metrics.json", "w") as fh:
        json.dump(all_metrics, fh, indent=2)

    if all_breakdowns:
        combined_bd = pd.concat(all_breakdowns, ignore_index=True)
        combined_bd.to_csv(
            args.output_dir / "attack_breakdown_combined.csv", index=False
        )

    _log.info("Summary → %s", args.output_dir / "summary_metrics.json")

    if not args.skip_plots:
        plots_dir = args.output_dir / "_plots"
        try:
            make_all_plots(args.output_dir, plots_dir)
            _log.info("Plots → %s", plots_dir)
        except Exception as exc:
            _log.warning("Plot generation failed (non-fatal): %s", exc)


if __name__ == "__main__":
    main()
