"""
import argparse
import re
from pathlib import Path
import pandas as pd


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--flow_csv",  type=Path, required=True)
    parser.add_argument("--pcap_dir",  type=Path, required=True)
    args = parser.parse_args()

    print("\nNote: CSV has no IP columns. Identifying attack machines by file size.\n")

    # Check label distribution
    header = pd.read_csv(args.flow_csv, nrows=0)
    lbl_col = next((c for c in header.columns if c.strip() == "Label"), None)
    if lbl_col:
        labels = pd.read_csv(args.flow_csv, usecols=[lbl_col], low_memory=False)
        labels[lbl_col] = labels[lbl_col].str.strip()
        print(f"Label distribution:\n{labels[lbl_col].value_counts().to_string()}\n")

    cap_files = [f for f in args.pcap_dir.iterdir() if f.is_file()]

    from collections import defaultdict
    by_prefix = defaultdict(list)
    for f in cap_files:
        parts = f.name.split("-")
        prefix = parts[0] if len(parts) == 1 else "-".join(parts[:2]) if "cap" in parts[0] else parts[0]
        name = f.name
        idx = name.rfind("-172.")
        if idx == -1:
            idx = name.rfind("-10.")
        if idx == -1:
            idx = name.rfind("-192.")
        machine = name[:idx] if idx != -1 else name
        by_prefix[machine].append(f)

    print("File size summary by machine group:")
    print(f"{'Machine':<35} {'Files':>6} {'Min MB':>8} {'Max MB':>8} {'Total MB':>10}")
    print("-" * 75)

    outliers = []
    for machine, files in sorted(by_prefix.items()):
        sizes = [f.stat().st_size / 1024 / 1024 for f in files]
        total = sum(sizes)
        print(f"{machine:<35} {len(files):>6} {min(sizes):>8.0f} {max(sizes):>8.0f} {total:>10.0f}")
        if len(sizes) > 1:
            import statistics
            med = statistics.median(sizes)
            for f, s in zip(files, sizes):
                if s > 5 * med:
                    outliers.append((f, s, machine))
        elif len(sizes) == 1:
            if sizes[0] > 500:
                outliers.append((files[0], sizes[0], machine))

    for f in cap_files:
        s = f.stat().st_size / 1024 / 1024
        if s > 1000 and not any(o[0] == f for o in outliers):
            machine = f.name[:f.name.rfind("-172.")]
            outliers.append((f, s, machine))

    print("\n--- Likely attack/victim files (size outliers) ---")
    for f, s, machine in sorted(outliers, key=lambda x: -x[1]):
        print(f"  {s:>8.0f} MB  {f.name}")

    print("\n--- Commands to run extraction on likely attack files ---")
    for f, s, machine in sorted(outliers, key=lambda x: -x[1]):
        safe = f.name.replace("-", "_").replace(".", "_")
        print(f"""
python phase2/http/run_extraction.py \\
    --pcap       "{f}" \\
    --flow_csv   "{args.flow_csv}" \\
    --day        Friday-23-02-2018 \\
    --output_dir "dataset/CSV_Data/Friday" \\
    --prefix     friday_{safe} \\
    --mode       all""")


if __name__ == "__main__":
    main()
