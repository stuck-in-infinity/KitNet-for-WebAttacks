"""
import argparse
import struct
import sys
from pathlib import Path
from datetime import datetime, timezone

import pandas as pd


# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------

def get_attack_windows(flow_csv: Path):
    df = pd.read_csv(flow_csv, usecols=["Timestamp", "Label"], low_memory=False)
    df["Label"] = df["Label"].str.strip()
    df["Timestamp"] = pd.to_datetime(df["Timestamp"], dayfirst=True, errors="coerce")
    df = df.dropna(subset=["Timestamp"])

    attacks = df[df["Label"] != "Benign"]
    if attacks.empty:
        print("No attack rows found in CSV.")
        sys.exit(1)

    print(f"Attack label distribution:\n{attacks['Label'].value_counts().to_string()}\n")

    t_min = attacks["Timestamp"].min()
    t_max = attacks["Timestamp"].max()

    # Per attack type windows
    windows = []
    for label, grp in attacks.groupby("Label"):
        windows.append({
            "label":   label,
            "t_start": grp["Timestamp"].min().timestamp(),
            "t_end":   grp["Timestamp"].max().timestamp(),
            "t_start_str": str(grp["Timestamp"].min()),
            "t_end_str":   str(grp["Timestamp"].max()),
        })

    print("Attack time windows (from CSV timestamps):")
    for w in windows:
        print(f"  {w['label']:<25}  {w['t_start_str']}  →  {w['t_end_str']}")

    # Combined window with 5 min buffer
    combined_start = t_min.timestamp() - 300
    combined_end   = t_max.timestamp() + 300
    print(f"\n  Combined window: {t_min} → {t_max}")
    print(f"  With 5-min buffer: epoch {combined_start:.0f} → {combined_end:.0f}\n")

    return combined_start, combined_end, windows


# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------

def _read_pcap_packets(path: Path, t_start: float, t_end: float, max_packets: int = 5000):
    """
    Read up to max_packets packets from a standard pcap file.
    Returns list of (timestamp, src_port, dst_port) for TCP packets.
    """
    """
    try:
        with open(path, "rb") as f:
            # Global header: magic(4) ver_major(2) ver_minor(2) thiszone(4)
            #                sigfigs(4) snaplen(4) network(4) = 24 bytes
            hdr = f.read(24)
            if len(hdr) < 24:
                return results
            magic = struct.unpack_from("<I", hdr)[0]
            if magic not in (0xd4c3b2a1, 0xa1b2c3d4):
                return results  # not a standard pcap

            swap = (magic == 0xa1b2c3d4)  # big-endian
            endian = ">" if swap else "<"

            count = 0
            while count < max_packets:
                rec_hdr = f.read(16)
                if len(rec_hdr) < 16:
                    break
                ts_sec, ts_usec, incl_len, orig_len = struct.unpack(f"{endian}IIII", rec_hdr)
                ts = ts_sec + ts_usec / 1e6

                data = f.read(incl_len)
                if len(data) < incl_len:
                    break
                count += 1

                if not (t_start <= ts <= t_end):
                    continue

                # Ethernet: 14 bytes header, then IP
                if len(data) < 14:
                    continue
                eth_type = struct.unpack_from(">H", data, 12)[0]
                if eth_type != 0x0800:  # not IPv4
                    continue

                ip_start = 14
                if len(data) < ip_start + 20:
                    continue
                ihl = (data[ip_start] & 0x0F) * 4
                proto = data[ip_start + 9]
                if proto != 6:  # not TCP
                    continue

                tcp_start = ip_start + ihl
                if len(data) < tcp_start + 4:
                    continue
                src_port = struct.unpack_from(">H", data, tcp_start)[0]
                dst_port = struct.unpack_from(">H", data, tcp_start + 2)[0]
                results.append((ts, src_port, dst_port))

    except Exception:
        pass
    return results


def check_pcap(path: Path, t_start: float, t_end: float) -> dict:
    """Check if a PCAP has HTTP (port 80) traffic during the attack window."""
    packets = _read_pcap_packets(path, t_start, t_end, max_packets=10000)
    http_packets = [p for p in packets if 80 in (p[1], p[2])]
    return {
        "file":          path.name,
        "size_mb":       round(path.stat().st_size / 1024 / 1024, 1),
        "pkts_in_window": len(packets),
        "http_pkts":     len(http_packets),
        "has_http":      len(http_packets) > 0,
    }


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--flow_csv", type=Path, required=True)
    parser.add_argument("--pcap_dir", type=Path, required=True)
    parser.add_argument("--top",      type=int, default=20,
                        help="Show top N files by HTTP packet count (default 20)")
    args = parser.parse_args()

    # Step 1: Get attack windows
    t_start, t_end, windows = get_attack_windows(args.flow_csv)

    # Step 2: Check each PCAP
    cap_files = sorted(args.pcap_dir.iterdir(), key=lambda f: -f.stat().st_size)
    print(f"Checking {len(cap_files)} PCAP files for HTTP traffic during attack windows...")
    print("(sampling up to 10,000 packets per file)\n")

    results = []
    for i, f in enumerate(cap_files):
        if not f.is_file():
            continue
        r = check_pcap(f, t_start, t_end)
        results.append(r)
        if (i + 1) % 20 == 0:
            print(f"  {i+1}/{len(cap_files)} files checked...")

    results.sort(key=lambda x: -x["http_pkts"])

    print(f"\n{'File':<45} {'Size MB':>8} {'Window Pkts':>12} {'HTTP Pkts':>10}")
    print("-" * 80)
    for r in results[:args.top]:
        marker = " ← ATTACK" if r["http_pkts"] > 10 else ""
        print(f"{r['file']:<45} {r['size_mb']:>8} {r['pkts_in_window']:>12} {r['http_pkts']:>10}{marker}")

    attack_files = [r for r in results if r["http_pkts"] > 10]
    print(f"\nFound {len(attack_files)} files with HTTP traffic during attack window.")

    if attack_files:
        print("\n--- Extraction commands ---")
        flow_csv = args.flow_csv
        for r in attack_files:
            f = args.pcap_dir / r["file"]
            safe = r["file"].replace("-", "_").replace(".", "_")
            print(f"""
python phase2/http/run_extraction.py \\
    --pcap       "{f}" \\
    --flow_csv   "{flow_csv}" \\
    --day        Friday-23-02-2018 \\
    --output_dir "dataset/CSV_Data/Friday" \\
    --prefix     friday_{safe} \\
    --mode       all""")


if __name__ == "__main__":
    main()
