# Phase 2 — HTTP Feature Extraction Library

Converts raw traffic (PCAP or live) into the three feature CSVs consumed by the Phase 2 experiments.

---

## Files

| File | Role |
|------|------|
| `run_extraction.py` | **Main entry point** — full pipeline: source → labeled rows → feature CSVs |
| `pcap_http_extractor.py` | Step 1: PCAP → raw HTTP transaction dicts (dpkt) |
| `pcap_http_extractor.sh` | Step 1 alternative: tshark one-liner (faster on large PCAPs) |
| `http_label_mapper.py` | Step 2: assign ground-truth labels (dual-source: metadata + CSV) |
| `pcap_dual_extractor.py` | Step 3: labeled HTTP CSV → 3 feature CSVs (used internally) |
| `http_feature_engine.py` | 85-dim HTTP AfterImage feature computation |
| `http_transaction.py` | `HTTPTransaction` dataclass |

---

## How to run (PCAP mode)

Always run from the **project root**.

### Both days, all three feature variants

```bash
# Thursday
python phase2/http/run_extraction.py \
    --pcap       /data/pcaps/Thursday-22-02-2018.pcap \
    --flow_csv   dataset/cse-cic-ids2018/Thursday-22-02-2018_TrafficForML_CICFlowMeter.csv \
    --day        Thursday-22-02-2018 \
    --output_dir dataset/cse-cic-ids2018/http_transactions \
    --prefix     thursday

# Friday
python phase2/http/run_extraction.py \
    --pcap       /data/pcaps/Friday-23-02-2018.pcap \
    --flow_csv   dataset/cse-cic-ids2018/Friday-23-02-2018_TrafficForML_CICFlowMeter.csv \
    --day        Friday-23-02-2018 \
    --output_dir dataset/cse-cic-ids2018/http_transactions \
    --prefix     friday
```

This produces 6 files total:
```
dataset/cse-cic-ids2018/http_transactions/
    thursday_kitsune_115.csv
    thursday_http_85.csv
    thursday_hybrid_200.csv
    friday_kitsune_115.csv
    friday_http_85.csv
    friday_hybrid_200.csv
```

### Produce only what you need

```bash
# Only Experiment A (Traditional):
python phase2/http/run_extraction.py ... --mode traditional

# Only Experiment B (HTTP-only):
python phase2/http/run_extraction.py ... --mode http

# Only Experiment C (Hybrid):
python phase2/http/run_extraction.py ... --mode hybrid
```

### With known attacker IPs (improves labeling accuracy)

Once you identify the attacker machine IPs from the PCAP, pass them in to activate Source-A labeling:

```bash
python phase2/http/run_extraction.py \
    --pcap       ... \
    --flow_csv   ... \
    --day        Thursday-22-02-2018 \
    --attack_ips 18.218.115.60,13.58.225.72 \
    --output_dir ... \
    --prefix     thursday
```

### All CLI flags

| Flag | Default | Description |
|------|---------|-------------|
| `--pcap FILE` | — | Input PCAP file (required unless --live) |
| `--live INTERFACE` | — | Live capture interface, e.g. `eth0` (future) |
| `--flow_csv FILE` | required | CICFlowMeter CSV for Source-B labeling |
| `--day NAME` | required | e.g. `Thursday-22-02-2018` |
| `--output_dir DIR` | `dataset/cse-cic-ids2018/http_transactions` | Output directory |
| `--prefix STR` | required | Filename prefix, e.g. `thursday` |
| `--mode` | `all` | `all` / `traditional` / `http` / `hybrid` |
| `--attack_ips IPS` | none | Comma-separated attacker IPs for Source-A |
| `--tolerance SEC` | `5.0` | Timestamp tolerance for CSV-based label matching |
| `--live_port PORT` | `80` | Port filter for live capture mode |

---

## Labeling strategy (dual-source)

Source A — Documented metadata: matches `src_ip` against known attacker IPs within documented attack time windows. Most accurate when attacker IPs are known.

Source B — CICFlowMeter CSV correlation: finds the closest attack flow record by timestamp (within ±`tolerance_s` seconds). Activates when Source A doesn't match. Less precise but works without knowing attacker IPs.

Default — anything unmatched by either source is labeled Benign.

---

## Feature output schema

All three CSVs share the same column structure:

```
feat_0, feat_1, ..., feat_N-1,   binary_label, attack_type, label_source, day
```

Where `binary_label` is 0 (Benign) or 1 (Attack), `attack_type` is the original string (`Brute Force -Web`, `Brute Force -XSS`, `SQL Injection`, or `Benign`), and `label_source` is `doc`, `csv`, or `default`.

---

## Extending to live capture (future)

The `LiveCaptureSource` stub in `run_extraction.py` shows exactly where to add live sniffing. The feature engines and labeling code do not change — only the source iterator is swapped:

```python
# In run_extraction.py — implement __iter__:
class LiveCaptureSource:
    def __iter__(self) -> Iterator[dict]:
        from scapy.all import sniff, TCP, IP
        # parse TCP payloads with dpkt.http
        # yield same dict schema as PCAPSource
        ...
```

Then run:
```bash
python phase2/http/run_extraction.py \
    --live       eth0 \
    --flow_csv   ... \
    --day        live \
    --output_dir results_live/ \
    --prefix     live_capture
```

---

## After extraction — run the experiments

```bash
python phase2/traditional/run_traditional.py   # reads *_kitsune_115.csv
python phase2/http_only/run_http.py            # reads *_http_85.csv
python phase2/hybrid/run_hybrid.py             # reads *_hybrid_200.csv
python phase2/comparison/run_comparison.py     # compare all three
```
