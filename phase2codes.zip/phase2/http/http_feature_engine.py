"""
from __future__ import annotations

import argparse
import csv
import logging
import math
import sys
from collections import defaultdict
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np

logging.basicConfig(
    format="%(asctime)s | %(levelname)-7s | %(message)s",
    datefmt="%H:%M:%S",
    level=logging.INFO,
)
_log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

LAMBDAS: Tuple[float, ...] = (0.1, 0.5, 1.5, 10.0, 60.0)
N_LAMBDAS = len(LAMBDAS)
SPECIAL_CHARS: Tuple[str, ...] = ("<", ">", "'", '"', "--", ";")
N_FEATURES = 85

_IDX_REQ_RATE    = slice(0, 5)       # 5
_IDX_FAIL_AUTH   = slice(5, 10)      # 5
_IDX_URL_LEN     = slice(10, 20)     # 10 (mean + std per λ)
_IDX_QS_LEN      = slice(20, 30)     # 10
_IDX_SPECIAL     = slice(30, 60)     # 30 (6 chars × 5 λ)
_IDX_QPARAMS     = slice(60, 65)     # 5
_IDX_STATUS      = slice(65, 85)     # 20 (4 buckets × 5 λ)


# ---------------------------------------------------------------------------
# Damped Incremental Statistic (single λ)
# ---------------------------------------------------------------------------

@dataclass
class DampedStat:
    """
    Exponentially weighted running count, mean, and variance for a single λ.

    update(t, x) → (count, mean, std)
    """
    """
    last_t:      float = 0.0
    weight:      float = 0.0      # damped sum of weights
    mean:        float = 0.0
    m2:          float = 0.0

    def update(self, t: float, x: float) -> Tuple[float, float, float]:
        """
        Feed a new observation (x) at time (t).
        Returns (damped_count, current_mean, current_std).
        """
        """
            # First observation
            self.last_t = t
            self.weight = 1.0
            self.mean   = x
            self.m2     = 0.0
            return 1.0, x, 0.0

        dt = t - self.last_t
        if dt < 0:
            dt = 0.0  # handle out-of-order packets gracefully

        decay = math.exp(-dt / self.lam) if dt < 500 * self.lam else 0.0

        # Decay existing statistics
        old_weight = self.weight * decay
        new_weight = old_weight + 1.0

        delta     = x - self.mean
        new_mean  = self.mean + delta / new_weight
        new_m2    = (self.m2 * decay) + delta * (x - new_mean)

        self.weight = new_weight
        self.mean   = new_mean
        self.m2     = new_m2
        self.last_t = t

        var = self.m2 / self.weight if self.weight > 1e-12 else 0.0
        std = math.sqrt(max(var, 0.0))

        return self.weight, self.mean, std

    def get_count(self) -> float:
        """Return the current damped count without updating."""
        return self.weight


# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------

@dataclass
class DampedCounter:
    """
    Exponentially weighted event counter for a single λ.

    Counts events rather than tracking value statistics.
    """
    """
    last_t: float = 0.0
    count:  float = 0.0

    def increment(self, t: float, amount: float = 1.0) -> float:
        """Record an event at time t. Returns damped count."""
        if self.count == 0.0:
            self.last_t = t
            self.count  = amount
            return self.count

        dt = t - self.last_t
        if dt < 0:
            dt = 0.0
        decay = math.exp(-dt / self.lam) if dt < 500 * self.lam else 0.0

        self.count = self.count * decay + amount
        self.last_t = t
        return self.count


# ---------------------------------------------------------------------------
# Per-IP state across all λ values
# ---------------------------------------------------------------------------

@dataclass
class IPState:
    """All damped statistics for a single source IP."""

    # Request rate counters (one per λ)
    req_rate:       List[DampedCounter] = field(default_factory=list)
    # Failed auth counters
    fail_auth:      List[DampedCounter] = field(default_factory=list)
    # URL length stats
    url_len:        List[DampedStat]    = field(default_factory=list)
    # Query string length stats
    qs_len:         List[DampedStat]    = field(default_factory=list)
    special:        List[List[DampedCounter]] = field(default_factory=list)
    # Distinct query param count stats
    qparams:        List[DampedStat]    = field(default_factory=list)
    status_buckets: List[List[DampedCounter]] = field(default_factory=list)
    # Total request counter (for computing ratios)
    total_reqs:     List[DampedCounter] = field(default_factory=list)

    def __post_init__(self) -> None:
        if not self.req_rate:
            self.req_rate  = [DampedCounter(lam=l) for l in LAMBDAS]
            self.fail_auth = [DampedCounter(lam=l) for l in LAMBDAS]
            self.url_len   = [DampedStat(lam=l) for l in LAMBDAS]
            self.qs_len    = [DampedStat(lam=l) for l in LAMBDAS]
            self.special   = [
                [DampedCounter(lam=l) for l in LAMBDAS]
                for _ in SPECIAL_CHARS
            ]
            self.qparams    = [DampedStat(lam=l) for l in LAMBDAS]
            self.status_buckets = [
                [DampedCounter(lam=l) for l in LAMBDAS]
                for _ in range(4)  # 2xx, 3xx, 4xx, 5xx
            ]
            self.total_reqs = [DampedCounter(lam=l) for l in LAMBDAS]


# ---------------------------------------------------------------------------
# HTTP Feature Engine
# ---------------------------------------------------------------------------

class HTTPFeatureEngine:
    """
    AfterImage-style per-IP incremental statistics for HTTP traffic.

    Call `update(tx_dict)` for each HTTP transaction (as a dict with keys
    matching the intermediate CSV schema).  Returns an 85-dim numpy array.
    """
    """
    N_FEATURES = N_FEATURES

    def __init__(self) -> None:
        self._ip_states: Dict[str, IPState] = defaultdict(IPState)

    def update(self, tx: dict) -> np.ndarray:
        """
        Process one HTTP transaction dict, return 85-dim feature vector.

        Expected tx keys:
            timestamp, src_ip, request_uri, status_code, is_request
        """
        """
        src_ip    = str(tx.get("src_ip", "0.0.0.0"))
        uri       = str(tx.get("request_uri", ""))
        status    = int(tx.get("status_code", 0) or 0)
        is_req    = tx.get("is_request", True)
        if isinstance(is_req, str):
            is_req = is_req.lower() in ("true", "1", "yes")

        state = self._ip_states[src_ip]
        vec   = np.zeros(N_FEATURES, dtype=np.float32)

        for i, ctr in enumerate(state.req_rate):
            vec[i] = ctr.increment(t)

        # ── 2. Failed auth count ──────────────────────────────────
        is_fail = 1.0 if status in (401, 403) else 0.0
        for i, ctr in enumerate(state.fail_auth):
            vec[5 + i] = ctr.increment(t, is_fail)

        url_len = float(len(uri))
        for i, stat in enumerate(state.url_len):
            _, mean, std = stat.update(t, url_len)
            vec[10 + 2*i]     = mean
            vec[10 + 2*i + 1] = std

        qs = uri.split("?", 1)[1] if "?" in uri else ""
        qs_len = float(len(qs))
        for i, stat in enumerate(state.qs_len):
            _, mean, std = stat.update(t, qs_len)
            vec[20 + 2*i]     = mean
            vec[20 + 2*i + 1] = std

        # ── 5. Special character rates ────────────────────────────
        for c_idx, char in enumerate(SPECIAL_CHARS):
            count = float(uri.count(char))
            for l_idx, ctr in enumerate(state.special[c_idx]):
                vec[30 + c_idx * N_LAMBDAS + l_idx] = ctr.increment(t, count)

        if qs:
            params = qs.split("&")
            n_params = float(len({p.split("=", 1)[0] for p in params if p}))
        else:
            n_params = 0.0
        for i, stat in enumerate(state.qparams):
            _, mean, _ = stat.update(t, n_params)
            vec[60 + i] = mean

        # ── 7. Status code ratios ─────────────────────────────────
        # Increment total request counter
        for i, ctr in enumerate(state.total_reqs):
            ctr.increment(t)

        if status > 0:
            bucket = min((status // 100) - 2, 3)  # 2xx=0, 3xx=1, 4xx=2, 5xx=3
            bucket = max(bucket, 0)
            for l_idx, ctr in enumerate(state.status_buckets[bucket]):
                ctr.increment(t)

        # Compute ratios
        for b_idx in range(4):
            for l_idx in range(N_LAMBDAS):
                total = state.total_reqs[l_idx].count
                if total > 1e-12:
                    vec[65 + b_idx * N_LAMBDAS + l_idx] = (
                        state.status_buckets[b_idx][l_idx].count / total
                    )

        return vec


# ---------------------------------------------------------------------------
# Batch processing: CSV → feature CSV
# ---------------------------------------------------------------------------

def process_http_csv(
    input_path:  Path,
    output_path: Path,
) -> int:
    """
    count  = 0

    # Build output column names
    feature_names = _feature_column_names()
    out_cols = feature_names + ["binary_label", "attack_type", "day"]

    with open(input_path, newline="") as fin, \
         open(output_path, "w", newline="") as fout:
        reader = csv.DictReader(fin)
        writer = csv.writer(fout)
        writer.writerow(out_cols)

        for row in reader:
            vec = engine.update(row)
            out_row = list(vec) + [
                row.get("binary_label", 0),
                row.get("attack_type", "Benign"),
                row.get("day", ""),
            ]
            writer.writerow(out_row)
            count += 1

            if count % 100_000 == 0:
                _log.info("Processed %d HTTP transactions", count)

    _log.info("Feature extraction complete. Wrote %d rows to %s", count, output_path)
    return count


def _feature_column_names() -> List[str]:
    """Generate human-readable column names for the 85 features."""
    names: List[str] = []
    for l in LAMBDAS:
        names.append(f"req_rate_L{l}")
    for l in LAMBDAS:
        names.append(f"fail_auth_L{l}")
    for l in LAMBDAS:
        names.append(f"url_len_mean_L{l}")
        names.append(f"url_len_std_L{l}")
    for l in LAMBDAS:
        names.append(f"qs_len_mean_L{l}")
        names.append(f"qs_len_std_L{l}")
    for char in SPECIAL_CHARS:
        safe = char.replace("<", "lt").replace(">", "gt").replace("'", "sq")\
                   .replace('"', "dq").replace("--", "dd").replace(";", "sc")
        for l in LAMBDAS:
            names.append(f"schar_{safe}_L{l}")
    for l in LAMBDAS:
        names.append(f"qparams_mean_L{l}")
    for bucket in ("2xx", "3xx", "4xx", "5xx"):
        for l in LAMBDAS:
            names.append(f"status_{bucket}_ratio_L{l}")
    assert len(names) == N_FEATURES, f"Expected {N_FEATURES}, got {len(names)}"
    return names


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main() -> None:
    parser = argparse.ArgumentParser(
        description="Compute HTTP AfterImage features from labeled HTTP transaction CSV."
    )
    parser.add_argument("--input",  type=Path, required=True,
                        help="Input labeled HTTP transactions CSV.")
    parser.add_argument("--output", type=Path, required=True,
                        help="Output HTTP feature CSV (85 cols + labels).")
    args = parser.parse_args()

    if not args.input.exists():
        _log.error("Input file not found: %s", args.input)
        sys.exit(1)

    args.output.parent.mkdir(parents=True, exist_ok=True)
    process_http_csv(args.input, args.output)


if __name__ == "__main__":
    main()
