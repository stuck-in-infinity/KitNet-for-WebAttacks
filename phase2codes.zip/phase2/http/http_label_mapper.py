"""
from __future__ import annotations

import argparse
import csv
import logging
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

logging.basicConfig(
    format="%(asctime)s | %(levelname)-7s | %(message)s",
    datefmt="%H:%M:%S",
    level=logging.INFO,
)
_log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# CIC-IDS-2018 documented attack metadata
# ---------------------------------------------------------------------------
#
# Structure:
#
# ---------------------------------------------------------------------------

ATTACK_METADATA: Dict[str, List[dict]] = {
    "Thursday-22-02-2018": [
        {
            "attack_type": "Brute Force -Web",
            "time_range":  ("2018-02-22 10:13:00", "2018-02-22 11:10:00"),
            "attacker_ips": [],  # TODO: fill from PCAP / docs
            "dst_port": 80,
        },
        {
            "attack_type": "Brute Force -XSS",
            "time_range":  ("2018-02-22 10:13:00", "2018-02-22 11:10:00"),
            "attacker_ips": [],
            "dst_port": 80,
        },
        {
            "attack_type": "SQL Injection",
            "time_range":  ("2018-02-22 01:50:00", "2018-02-22 04:30:00"),
            "attacker_ips": [],
            "dst_port": 80,
        },
    ],
    "Friday-23-02-2018": [
        {
            "attack_type": "Brute Force -Web",
            "time_range":  ("2018-02-23 10:00:00", "2018-02-23 11:30:00"),
            "attacker_ips": [],
            "dst_port": 80,
        },
        {
            "attack_type": "Brute Force -XSS",
            "time_range":  ("2018-02-23 10:00:00", "2018-02-23 11:30:00"),
            "attacker_ips": [],
            "dst_port": 80,
        },
        {
            "attack_type": "SQL Injection",
            "time_range":  ("2018-02-23 01:30:00", "2018-02-23 05:00:00"),
            "attacker_ips": [],
            "dst_port": 80,
        },
    ],
}


def _parse_time(s: str) -> float:
    """Parse a datetime string to Unix epoch."""
    dt = datetime.strptime(s, "%Y-%m-%d %H:%M:%S").replace(tzinfo=timezone.utc)
    return dt.timestamp()


# ---------------------------------------------------------------------------
# Source A: documented metadata matching
# ---------------------------------------------------------------------------

def label_from_metadata(
    timestamp:    float,
    src_ip:       str,
    dst_port:     int,
    day:          str,
    attacker_ips: Optional[set[str]] = None,
) -> Optional[Tuple[str, str]]:
    """
    for entry in entries:
        t_start = _parse_time(entry["time_range"][0])
        t_end   = _parse_time(entry["time_range"][1])

        if not (t_start <= timestamp <= t_end):
            continue
        if dst_port != entry["dst_port"]:
            continue

        known_ips = set(entry.get("attacker_ips", []))
        if attacker_ips:
            known_ips |= attacker_ips

        if known_ips and src_ip not in known_ips:
            continue

        return entry["attack_type"], "doc"

    return None


# ---------------------------------------------------------------------------
# Source B: CICFlowMeter CSV timestamp correlation
# ---------------------------------------------------------------------------

def build_flow_label_index(
    flow_csv: Path,
    dst_port_filter: int = 80,
) -> pd.DataFrame:
    """
    # Keep only port-80 attack flows
    attacks = df[(df["Label"] != "Benign") & (df["Dst Port"] == dst_port_filter)].copy()

    if attacks.empty:
        _log.warning("No attack flows found in %s for port %d", flow_csv.name, dst_port_filter)
        return pd.DataFrame(columns=["timestamp_epoch", "label", "attack_type"])

    # Parse timestamps to epoch
    # CIC-IDS-2018 format: "22/02/2018 10:13:44"
    attacks["timestamp_epoch"] = pd.to_datetime(
        attacks["Timestamp"], format="%d/%m/%Y %H:%M:%S", dayfirst=True
    ).astype("int64") / 1e9  # nanoseconds → seconds

    attacks = attacks.rename(columns={"Label": "attack_type"})
    attacks["label"] = 1
    return attacks[["timestamp_epoch", "label", "attack_type"]].sort_values("timestamp_epoch")


def label_from_flow_csv(
    timestamp:   float,
    flow_index:  pd.DataFrame,
    tolerance_s: float = 5.0,
) -> Optional[Tuple[str, str]]:
    """
        return None

    diffs = np.abs(flow_index["timestamp_epoch"].values - timestamp)
    min_idx = int(np.argmin(diffs))
    if diffs[min_idx] <= tolerance_s:
        atype = str(flow_index.iloc[min_idx]["attack_type"])
        return atype, "csv"

    return None


# ---------------------------------------------------------------------------
# Main labeling pipeline
# ---------------------------------------------------------------------------

def label_http_transactions(
    http_csv:     Path,
    flow_csv:     Path,
    output_csv:   Path,
    day:          str,
    attacker_ips: Optional[set[str]] = None,
    tolerance_s:  float = 5.0,
) -> dict:
    """
    flow_index = build_flow_label_index(flow_csv)
    _log.info("Flow label index: %d attack flows loaded", len(flow_index))

    stats = {"total": 0, "doc": 0, "csv": 0, "default": 0, "attack": 0}

    in_cols  = None
    out_cols = None

    with open(http_csv, newline="") as fin, \
         open(output_csv, "w", newline="") as fout:

        reader = csv.DictReader(fin)
        in_cols = reader.fieldnames or []

        # Add label columns
        extra_cols = ["binary_label", "attack_type", "label_source", "day"]
        out_cols = list(in_cols) + extra_cols
        writer = csv.DictWriter(fout, fieldnames=out_cols, quoting=csv.QUOTE_ALL)
        writer.writeheader()

        for row in reader:
            stats["total"] += 1
            ts       = float(row.get("timestamp", 0.0))
            src_ip   = row.get("src_ip", "")
            dst_port = int(row.get("dst_port", 0) or 0)

            # Source A: documented metadata
            result = label_from_metadata(ts, src_ip, dst_port, day, attacker_ips)
            if result:
                attack_type, source = result
                row["binary_label"] = 1
                row["attack_type"]  = attack_type
                row["label_source"] = source
                stats["doc"] += 1
                stats["attack"] += 1
            else:
                # Source B: CSV timestamp correlation
                result = label_from_flow_csv(ts, flow_index, tolerance_s)
                if result:
                    attack_type, source = result
                    row["binary_label"] = 1
                    row["attack_type"]  = attack_type
                    row["label_source"] = source
                    stats["csv"] += 1
                    stats["attack"] += 1
                else:
                    row["binary_label"] = 0
                    row["attack_type"]  = "Benign"
                    row["label_source"] = "default"
                    stats["default"] += 1

            row["day"] = day
            writer.writerow(row)

            if stats["total"] % 100_000 == 0:
                _log.info("Labeled %d transactions (attacks: %d)", stats["total"], stats["attack"])

    _log.info(
        "Labeling complete: total=%d, doc=%d, csv=%d, default=%d, attack=%d",
        stats["total"], stats["doc"], stats["csv"], stats["default"], stats["attack"],
    )
    return stats


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main() -> None:
    parser = argparse.ArgumentParser(
        description="Label HTTP transactions using attack metadata + CSV correlation."
    )
    parser.add_argument("--http_csv",    type=Path, required=True,
                        help="Input HTTP transactions CSV (from PCAP extractor).")
    parser.add_argument("--flow_csv",    type=Path, required=True,
                        help="CICFlowMeter CSV with flow-level labels.")
    parser.add_argument("--output",      type=Path, required=True,
                        help="Output labeled HTTP transactions CSV.")
    parser.add_argument("--day",         type=str,  required=True,
                        help="Day name, e.g. 'Thursday-22-02-2018'.")
    parser.add_argument("--attack_ips",  type=str,  default="",
                        help="Comma-separated known attacker IPs.")
    parser.add_argument("--tolerance",   type=float, default=5.0,
                        help="Timestamp tolerance (seconds) for CSV correlation.")
    args = parser.parse_args()

    ips = set(args.attack_ips.split(",")) if args.attack_ips else None

    args.output.parent.mkdir(parents=True, exist_ok=True)
    label_http_transactions(
        http_csv=args.http_csv,
        flow_csv=args.flow_csv,
        output_csv=args.output,
        day=args.day,
        attacker_ips=ips,
        tolerance_s=args.tolerance,
    )


if __name__ == "__main__":
    main()
