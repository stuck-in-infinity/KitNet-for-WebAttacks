"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional


@dataclass
class HTTPTransaction:
    """One HTTP request or response extracted from a PCAP."""

    timestamp:      float               # Unix epoch seconds
    src_ip:         str                  # Source IP address
    dst_ip:         str                  # Destination IP address
    src_port:       int                  # Source TCP port
    dst_port:       int                  # Destination TCP port
    http_method:    str = ""             # GET, POST, … (empty for responses)
    request_uri:    str = ""             # Full URI including query string
    status_code:    int = 0              # HTTP response code (0 for requests)
    content_length: int = 0              # Content-Length header value
    host:           str = ""             # Host header
    is_request:     bool = True          # True = request, False = response

    # ── Derived fields (populated lazily) ──────────────────────────
    query_string:   str = ""             # Everything after '?' in URI
    n_query_params: int = 0              # Count of distinct query parameters
    special_chars:  dict[str, int] = field(default_factory=dict)

    binary_label:   int = 0              # 0 = benign, 1 = attack
    attack_type:    str = "Benign"
    label_source:   str = "default"      # "doc" | "csv" | "default"
    day:            str = ""             # e.g. "Thursday-22-02-2018"

    # ── Helpers ────────────────────────────────────────────────────

    def parse_uri_fields(self) -> None:
        """
        Populate query_string, n_query_params, and special_chars from
        the raw request_uri.  Call after construction.
        """
        """
        if "?" in self.request_uri:
            self.query_string = self.request_uri.split("?", 1)[1]
            params = self.query_string.split("&")
            keys = {p.split("=", 1)[0] for p in params if p}
            self.n_query_params = len(keys)
        else:
            self.query_string = ""
            self.n_query_params = 0

        target = self.request_uri
        self.special_chars = {
            "<":  target.count("<"),
            ">":  target.count(">"),
            "'":  target.count("'"),
            '"':  target.count('"'),
            "--": target.count("--"),
            ";":  target.count(";"),
        }

    def to_dict(self) -> dict:
        """Flat dict suitable for CSV serialisation."""
        return {
            "timestamp":      self.timestamp,
            "src_ip":         self.src_ip,
            "dst_ip":         self.dst_ip,
            "src_port":       self.src_port,
            "dst_port":       self.dst_port,
            "http_method":    self.http_method,
            "request_uri":    self.request_uri,
            "status_code":    self.status_code,
            "content_length": self.content_length,
            "host":           self.host,
            "is_request":     self.is_request,
            "query_string":   self.query_string,
            "n_query_params": self.n_query_params,
            "binary_label":   self.binary_label,
            "attack_type":    self.attack_type,
            "label_source":   self.label_source,
            "day":            self.day,
        }
