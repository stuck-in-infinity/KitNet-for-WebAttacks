"""
from __future__ import annotations

import argparse
import csv
import logging
import sys
from pathlib import Path
from typing import List, Optional

import numpy as np

_project_root = str(Path(__file__).resolve().parent.parent.parent)
if _project_root not in sys.path:
    sys.path.insert(0, _project_root)

from core.feature_extractor import FeatureExtractor, N_FEATURES as KITSUNE_N
from phase2.http.http_feature_engine import HTTPFeatureEngine, N_FEATURES as HTTP_N, _feature_column_names

logging.basicConfig(
    format="%(asctime)s | %(levelname)-7s | %(message)s",
    datefmt="%H:%M:%S",
    level=logging.INFO,
)
_log = logging.getLogger(__name__)

HYBRID_N = KITSUNE_N + HTTP_N  # 115 + 85 = 200


# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------

def _kitsune_col_names() -> List[str]:
    """Generate column names for the 115 Kitsune features."""
    names = []
    lambdas = [5.0, 3.0, 1.0, 0.1, 0.01]
    stat_names = [
        "mac_size_mean", "mac_size_std",
        "src_size_mean", "src_size_std",
        "chan_size_mean", "chan_size_std",
        "sock_size_mean", "sock_size_std",
        "chan_sock_mag", "chan_sock_rad", "chan_sock_cov", "chan_sock_pcc",
        "mac_src_mag", "mac_src_rad", "mac_src_cov", "mac_src_pcc",
        "mac_count", "src_count", "chan_count", "sock_count",
        "chan_jitter_w", "chan_jitter_mean", "chan_jitter_std",
    ]
    for lam in lambdas:
        for s in stat_names:
            names.append(f"kit_{s}_L{lam}")
    assert len(names) == KITSUNE_N, f"Expected {KITSUNE_N}, got {len(names)}"
    return names


_META_COLS = ["binary_label", "attack_type", "day"]


# ---------------------------------------------------------------------------
# Core dual extraction
# ---------------------------------------------------------------------------

def extract_dual_features(
    input_csv:   Path,
    output_dir:  Path,
    prefix:      str,
) -> dict:
    """

    kitsune_path = output_dir / f"{prefix}_kitsune_115.csv"
    http_path    = output_dir / f"{prefix}_http_85.csv"
    hybrid_path  = output_dir / f"{prefix}_hybrid_200.csv"

    kit_engine  = FeatureExtractor()
    http_engine = HTTPFeatureEngine()

    kit_cols    = _kitsune_col_names()
    http_cols   = _feature_column_names()
    hybrid_cols = kit_cols + http_cols

    count = 0

    with open(input_csv, newline="") as fin, \
         open(kitsune_path, "w", newline="") as f_kit, \
         open(http_path,    "w", newline="") as f_http, \
         open(hybrid_path,  "w", newline="") as f_hyb:

        reader = csv.DictReader(fin)

        w_kit  = csv.writer(f_kit)
        w_http = csv.writer(f_http)
        w_hyb  = csv.writer(f_hyb)

        w_kit.writerow(kit_cols + _META_COLS)
        w_http.writerow(http_cols + _META_COLS)
        w_hyb.writerow(hybrid_cols + _META_COLS)

        for row in reader:
            pkt = {
                "time":     float(row.get("timestamp", 0.0)),
                "src_ip":   row.get("src_ip", "0.0.0.0"),
                "dst_ip":   row.get("dst_ip", "0.0.0.0"),
                "src_port": int(row.get("src_port", 0) or 0),
                "dst_port": int(row.get("dst_port", 0) or 0),
                "proto":    "TCP",
                "size":     float(row.get("content_length", 0) or 0),
                "src_mac":  "00:00:00:00:00:00",  # not in HTTP CSV
            }

            # ── Compute both feature vectors ──────────────────────
            kit_vec  = kit_engine.update(pkt)          # 115-dim
            http_vec = http_engine.update(row)          # 85-dim
            hyb_vec  = np.concatenate([kit_vec, http_vec])  # 200-dim

            # ── Meta columns ──────────────────────────────────────
            meta = [
                row.get("binary_label", 0),
                row.get("attack_type", "Benign"),
                row.get("day", ""),
            ]

            # ── Write rows ────────────────────────────────────────
            w_kit.writerow(list(kit_vec) + meta)
            w_http.writerow(list(http_vec) + meta)
            w_hyb.writerow(list(hyb_vec) + meta)

            count += 1
            if count % 100_000 == 0:
                _log.info("Processed %d HTTP transactions", count)

    stats = {
        "total_rows":    count,
        "kitsune_dims":  KITSUNE_N,
        "http_dims":     HTTP_N,
        "hybrid_dims":   HYBRID_N,
        "kitsune_csv":   str(kitsune_path),
        "http_csv":      str(http_path),
        "hybrid_csv":    str(hybrid_path),
    }
    _log.info(
        "Dual extraction complete: %d rows → %s, %s, %s",
        count, kitsune_path.name, http_path.name, hybrid_path.name,
    )
    return stats


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main() -> None:
    parser = argparse.ArgumentParser(
        description="Compute 115-dim + 85-dim + 200-dim features from labeled HTTP CSV."
    )
    parser.add_argument("--input",      type=Path, required=True,
                        help="Input labeled HTTP transactions CSV.")
    parser.add_argument("--output_dir", type=Path, required=True,
                        help="Output directory for feature CSVs.")
    parser.add_argument("--prefix",     type=str,  required=True,
                        help="File prefix, e.g. 'thursday' or 'friday'.")
    args = parser.parse_args()

    if not args.input.exists():
        _log.error("Input file not found: %s", args.input)
        sys.exit(1)

    extract_dual_features(args.input, args.output_dir, args.prefix)


if __name__ == "__main__":
    main()
