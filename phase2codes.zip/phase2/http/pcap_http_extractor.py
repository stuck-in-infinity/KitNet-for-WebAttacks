"""
from __future__ import annotations

import argparse
import csv
import logging
import re
import socket
import struct
import sys
from pathlib import Path
from typing import Iterator, Optional, Tuple

logging.basicConfig(
    format="%(asctime)s | %(levelname)-7s | %(message)s",
    datefmt="%H:%M:%S",
    level=logging.INFO,
)
_log = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Try dpkt first
# ---------------------------------------------------------------------------

try:
    import dpkt
    _HAVE_DPKT = True
except ImportError:
    _HAVE_DPKT = False
    _log.info("dpkt not available — using pure-Python PCAP reader (no pip install needed).")


# ---------------------------------------------------------------------------
# Output schema
# ---------------------------------------------------------------------------

_CSV_COLUMNS = [
    "timestamp", "src_ip", "dst_ip", "src_port", "dst_port",
    "http_method", "request_uri", "status_code", "content_length",
    "host", "user_agent",
]


# ===========================================================================
# Backend 1: dpkt
# ===========================================================================

def _extract_dpkt(pcap_path: Path) -> Iterator[dict]:
    """Extract HTTP transactions using dpkt."""

    def _safe_decode(raw, fallback=""):
        if isinstance(raw, bytes):
            return raw.decode("utf-8", errors="replace")
        return str(raw) if raw else fallback

    total = 0
    http_count = 0

    with open(pcap_path, "rb") as fh:
        try:
            pcap = dpkt.pcap.Reader(fh)
        except ValueError:
            fh.seek(0)
            pcap = dpkt.pcapng.Reader(fh)

        for ts, buf in pcap:
            total += 1
            if total % 500_000 == 0:
                _log.info("dpkt: %d packets, %d HTTP found", total, http_count)

            try:
                eth = dpkt.ethernet.Ethernet(buf)
            except Exception:
                try:
                    ip_pkt = dpkt.ip.IP(buf)
                except Exception:
                    continue
            else:
                if not isinstance(eth.data, dpkt.ip.IP):
                    try:
                        ip_pkt = dpkt.ip.IP(buf)
                    except Exception:
                        continue
                else:
                    ip_pkt = eth.data

            if not isinstance(ip_pkt.data, dpkt.tcp.TCP):
                continue
            tcp = ip_pkt.data
            if not tcp.data:
                continue

            src_ip = socket.inet_ntoa(ip_pkt.src)
            dst_ip = socket.inet_ntoa(ip_pkt.dst)

            try:
                req = dpkt.http.Request(tcp.data)
                http_count += 1
                yield {
                    "timestamp":      ts,
                    "src_ip":         src_ip,
                    "dst_ip":         dst_ip,
                    "src_port":       tcp.sport,
                    "dst_port":       tcp.dport,
                    "http_method":    _safe_decode(req.method),
                    "request_uri":    _safe_decode(req.uri),
                    "status_code":    0,
                    "content_length": int(req.headers.get("content-length", 0) or 0),
                    "host":           _safe_decode(req.headers.get("host", "")),
                    "user_agent":     _safe_decode(req.headers.get("user-agent", "")),
                }
                continue
            except Exception:
                pass

            try:
                resp = dpkt.http.Response(tcp.data)
                http_count += 1
                yield {
                    "timestamp":      ts,
                    "src_ip":         src_ip,
                    "dst_ip":         dst_ip,
                    "src_port":       tcp.sport,
                    "dst_port":       tcp.dport,
                    "http_method":    "",
                    "request_uri":    "",
                    "status_code":    int(resp.status) if hasattr(resp, "status") else 0,
                    "content_length": int(resp.headers.get("content-length", 0) or 0),
                    "host":           "",
                    "user_agent":     "",
                }
            except Exception:
                pass

    _log.info("dpkt done. packets=%d  http=%d", total, http_count)


# ===========================================================================
# ===========================================================================

def _parse_http_payload(payload: bytes) -> Optional[dict]:
    """
    Parse a TCP payload as HTTP request or response.
    Returns a partial dict (missing ip/port/ts) or None.
    """
    """
        text = payload.decode("utf-8", errors="replace")
    except Exception:
        return None

    req_m = re.match(
        r'^(GET|POST|PUT|DELETE|HEAD|OPTIONS|PATCH|CONNECT|TRACE) '
        r'(\S+) HTTP/[\d.]+\r?\n',
        text,
    )
    if req_m:
        method = req_m.group(1)
        uri    = req_m.group(2)
        host_m = re.search(r'(?i)^Host:\s*(.+?)\r?$', text, re.MULTILINE)
        ua_m   = re.search(r'(?i)^User-Agent:\s*(.+?)\r?$', text, re.MULTILINE)
        cl_m   = re.search(r'(?i)^Content-Length:\s*(\d+)', text, re.MULTILINE)
        return {
            "http_method":    method,
            "request_uri":    uri,
            "status_code":    0,
            "content_length": int(cl_m.group(1)) if cl_m else 0,
            "host":           host_m.group(1).strip() if host_m else "",
            "user_agent":     ua_m.group(1).strip()   if ua_m  else "",
        }

    resp_m = re.match(r'^HTTP/[\d.]+ (\d{3})', text)
    if resp_m:
        cl_m = re.search(r'(?i)^Content-Length:\s*(\d+)', text, re.MULTILINE)
        return {
            "http_method":    "",
            "request_uri":    "",
            "status_code":    int(resp_m.group(1)),
            "content_length": int(cl_m.group(1)) if cl_m else 0,
            "host":           "",
            "user_agent":     "",
        }

    return None


def _inet_ntoa(packed: bytes) -> str:
    return ".".join(str(b) for b in packed)


def _extract_pure_python_pcap(path: Path) -> Iterator[dict]:
    """
    Pure-Python reader for standard pcap format (magic 0xa1b2c3d4 / 0xd4c3b2a1).
    No external dependencies.
    """
    """
    http_count = 0

    with open(path, "rb") as f:
        # Global header (24 bytes)
        hdr = f.read(24)
        if len(hdr) < 24:
            return
        magic = struct.unpack_from("<I", hdr)[0]
        if magic == 0xa1b2c3d4:
            byte_order = "<"   # little-endian
        elif magic == 0xd4c3b2a1:
            byte_order = ">"   # big-endian (rare)
        else:
            _log.error("Not a standard pcap file (magic=%08x). Try dpkt for pcapng.", magic)
            return

        while True:
            rec_hdr = f.read(16)
            if len(rec_hdr) < 16:
                break
            ts_sec, ts_usec, incl_len, orig_len = struct.unpack(byte_order + "IIII", rec_hdr)
            if incl_len > 65535:
                break
            pkt = f.read(incl_len)
            if len(pkt) < incl_len:
                break

            total += 1
            if total % 500_000 == 0:
                _log.info("pure-py: %d packets, %d HTTP found", total, http_count)

            if len(pkt) < 54:
                continue

            # Ethernet type
            eth_type = struct.unpack_from(">H", pkt, 12)[0]
            if eth_type != 0x0800:   # IPv4 only
                continue

            ip_proto = pkt[23]
            if ip_proto != 6:        # TCP only
                continue

            # IP header length
            ip_hdr_len = (pkt[14] & 0x0F) * 4
            if 14 + ip_hdr_len + 20 > len(pkt):
                continue

            src_ip = _inet_ntoa(pkt[26:30])
            dst_ip = _inet_ntoa(pkt[30:34])

            tcp_off = 14 + ip_hdr_len
            src_port = struct.unpack_from(">H", pkt, tcp_off)[0]
            dst_port = struct.unpack_from(">H", pkt, tcp_off + 2)[0]

            # TCP header length
            tcp_hdr_len = ((pkt[tcp_off + 12] >> 4) & 0xF) * 4
            payload_off = tcp_off + tcp_hdr_len
            payload = pkt[payload_off:]

            if len(payload) < 8:
                continue

            timestamp = ts_sec + ts_usec / 1_000_000.0

            parsed = _parse_http_payload(payload)
            if parsed:
                http_count += 1
                yield {
                    "timestamp":  timestamp,
                    "src_ip":     src_ip,
                    "dst_ip":     dst_ip,
                    "src_port":   src_port,
                    "dst_port":   dst_port,
                    **parsed,
                }

    _log.info("pure-py done. packets=%d  http=%d", total, http_count)


def _extract_pure_python_pcapng(path: Path) -> Iterator[dict]:
    """
    Pure-Python reader for pcapng format (magic 0x0a0d0d0a).
    Handles Enhanced Packet Blocks (EPB, type 0x00000006) only.
    """
    """
    http_count = 0

    with open(path, "rb") as f:
        data = f.read()

    offset = 0
    while offset < len(data) - 8:
        block_type   = struct.unpack_from("<I", data, offset)[0]
        block_length = struct.unpack_from("<I", data, offset + 4)[0]
        if block_length < 12 or offset + block_length > len(data):
            break

        # Enhanced Packet Block
        if block_type == 0x00000006 and block_length > 28:
            ts_high  = struct.unpack_from("<I", data, offset + 12)[0]
            ts_low   = struct.unpack_from("<I", data, offset + 16)[0]
            cap_len  = struct.unpack_from("<I", data, offset + 20)[0]
            timestamp = ((ts_high << 32) | ts_low) / 1_000_000.0

            pkt = data[offset + 28 : offset + 28 + cap_len]
            total += 1

            if len(pkt) >= 54:
                eth_type = struct.unpack_from(">H", pkt, 12)[0]
                if eth_type == 0x0800 and pkt[23] == 6:
                    ip_hdr_len  = (pkt[14] & 0x0F) * 4
                    tcp_off     = 14 + ip_hdr_len
                    src_ip      = _inet_ntoa(pkt[26:30])
                    dst_ip      = _inet_ntoa(pkt[30:34])
                    src_port    = struct.unpack_from(">H", pkt, tcp_off)[0]
                    dst_port    = struct.unpack_from(">H", pkt, tcp_off + 2)[0]
                    tcp_hdr_len = ((pkt[tcp_off + 12] >> 4) & 0xF) * 4
                    payload     = pkt[tcp_off + tcp_hdr_len:]

                    if len(payload) >= 8:
                        parsed = _parse_http_payload(payload)
                        if parsed:
                            http_count += 1
                            yield {
                                "timestamp": timestamp,
                                "src_ip":    src_ip,
                                "dst_ip":    dst_ip,
                                "src_port":  src_port,
                                "dst_port":  dst_port,
                                **parsed,
                            }

        offset += block_length

    _log.info("pure-py pcapng done. packets=%d  http=%d", total, http_count)


# ===========================================================================
# Public interface — auto-selects backend
# ===========================================================================

def extract_http_from_pcap(pcap_path: str | Path) -> Iterator[dict]:
    """
    Yield one dict per HTTP request or response found in the PCAP.

    Auto-selects backend:
      • dpkt if installed
      • pure-Python struct reader otherwise (supports pcap and pcapng)

    Each dict has keys: timestamp, src_ip, dst_ip, src_port, dst_port,
    http_method, request_uri, status_code, content_length, host, user_agent.
    """
    """
    if not pcap_path.exists():
        raise FileNotFoundError(f"PCAP not found: {pcap_path}")

    # Detect format from magic bytes
    with open(pcap_path, "rb") as f:
        magic = struct.unpack_from("<I", f.read(4))[0]

    is_pcapng = (magic == 0x0a0d0d0a)

    if _HAVE_DPKT:
        _log.info("Using dpkt backend for %s", pcap_path.name)
        yield from _extract_dpkt(pcap_path)
    elif is_pcapng:
        _log.info("Using pure-Python pcapng reader for %s", pcap_path.name)
        yield from _extract_pure_python_pcapng(pcap_path)
    else:
        _log.info("Using pure-Python pcap reader for %s", pcap_path.name)
        yield from _extract_pure_python_pcap(pcap_path)


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main() -> None:
    parser = argparse.ArgumentParser(
        description="Extract HTTP transactions from PCAP (dpkt or pure-Python fallback)."
    )
    parser.add_argument("--pcap",   type=Path, required=True, help="Input PCAP/pcapng file.")
    parser.add_argument("--output", type=Path, required=True, help="Output CSV file.")
    args = parser.parse_args()

    args.output.parent.mkdir(parents=True, exist_ok=True)

    count = 0
    with open(args.output, "w", newline="") as fh:
        writer = csv.DictWriter(fh, fieldnames=_CSV_COLUMNS, quoting=csv.QUOTE_ALL)
        writer.writeheader()
        for tx in extract_http_from_pcap(args.pcap):
            writer.writerow(tx)
            count += 1

    _log.info("Wrote %d HTTP transactions → %s", count, args.output)


if __name__ == "__main__":
    main()
