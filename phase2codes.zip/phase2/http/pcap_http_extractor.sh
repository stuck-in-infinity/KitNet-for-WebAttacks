#!/usr/bin/env bash
# ──────────────────────────────────────────────────────────────────
# pcap_http_extractor.sh — Extract HTTP transactions from PCAP using tshark
#
# Usage:
#   bash http/pcap_http_extractor.sh <input.pcap> <output.csv>
#
# Example:
#   bash http/pcap_http_extractor.sh \
#       /data/pcaps/Thursday-22-02-2018.pcap \
#       dataset/cse-cic-ids2018/http_transactions/thursday_http.csv
#
# Requirements:
#   - tshark (Wireshark CLI) installed and in PATH
#   - Sufficient disk for the output CSV (~500MB–2GB per 50GB PCAP)
#
# Output CSV columns:
#   timestamp, src_ip, dst_ip, src_port, dst_port, http_method,
#   request_uri, status_code, content_length, host, user_agent
# ──────────────────────────────────────────────────────────────────

set -euo pipefail

if [ $# -lt 2 ]; then
    echo "Usage: $0 <input.pcap> <output.csv>"
    exit 1
fi

INPUT_PCAP="$1"
OUTPUT_CSV="$2"

if ! command -v tshark &> /dev/null; then
    echo "ERROR: tshark not found. Install Wireshark or use the Python fallback."
    echo "  Python fallback: python http/pcap_http_extractor.py --pcap $INPUT_PCAP --output $OUTPUT_CSV"
    exit 1
fi

if [ ! -f "$INPUT_PCAP" ]; then
    echo "ERROR: Input PCAP not found: $INPUT_PCAP"
    exit 1
fi

echo "Extracting HTTP transactions from: $INPUT_PCAP"
echo "Output: $OUTPUT_CSV"
echo "This may take a while for large PCAPs..."

# Write CSV header
echo '"timestamp","src_ip","dst_ip","src_port","dst_port","http_method","request_uri","status_code","content_length","host","user_agent"' > "$OUTPUT_CSV"

# Extract HTTP fields via tshark
# -Y "http"        : display filter for HTTP packets only
# -T fields        : output as tab/comma separated fields
# -e ...           : fields to extract
# -E header=n      : no header (we wrote our own)
# -E separator=,   : comma separated
# -E quote=d       : double-quote strings
tshark -r "$INPUT_PCAP" \
    -Y "http" \
    -T fields \
    -e frame.time_epoch \
    -e ip.src \
    -e ip.dst \
    -e tcp.srcport \
    -e tcp.dstport \
    -e http.request.method \
    -e http.request.uri \
    -e http.response.code \
    -e http.content_length \
    -e http.host \
    -e http.user_agent \
    -E header=n \
    -E separator=, \
    -E quote=d \
    >> "$OUTPUT_CSV"

ROW_COUNT=$(( $(wc -l < "$OUTPUT_CSV") - 1 ))
echo "Done. Extracted $ROW_COUNT HTTP transactions."
echo "Output: $OUTPUT_CSV"
