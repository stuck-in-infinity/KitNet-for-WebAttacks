"""
from __future__ import annotations

import argparse
import csv
import json
import logging
import sys
import time
from pathlib import Path
from typing import Dict, Iterator, List, Optional

import numpy as np

# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------
_project_root = str(Path(__file__).resolve().parent.parent.parent)
if _project_root not in sys.path:
    sys.path.insert(0, _project_root)

from core.feature_extractor import FeatureExtractor, N_FEATURES as KITSUNE_N
from phase2.http.http_feature_engine import (
    HTTPFeatureEngine, N_FEATURES as HTTP_N, _feature_column_names,
)
from phase2.http.http_label_mapper import (
    build_flow_label_index, label_from_metadata, label_from_flow_csv,
)
from phase2.http.pcap_http_extractor import extract_http_from_pcap

logging.basicConfig(
    format="%(asctime)s | %(levelname)-7s | %(message)s",
    datefmt="%H:%M:%S",
    level=logging.INFO,
)
_log = logging.getLogger(__name__)

HYBRID_N = KITSUNE_N + HTTP_N   # 115 + 85 = 200


# ---------------------------------------------------------------------------
# TransactionSource protocol
# ---------------------------------------------------------------------------

class PCAPSource:
    """
    Offline source: read HTTP transactions from a saved PCAP file.
    Uses the dpkt-based extractor; tshark path handled in a separate shell script.
    """
    """
    def __init__(self, pcap_path: Path) -> None:
        self.pcap_path = pcap_path

    def __iter__(self) -> Iterator[dict]:
        yield from extract_http_from_pcap(self.pcap_path)

    def __repr__(self) -> str:
        return f"PCAPSource({self.pcap_path.name})"


class LiveCaptureSource:
    """
    Placeholder for future live-capture mode.

    Yields HTTP dicts from packets sniffed on a local network interface.
    Requires scapy (pip install scapy) and root/admin permissions.

    Implement __iter__ to yield the same dict schema as PCAPSource:
        {timestamp, src_ip, dst_ip, src_port, dst_port,
         http_method, request_uri, status_code, content_length,
         host, user_agent}

    Because all downstream code consumes the same dict schema, no changes
    are needed in the labeler, feature engines, or output writers.
    """
    """
    def __init__(self, interface: str, port: int = 80, max_packets: int = 0) -> None:
        self.interface   = interface
        self.port        = port
        self.max_packets = max_packets

    def __iter__(self) -> Iterator[dict]:
        raise NotImplementedError(
            "LiveCaptureSource is not yet implemented. "
            "To add live capture: implement __iter__ using scapy's sniff() or "
            "a raw socket, parse TCP payloads with dpkt.http, and yield dicts "
            "with the same schema as PCAPSource."
        )

    def __repr__(self) -> str:
        return f"LiveCaptureSource(interface={self.interface}, port={self.port})"


# ---------------------------------------------------------------------------
# Column name helpers
# ---------------------------------------------------------------------------

def _kitsune_col_names() -> List[str]:
    names = []
    lambdas    = [5.0, 3.0, 1.0, 0.1, 0.01]
    stat_names = [
        "mac_size_mean", "mac_size_std",
        "src_size_mean", "src_size_std",
        "chan_size_mean", "chan_size_std",
        "sock_size_mean", "sock_size_std",
        "chan_sock_mag", "chan_sock_rad", "chan_sock_cov", "chan_sock_pcc",
        "mac_src_mag",  "mac_src_rad",  "mac_src_cov",  "mac_src_pcc",
        "mac_count", "src_count", "chan_count", "sock_count",
        "chan_jitter_w", "chan_jitter_mean", "chan_jitter_std",
    ]
    for lam in lambdas:
        for s in stat_names:
            names.append(f"kit_{s}_L{lam}")
    assert len(names) == KITSUNE_N
    return names


_META_COLS = ["timestamp", "binary_label", "attack_type", "label_source", "day"]


# ---------------------------------------------------------------------------
# Core extraction function
# ---------------------------------------------------------------------------

def run_extraction(
    source:         "PCAPSource | LiveCaptureSource",
    flow_csv:       Path,
    output_dir:     Path,
    prefix:         str,
    day:            str,
    mode:           str = "all",
    attacker_ips:   Optional[set] = None,
    tolerance_s:    float = 5.0,
    log_every:      int = 100_000,
) -> dict:
    """

    write_kit    = mode in ("all", "traditional")
    write_http   = mode in ("all", "http")
    write_hybrid = mode in ("all", "hybrid")

    kit_cols    = _kitsune_col_names()
    http_cols   = _feature_column_names()
    hybrid_cols = kit_cols + http_cols

    import pandas as pd
    if flow_csv is not None and Path(flow_csv).exists():
        _log.info("Building flow label index from %s …", Path(flow_csv).name)
        flow_index = build_flow_label_index(flow_csv)
        _log.info("  %d attack flows indexed", len(flow_index))
    else:
        _log.info("No flow_csv provided — Source-B labeling disabled (all unlabeled rows → Benign).")
        flow_index = pd.DataFrame(columns=["timestamp_epoch", "label", "attack_type"])

    # ── Initialise feature engines ────────────────────────────────────────
    kit_engine  = FeatureExtractor()
    http_engine = HTTPFeatureEngine()

    # ── Open output files ─────────────────────────────────────────────────
    open_files = {}
    writers    = {}

    if write_kit:
        p = output_dir / f"{prefix}_kitsune_115.csv"
        open_files["kit"]  = open(p, "w", newline="")
        writers["kit"]     = csv.writer(open_files["kit"])
        writers["kit"].writerow(kit_cols + _META_COLS)
        _log.info("Writing kitsune features → %s", p.name)

    if write_http:
        p = output_dir / f"{prefix}_http_85.csv"
        open_files["http"] = open(p, "w", newline="")
        writers["http"]    = csv.writer(open_files["http"])
        writers["http"].writerow(http_cols + _META_COLS)
        _log.info("Writing HTTP features    → %s", p.name)

    if write_hybrid:
        p = output_dir / f"{prefix}_hybrid_200.csv"
        open_files["hyb"]  = open(p, "w", newline="")
        writers["hyb"]     = csv.writer(open_files["hyb"])
        writers["hyb"].writerow(hybrid_cols + _META_COLS)
        _log.info("Writing hybrid features  → %s", p.name)

    # ── Main loop ─────────────────────────────────────────────────────────
    stats: Dict = {
        "total": 0, "attack": 0, "benign": 0,
        "label_doc": 0, "label_csv": 0, "label_default": 0,
        "kitsune_dims": KITSUNE_N, "http_dims": HTTP_N, "hybrid_dims": HYBRID_N,
        "source": repr(source), "day": day, "mode": mode,
    }

    t_start = time.time()

    try:
        for tx in source:
            stats["total"] += 1
            ts       = float(tx.get("timestamp", 0.0))
            src_ip   = tx.get("src_ip", "")
            dst_port = int(tx.get("dst_port", 0) or 0)

            # ── Label ─────────────────────────────────────────────────────
            result = label_from_metadata(ts, src_ip, dst_port, day, attacker_ips)
            if result:
                attack_type, label_src = result
                binary_label = 1
                stats["label_doc"] += 1
            else:
                result = label_from_flow_csv(ts, flow_index, tolerance_s)
                if result:
                    attack_type, label_src = result
                    binary_label = 1
                    stats["label_csv"] += 1
                else:
                    attack_type  = "Benign"
                    label_src    = "default"
                    binary_label = 0
                    stats["label_default"] += 1

            if binary_label:
                stats["attack"] += 1
            else:
                stats["benign"] += 1

            meta = [round(ts, 6), binary_label, attack_type, label_src, day]

            pkt = {
                "time":     ts,
                "src_ip":   src_ip,
                "dst_ip":   tx.get("dst_ip", "0.0.0.0"),
                "src_port": int(tx.get("src_port", 0) or 0),
                "dst_port": dst_port,
                "proto":    "TCP",
                "size":     float(tx.get("content_length", 0) or 0),
                "src_mac":  "00:00:00:00:00:00",
            }

            # ── Compute features ──────────────────────────────────────────
            if write_kit or write_hybrid:
                kit_vec = kit_engine.update(pkt)
            if write_http or write_hybrid:
                http_vec = http_engine.update(tx)

            # ── Write rows ────────────────────────────────────────────────
            if write_kit:
                writers["kit"].writerow(list(kit_vec) + meta)
            if write_http:
                writers["http"].writerow(list(http_vec) + meta)
            if write_hybrid:
                hyb_vec = np.concatenate([kit_vec, http_vec])
                writers["hyb"].writerow(list(hyb_vec) + meta)

            if stats["total"] % log_every == 0:
                elapsed = time.time() - t_start
                rate    = stats["total"] / elapsed if elapsed > 0 else 0
                _log.info(
                    "  %d tx  |  attacks=%d  benign=%d  |  %.0f tx/s",
                    stats["total"], stats["attack"], stats["benign"], rate,
                )

    finally:
        for fh in open_files.values():
            fh.close()

    elapsed = time.time() - t_start
    stats["elapsed_sec"]   = round(elapsed, 2)
    stats["tx_per_sec"]    = round(stats["total"] / elapsed, 1) if elapsed > 0 else 0
    stats["output_files"]  = {
        k: str(output_dir / f"{prefix}_{suffix}")
        for k, suffix in [
            ("kitsune_115", "kitsune_115.csv"),
            ("http_85",     "http_85.csv"),
            ("hybrid_200",  "hybrid_200.csv"),
        ]
        if (k == "kitsune_115" and write_kit)
        or (k == "http_85" and write_http)
        or (k == "hybrid_200" and write_hybrid)
    }

    # Save stats
    stats_path = output_dir / f"{prefix}_extraction_stats.json"
    with open(stats_path, "w") as fh:
        json.dump(stats, fh, indent=2)

    _log.info(
        "Extraction complete: %d transactions, %d attacks, %.1f tx/s → %s",
        stats["total"], stats["attack"], stats["tx_per_sec"], output_dir,
    )
    return stats


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main() -> None:
    parser = argparse.ArgumentParser(
        description=(
            "Full extraction pipeline: PCAP (or live) → labeled HTTP "
            "transactions → kitsune_115 / http_85 / hybrid_200 feature CSVs."
        )
    )

    # ── Source (mutually exclusive) ───────────────────────────────────────
    src_group = parser.add_mutually_exclusive_group(required=True)
    src_group.add_argument(
        "--pcap", type=Path, metavar="FILE",
        help="Input PCAP file (offline mode).",
    )
    src_group.add_argument(
        "--live", type=str, metavar="INTERFACE",
        help="Network interface for live capture (e.g. eth0, lo). Not yet implemented.",
    )

    # ── Labeling ──────────────────────────────────────────────────────────
    parser.add_argument(
        "--flow_csv", type=Path, required=False, default=None,
        help="CICFlowMeter CSV for the same day (Source-B labeling). "
             "Optional — omit for smoke tests or when CSV is unavailable.",
    )
    parser.add_argument(
        "--day", type=str, required=True,
        help="Day name, e.g. 'Thursday-22-02-2018' or 'Friday-23-02-2018'.",
    )
    parser.add_argument(
        "--attack_ips", type=str, default="",
        help="Comma-separated known attacker IPs (improves Source-A labeling).",
    )
    parser.add_argument(
        "--tolerance", type=float, default=5.0,
        help="Timestamp tolerance in seconds for CSV-based label matching (default: 5).",
    )

    # ── Output ────────────────────────────────────────────────────────────
    parser.add_argument(
        "--output_dir", type=Path,
        default=Path("dataset/cse-cic-ids2018/http_transactions"),
        help="Directory where feature CSVs are written.",
    )
    parser.add_argument(
        "--prefix", type=str, required=True,
        help="Filename prefix, e.g. 'thursday' → thursday_kitsune_115.csv …",
    )
    parser.add_argument(
        "--mode", choices=["all", "traditional", "http", "hybrid"],
        default="all",
        help=(
            "Which feature CSVs to produce: "
            "'all' (default), 'traditional' (kitsune_115 only), "
            "'http' (http_85 only), 'hybrid' (hybrid_200 only)."
        ),
    )
    parser.add_argument(
        "--live_port", type=int, default=80,
        help="Port to filter in live mode (default: 80).",
    )

    args = parser.parse_args()

    # ── Build source ──────────────────────────────────────────────────────
    if args.pcap:
        if not args.pcap.exists():
            _log.error("PCAP file not found: %s", args.pcap)
            sys.exit(1)
        source = PCAPSource(args.pcap)
    else:
        source = LiveCaptureSource(interface=args.live, port=args.live_port)

    # ── Parse attacker IPs ────────────────────────────────────────────────
    attacker_ips = (
        set(ip.strip() for ip in args.attack_ips.split(",") if ip.strip())
        if args.attack_ips else None
    )

    # ── Run ───────────────────────────────────────────────────────────────
    stats = run_extraction(
        source=source,
        flow_csv=args.flow_csv,
        output_dir=args.output_dir,
        prefix=args.prefix,
        day=args.day,
        mode=args.mode,
        attacker_ips=attacker_ips,
        tolerance_s=args.tolerance,
    )

    print("\n--- Extraction Summary ---")
    for k, v in stats.items():
        if k != "output_files":
            print(f"  {k:20s}: {v}")
    print("  Output files:")
    for name, path in stats.get("output_files", {}).items():
        print(f"    {name:15s}: {path}")


if __name__ == "__main__":
    main()
