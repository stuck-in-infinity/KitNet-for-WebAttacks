# Phase 2 — Experiment B: HTTP-only KitNET (85-dim) — Novel Contribution

## What this is

The **novel extension** of this project. KitNET runs on **85-dimensional HTTP application-layer AfterImage features** extracted from raw HTTP request/response pairs. The original Kitsune never used HTTP-layer semantics; this experiment tests whether application-layer behavioural statistics can detect web attacks that are invisible at the network layer.

### Feature breakdown (85 dimensions)

All features are per-source-IP incremental statistics with exponential damping over 5 time windows: λ ∈ {0.1 s, 0.5 s, 1.5 s, 10.0 s, 60.0 s}

| Feature group | Dims | Description |
|---------------|------|-------------|
| Request rate | 5 | HTTP requests per second (count per window) |
| Failed auth count | 5 | 401/403 responses per window |
| URL length mean | 5 | Mean URL length per window |
| URL length std | 5 | Std-dev of URL length per window |
| Query-string length mean | 5 | Mean query-string length per window |
| Query-string length std | 5 | Std-dev of query-string length per window |
| Special char counts | 30 | `< > ' " -- ;` × 5 windows |
| Query param count mean | 5 | Mean number of query params per window |
| Query param count std | 5 | Std-dev of query params per window |
| Status code distribution | 20 | 200, 3xx, 4xx, 5xx ratios × 5 windows |

Attack types evaluated: **Brute Force-Web**, **Brute Force-XSS**, **SQL Injection**
Days: Thursday 22-Feb-2018, Friday 23-Feb-2018

---

## Prerequisites

### 1. Install dependencies
```bash
pip install numpy pandas
# Optional (for plots):
pip install matplotlib
```

### 2. Extract HTTP features from PCAPs

Run the PCAP dual-extractor with the `http_only` mode to produce `*_http_85.csv` files:

```bash
python phase2/http/pcap_dual_extractor.py \
    --pcap_dir   /path/to/cic-ids-2018-pcaps/web-attack-days \
    --output_dir dataset/cse-cic-ids2018/http_transactions \
    --label_csv  dataset/cse-cic-ids2018/Thursday-22-02-2018_TrafficForML_CICFlowMeter.csv \
    --day        Thursday-22-02-2018 \
    --mode       http_only
# Repeat for Friday-23-02-2018
```

Each output CSV will contain one row per HTTP request with columns:
`timestamp, src_ip, dst_ip, src_port, dst_port, binary_label, attack_type, day, feat_0 … feat_84`

---

## How to run

Always run from the **project root** directory.

### Default run
```bash
python phase2/http_only/run_http.py
```

### Custom paths
```bash
python phase2/http_only/run_http.py \
    --data_dir   dataset/cse-cic-ids2018/http_transactions \
    --output_dir results_phase2/http_only
```

### All options
| Flag | Default | Description |
|------|---------|-------------|
| `--data_dir` | `dataset/cse-cic-ids2018/http_transactions` | Directory with `*_http_85.csv` files |
| `--output_dir` | `results_phase2/http_only` | Where results are saved |
| `--m` | `10` | KitNET max cluster size |
| `--beta` | `0.75` | Feature-mapper decay ratio |
| `--lr` | `0.1` | Autoencoder learning rate |
| `--skip_plots` | off | Pass to skip matplotlib output |

---

## Output files

```
results_phase2/http_only/
    Thursday-22-02-2018/
        scores.csv           — row_index, day, label, score, attack_type
        metrics.json         — AUC, AUPRC, F1, EER, runtime, feature_source
        roc_curve.csv
        pr_curve.csv
        attack_breakdown.csv — per-subtype detection rates
    Friday-23-02-2018/
        ...same structure...
    summary_metrics.csv
    summary_metrics.json
    _plots/
```

`metrics.json` includes `"feature_source": "http_afterimage_85"`.

---

## Compare with other experiments

```bash
python phase2/comparison/run_comparison.py
```
