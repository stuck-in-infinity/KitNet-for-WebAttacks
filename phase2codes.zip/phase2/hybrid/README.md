# Phase 2 — Experiment C: Hybrid KitNET (200-dim)

## What this is

Combined experiment. KitNET runs on a **200-dimensional feature vector** formed by concatenating the 115-dim Kitsune network-layer features with the 85-dim HTTP application-layer features from the same packet/request:

```
feature_vector = [kitsune_network (0:115)] ++ [http_afterimage (115:200)]
```

KitNET's FeatureMapper can discover **cross-layer correlations** — for example, packet jitter spikes co-occurring with SQL Injection special characters, or connection floods coinciding with elevated 4xx response ratios. The hypothesis is that combining both views improves detection accuracy over either alone.

Attack types evaluated: **Brute Force-Web**, **Brute Force-XSS**, **SQL Injection**
Days: Thursday 22-Feb-2018, Friday 23-Feb-2018

---

## Prerequisites

### 1. Install dependencies
```bash
pip install numpy pandas
# Optional (for plots):
pip install matplotlib
```

### 2. Extract hybrid features from PCAPs

Run the PCAP dual-extractor in `hybrid` mode to produce `*_hybrid_200.csv` files:

```bash
python phase2/http/pcap_dual_extractor.py \
    --pcap_dir   /path/to/cic-ids-2018-pcaps/web-attack-days \
    --output_dir dataset/cse-cic-ids2018/http_transactions \
    --label_csv  dataset/cse-cic-ids2018/Thursday-22-02-2018_TrafficForML_CICFlowMeter.csv \
    --day        Thursday-22-02-2018 \
    --mode       hybrid
# Repeat for Friday-23-02-2018
```

Each output CSV contains:
`timestamp, src_ip, dst_ip, src_port, dst_port, binary_label, attack_type, day, feat_0 … feat_199`

Columns 0–114 are Kitsune network features; columns 115–199 are HTTP AfterImage features.

---

## How to run

Always run from the **project root** directory.

### Default run
```bash
python phase2/hybrid/run_hybrid.py
```

### Custom paths
```bash
python phase2/hybrid/run_hybrid.py \
    --data_dir   dataset/cse-cic-ids2018/http_transactions \
    --output_dir results_phase2/hybrid
```

### All options
| Flag | Default | Description |
|------|---------|-------------|
| `--data_dir` | `dataset/cse-cic-ids2018/http_transactions` | Directory with `*_hybrid_200.csv` files |
| `--output_dir` | `results_phase2/hybrid` | Where results are saved |
| `--m` | `10` | KitNET max cluster size |
| `--beta` | `0.75` | Feature-mapper decay ratio |
| `--lr` | `0.1` | Autoencoder learning rate |
| `--skip_plots` | off | Pass to skip matplotlib output |

---

## Output files

```
results_phase2/hybrid/
    Thursday-22-02-2018/
        scores.csv           — row_index, day, label, score, attack_type
        metrics.json         — AUC, AUPRC, F1, EER, runtime, feature_source
        roc_curve.csv
        pr_curve.csv
        attack_breakdown.csv — per-subtype detection rates
    Friday-23-02-2018/
        ...same structure...
    summary_metrics.csv
    summary_metrics.json
    _plots/
```

`metrics.json` includes `"feature_source": "hybrid_network_http_200"`.

---

## Compare with other experiments

```bash
python phase2/comparison/run_comparison.py
```
