"""
from __future__ import annotations

import json
import logging
import sys
import time
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

_project_root = str(Path(__file__).resolve().parent.parent)
if _project_root not in sys.path:
    sys.path.insert(0, _project_root)

from core.feature_mapper import FeatureMapper
from core.kitnet import KitNET
from evaluation.metrics import build_curve_frames, compute_metrics, print_metrics
from phase2.reader import compute_warmup

_log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Pipeline
# ---------------------------------------------------------------------------

class AnomalyDetectionPipeline:
    """Three-phase pipeline: FM warmup → AD warmup → inference."""

    def __init__(
        self,
        fm_grace: int,
        ad_grace: int,
        n_features: int,
        max_cluster_size: int = 10,
        beta: float = 0.75,
        lr: float = 0.1,
    ) -> None:
        self.fm_grace = fm_grace
        self.ad_grace = ad_grace
        self.feat_mapper = FeatureMapper(
            n_features=n_features, max_cluster_size=max_cluster_size
        )
        self.detector: Optional[KitNET] = None
        self._mapper_ready = False
        self._rows_seen = 0
        self.peak_train_score = 0.0
        self._beta = beta
        self._lr = lr

    @property
    def warmup_length(self) -> int:
        return self.fm_grace + self.ad_grace

    def step(self, feature_vec: np.ndarray) -> Tuple[Optional[float], str]:
        idx = self._rows_seen
        self._rows_seen += 1

        if idx < self.fm_grace:
            self.feat_mapper.update(feature_vec)
            return None, "fm_train"

        if not self._mapper_ready:
            _log.info("Fitting FeatureMapper on %d rows…", self.fm_grace)
            self.feat_mapper.fit()
            self.detector = KitNET(
                cluster_sizes=self.feat_mapper.cluster_sizes,
                beta=self._beta,
                lr=self._lr,
            )
            self._mapper_ready = True
            _log.info(
                "FeatureMapper ready — k=%d clusters",
                self.feat_mapper.n_clusters,
            )

        sub_vecs = self.feat_mapper.transform(feature_vec)

        if idx < self.warmup_length:
            score = float(self.detector.train(sub_vecs))
            self.peak_train_score = max(self.peak_train_score, score)
            return None, "ad_train"

        return float(self.detector.execute(sub_vecs)), "exec"


# ---------------------------------------------------------------------------
# Attack breakdown
# ---------------------------------------------------------------------------

def build_attack_breakdown(scored_df: pd.DataFrame) -> pd.DataFrame:
    """Per-attack-type detection rates using 95th-percentile benign threshold."""
    benign_scores = scored_df.loc[scored_df["label"] == 0, "score"]
    threshold = float(np.percentile(benign_scores, 95)) if len(benign_scores) else 0.0

    rows = []
    for atype, grp in scored_df.groupby("attack_type"):
        total = len(grp)
        detected = int((grp["score"] > threshold).sum())
        rows.append({
            "attack_type":    atype,
            "total_rows":     total,
            "attack_rows":    int(grp["label"].sum()),
            "detected":       detected,
            "missed":         total - detected,
            "detection_rate": round(detected / total, 4) if total else 0.0,
            "threshold_p95":  round(threshold, 6),
        })
    return pd.DataFrame(rows).sort_values("attack_type").reset_index(drop=True)


# ---------------------------------------------------------------------------
# File discovery
# ---------------------------------------------------------------------------

def discover_feature_csvs(
    data_dir: Path, suffix: str
) -> List[Tuple[str, Path]]:
    """
    for p in sorted(data_dir.glob(f"*_{suffix}.csv")):
        day_name = p.stem.replace(f"_{suffix}", "")
        found.append((day_name, p))
    return found


# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------

def evaluate_feature_csv(
    day_name:       str,
    csv_path:       Path,
    output_dir:     Path,
    feature_source: str,
    cluster_limit:  int = 10,
    beta:           float = 0.75,
    learn_rate:     float = 0.1,
    log_every:      int = 50_000,
) -> Dict:
    """
    _log.info("Experiment: %s  |  Day: %s", feature_source, day_name)

    STREAM_CHUNK = 100_000
    META_COLS    = {"binary_label", "attack_type", "day", "timestamp", "label_source"}

    header_df = pd.read_csv(csv_path, nrows=0)
    feat_cols = [c for c in header_df.columns if c not in META_COLS]
    n_feats   = len(feat_cols)
    read_cols = feat_cols + ["binary_label", "attack_type"]

    _log.info("Scanning benign prefix …")
    benign_prefix = 0
    found_attack  = False
    total_rows    = 0
    for chunk in pd.read_csv(csv_path, usecols=["binary_label"],
                              chunksize=STREAM_CHUNK, dtype={"binary_label": "int8"}):
        total_rows += len(chunk)
        if not found_attack:
            for lbl in chunk["binary_label"]:
                if int(lbl) == 1:
                    found_attack = True
                    break
                benign_prefix += 1

    _log.info("feature_width=%d  total_rows=%d", n_feats, total_rows)
    fm_grace, ad_grace = compute_warmup(benign_prefix)
    _log.info(
        "benign_prefix=%d  fm_grace=%d  ad_grace=%d",
        benign_prefix, fm_grace, ad_grace,
    )

    pipeline = AnomalyDetectionPipeline(
        fm_grace=fm_grace,
        ad_grace=ad_grace,
        n_features=n_feats,
        max_cluster_size=cluster_limit,
        beta=beta,
        lr=learn_rate,
    )

    phase_counts = {"fm_train": 0, "ad_train": 0, "exec": 0}
    scored_rows: List[Dict] = []
    t_start  = time.time()
    glob_idx = 0

    feat_dtype = {c: "float32" for c in feat_cols}

    for chunk in pd.read_csv(csv_path, usecols=read_cols,
                              chunksize=STREAM_CHUNK, dtype=feat_dtype,
                              low_memory=False):
        feat_chunk  = chunk[feat_cols].fillna(0.0).replace([np.inf, -np.inf], 0.0)
        feat_array  = feat_chunk.values.astype(np.float32)
        label_array = chunk["binary_label"].values.astype(int)
        atype_array = chunk["attack_type"].values

        for i in range(len(chunk)):
            feat_vec    = feat_array[i]
            bin_label   = int(label_array[i])
            attack_type = str(atype_array[i])

            if pipeline._rows_seen < pipeline.warmup_length and bin_label == 1:
                scored_rows.append({
                    "row_index": glob_idx, "day": day_name, "label": bin_label,
                    "score": 0.0, "attack_type": attack_type,
                })
                phase_counts["exec"] += 1
                glob_idx += 1
                continue

            score, phase = pipeline.step(feat_vec)
            phase_counts[phase] += 1

            if phase == "exec":
                scored_rows.append({
                    "row_index": glob_idx, "day": day_name, "label": bin_label,
                    "score": float(score), "attack_type": attack_type,
                })

            glob_idx += 1

        if glob_idx % log_every < STREAM_CHUNK:
            elapsed_so_far = time.time() - t_start
            rate = glob_idx / max(elapsed_so_far, 1)
            _log.info("Row %d / %d  (%.0f rows/s)", glob_idx, total_rows, rate)

    elapsed = time.time() - t_start

    if not scored_rows:
        return {"dataset": day_name, "error": "no_eval_rows"}

    scored_df = pd.DataFrame(scored_rows)
    score_arr = scored_df["score"].to_numpy(dtype=np.float64)
    label_arr = scored_df["label"].to_numpy(dtype=np.int32)

    metrics = compute_metrics(
        scores=score_arr,
        labels=label_arr,
        dataset_name=day_name,
        runtime_sec=elapsed,
        extra={
            "feature_source":   feature_source,
            "n_features":       n_feats,
            "total_rows":       total_rows,
            "fm_grace":         fm_grace,
            "ad_grace":         ad_grace,
            "warmup_rows":      pipeline.warmup_length,
            "max_cluster_size": cluster_limit,
            "n_clusters":       pipeline.feat_mapper.n_clusters,
            "cluster_sizes":    pipeline.feat_mapper.cluster_sizes,
            "peak_train_score": round(pipeline.peak_train_score, 6),
        },
    )
    print_metrics(metrics)

    # Save artefacts
    target_dir = output_dir / day_name.replace(" ", "_")
    target_dir.mkdir(parents=True, exist_ok=True)

    scored_df.to_csv(target_dir / "scores.csv", index=False)
    roc_df, pr_df = build_curve_frames(scores=score_arr, labels=label_arr)
    roc_df.to_csv(target_dir / "roc_curve.csv", index=False)
    pr_df.to_csv(target_dir / "pr_curve.csv", index=False)
    with open(target_dir / "metrics.json", "w") as fh:
        json.dump(metrics, fh, indent=2)

    breakdown_df = build_attack_breakdown(scored_df)
    breakdown_df.to_csv(target_dir / "attack_breakdown.csv", index=False)
    _log.info("Attack breakdown:\n%s", breakdown_df.to_string(index=False))

    return metrics


# ---------------------------------------------------------------------------
# Multi-day evaluation with summary
# ---------------------------------------------------------------------------

def run_experiment(
    data_dir:       Path,
    output_dir:     Path,
    csv_suffix:     str,
    feature_source: str,
    cluster_limit:  int = 10,
    beta:           float = 0.75,
    learn_rate:     float = 0.1,
    skip_plots:     bool = False,
) -> List[Dict]:
    """

    days = discover_feature_csvs(data_dir, csv_suffix)
    if not days:
        _log.error("No *_%s.csv files found in %s", csv_suffix, data_dir)
        return []

    _log.info("Experiment '%s' — %d day(s) to process", feature_source, len(days))

    all_metrics: List[Dict] = []
    all_breakdowns: List[pd.DataFrame] = []

    for day_name, csv_path in days:
        result = evaluate_feature_csv(
            day_name=day_name,
            csv_path=csv_path,
            output_dir=output_dir,
            feature_source=feature_source,
            cluster_limit=cluster_limit,
            beta=beta,
            learn_rate=learn_rate,
        )
        all_metrics.append(result)

        bd_path = output_dir / day_name.replace(" ", "_") / "attack_breakdown.csv"
        if bd_path.exists():
            bd = pd.read_csv(bd_path)
            bd.insert(0, "day", day_name)
            all_breakdowns.append(bd)

    # Summary
    pd.DataFrame(all_metrics).to_csv(output_dir / "summary_metrics.csv", index=False)
    with open(output_dir / "summary_metrics.json", "w") as fh:
        json.dump(all_metrics, fh, indent=2)

    if all_breakdowns:
        combined = pd.concat(all_breakdowns, ignore_index=True)
        combined.to_csv(output_dir / "attack_breakdown_combined.csv", index=False)

    if not skip_plots:
        try:
            from evaluation.plot_results import make_all_plots
            make_all_plots(output_dir, output_dir / "_plots")
        except Exception as exc:
            _log.warning("Plot generation failed (non-fatal): %s", exc)

    _log.info("Summary → %s", output_dir / "summary_metrics.json")
    return all_metrics
