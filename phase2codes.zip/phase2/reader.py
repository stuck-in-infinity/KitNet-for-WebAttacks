"""
from __future__ import annotations

import logging
from dataclasses import dataclass
from pathlib import Path
from typing import Iterator, Tuple

import numpy as np
import pandas as pd

log = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Label vocabulary
# ---------------------------------------------------------------------------

_ATTACK_LABELS: frozenset[str] = frozenset({
    "brute force -web",
    "brute force -xss",
    "sql injection",
})

_DROP_COLS = {"Timestamp", "Label"}


# ---------------------------------------------------------------------------
# Dataclass returned by discover_phase2_datasets()
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class Phase2Day:
    name: str          # human-readable day name, e.g. "Thursday-22-02-2018"
    csv_path: Path


def discover_phase2_datasets(data_dir: str | Path) -> list[Phase2Day]:
    """Return Phase2Day objects for every recognised Phase 2 CSV found."""
    data_dir = Path(data_dir)
    known = [
        "Thursday-22-02-2018_TrafficForML_CICFlowMeter.csv",
        "Friday-23-02-2018_TrafficForML_CICFlowMeter.csv",
    ]
    found: list[Phase2Day] = []
    for fname in known:
        p = data_dir / fname
        if p.exists():
            day_name = fname.split("_")[0]   # e.g. "Thursday-22-02-2018"
            found.append(Phase2Day(name=day_name, csv_path=p))
        else:
            log.warning("Phase 2 CSV not found: %s", p)
    return found


# ---------------------------------------------------------------------------
# Label helpers
# ---------------------------------------------------------------------------

def _map_label(raw: str) -> Tuple[int, str]:
    """Return (binary_label, attack_type) for a raw label string."""
    stripped = raw.strip()
    lower    = stripped.lower()
    if lower in _ATTACK_LABELS:
        return 1, stripped
    return 0, "Benign"


# ---------------------------------------------------------------------------
# Warmup policy
# ---------------------------------------------------------------------------

def compute_warmup(benign_prefix_len: int) -> Tuple[int, int]:
    """
    Compute (fm_grace, ad_grace) from the length of the benign prefix.
    The pair is guaranteed to satisfy fm_grace + ad_grace <= benign_prefix_len.
    """
    """
    ad = min(20_000, int(0.60 * benign_prefix_len))

    if fm + ad > benign_prefix_len:
        ratio = benign_prefix_len / (fm + ad)
        fm = int(fm * ratio)
        ad = int(ad * ratio)

    return fm, ad


# ---------------------------------------------------------------------------
# Reader
# ---------------------------------------------------------------------------

class Phase2CSVReader:
    """
    Streaming reader for a single Phase 2 CICFlowMeter CSV.

    Usage
    -----
    reader = Phase2CSVReader(day)
    fm_grace, ad_grace = reader.warmup_params()
    for row_idx, day, feat_vec, binary_label, attack_type in reader:
        ...
    """
    """
    def __init__(self, day: Phase2Day, chunksize: int = 100_000) -> None:
        self.day       = day
        self.chunksize = chunksize
        self._n_features: int | None    = None
        self._feature_cols: list[str] | None = None

    # ------------------------------------------------------------------
    # Public interface
    # ------------------------------------------------------------------

    def feature_width(self) -> int:
        """Return the number of numeric feature columns (excludes Timestamp & Label)."""
        if self._feature_cols is None:
            self._detect_columns()
        return len(self._feature_cols)  # type: ignore[arg-type]

    def benign_prefix_length(self) -> int:
        """
        Count rows from the start of the CSV up to (not including) the first
        attack row.  This is the length of the initial benign training window.
        """
        """
            self._detect_columns()

        prefix = 0
        for chunk in pd.read_csv(self.day.csv_path, usecols=["Label"],
                                 chunksize=self.chunksize, low_memory=False):
            for raw in chunk["Label"]:
                label, _ = _map_label(str(raw))
                if label == 1:
                    return prefix
                prefix += 1
        return prefix

    def warmup_params(self) -> Tuple[int, int]:
        bpl = self.benign_prefix_length()
        fm, ad = compute_warmup(bpl)
        log.info(
            "[%s] benign_prefix=%d  →  fm_grace=%d  ad_grace=%d",
            self.day.name, bpl, fm, ad,
        )
        return fm, ad

    def __iter__(self) -> Iterator[Tuple[int, str, np.ndarray, int, str]]:
        """
        Yields (row_index, day_name, feature_vector, binary_label, attack_type).
        """
        """
            self._detect_columns()

        row_idx = 0
        for chunk in pd.read_csv(
            self.day.csv_path,
            chunksize=self.chunksize,
            low_memory=False,
        ):
            # Extract feature matrix
            feat_chunk = chunk[self._feature_cols].apply(  # type: ignore[index]
                pd.to_numeric, errors="coerce"
            ).fillna(0.0)
            feat_chunk = feat_chunk.replace([np.inf, -np.inf], 0.0)

            for i in range(len(chunk)):
                feat_vec     = feat_chunk.iloc[i].to_numpy(dtype=np.float32)
                raw_label    = str(chunk["Label"].iloc[i])
                bin_label, attack_type = _map_label(raw_label)
                yield row_idx, self.day.name, feat_vec, bin_label, attack_type
                row_idx += 1

    def count_rows(self) -> int:
        """Count total rows (excluding header) in the CSV."""
        total = 0
        for chunk in pd.read_csv(self.day.csv_path, usecols=["Label"],
                                  chunksize=self.chunksize, low_memory=False):
            total += len(chunk)
        return total

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _detect_columns(self) -> None:
        """Read the header and identify feature columns."""
        sample = pd.read_csv(self.day.csv_path, nrows=0)
        self._feature_cols = [
            c for c in sample.columns
            if c not in _DROP_COLS
        ]
        log.info(
            "[%s] feature_cols=%d  (dropped: %s)",
            self.day.name, len(self._feature_cols),
            sorted(_DROP_COLS & set(sample.columns)),
        )
