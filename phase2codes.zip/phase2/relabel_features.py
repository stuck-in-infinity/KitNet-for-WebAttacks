"""
from __future__ import annotations

import argparse
import logging
import sys
from pathlib import Path

import numpy as np
import pandas as pd

logging.basicConfig(
    format="%(asctime)s | %(levelname)-7s | %(message)s",
    datefmt="%H:%M:%S",
    level=logging.INFO,
)
_log = logging.getLogger(__name__)

_project_root = str(Path(__file__).resolve().parent.parent)
if _project_root not in sys.path:
    sys.path.insert(0, _project_root)

from phase2.http.http_label_mapper import build_flow_label_index, label_from_flow_csv


# ---------------------------------------------------------------------------
# Core relabeling logic
# ---------------------------------------------------------------------------

def relabel_feature_csv(
    feature_csv: Path,
    flow_csv:    Path,
    output:      Path,
    day:         str,
    tolerance_s: float = 5.0,
) -> dict:
    """
    df = pd.read_csv(feature_csv, low_memory=False)

    if "timestamp" not in df.columns:
        _log.error(
            "'timestamp' column not found in %s.\n"
            "This CSV was extracted without the timestamp column.\n"
            "Re-run run_extraction.py to get a relabelable CSV.",
            feature_csv.name,
        )
        sys.exit(1)

    _log.info("  Rows: %d", len(df))
    _log.info("  Previous label distribution:\n%s",
              df["binary_label"].value_counts().to_string())

    _log.info("Building flow label index from: %s", flow_csv.name)
    flow_index = build_flow_label_index(flow_csv)
    _log.info("  %d attack flows indexed", len(flow_index))

    if flow_index.empty:
        _log.warning("No attack flows found in CICFlowMeter CSV — labels unchanged.")
        df.to_csv(output, index=False)
        return {"total": len(df), "relabeled_attack": 0,
                "relabeled_benign": len(df), "previously_attack": 0}

    # Reassign labels row by row
    new_labels      = []
    new_attack_type = []
    new_label_src   = []

    timestamps = df["timestamp"].values

    _log.info("Matching %d rows against flow index …", len(df))
    for i, ts in enumerate(timestamps):
        result = label_from_flow_csv(float(ts), flow_index, tolerance_s)
        if result:
            atype, src = result
            new_labels.append(1)
            new_attack_type.append(atype)
            new_label_src.append(src)
        else:
            new_labels.append(0)
            new_attack_type.append("Benign")
            new_label_src.append("default")

        if (i + 1) % 100_000 == 0:
            _log.info("  %d / %d rows processed", i + 1, len(df))

    prev_attacks = int(df["binary_label"].sum()) if "binary_label" in df.columns else 0

    df["binary_label"]  = new_labels
    df["attack_type"]   = new_attack_type
    df["label_source"]  = new_label_src
    df["day"]           = day

    new_attacks = int(sum(new_labels))
    _log.info("Relabeling complete:")
    _log.info("  Previously attack rows : %d", prev_attacks)
    _log.info("  Now attack rows        : %d", new_attacks)
    _log.info("  Now benign rows        : %d", len(df) - new_attacks)

    output.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(output, index=False)
    _log.info("Saved → %s", output)

    return {
        "total":             len(df),
        "relabeled_attack":  new_attacks,
        "relabeled_benign":  len(df) - new_attacks,
        "previously_attack": prev_attacks,
    }


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main() -> None:
    parser = argparse.ArgumentParser(
        description="Post-hoc relabeling of feature CSVs using CICFlowMeter CSV."
    )

    # ── Input mode ───────────────────────────────────────────────────────────
    input_group = parser.add_mutually_exclusive_group(required=True)
    input_group.add_argument(
        "--feature_csv", type=Path,
        help="Single feature CSV to relabel.",
    )
    input_group.add_argument(
        "--data_dir", type=Path,
        help="Directory containing feature CSVs (relabels all three types for --prefix).",
    )

    parser.add_argument(
        "--prefix", type=str, default=None,
        help="Filename prefix when using --data_dir (e.g. 'friday').",
    )
    parser.add_argument(
        "--flow_csv", type=Path, required=True,
        help="CICFlowMeter CSV for the same day (from Kaggle or CIC AWS).",
    )
    parser.add_argument(
        "--day", type=str, required=True,
        help="Day name, e.g. 'Friday-23-02-2018'.",
    )
    parser.add_argument(
        "--output", type=Path, default=None,
        help="Output path (single file mode only). Defaults to overwriting input.",
    )
    parser.add_argument(
        "--tolerance", type=float, default=5.0,
        help="Timestamp matching tolerance in seconds (default: 5).",
    )
    args = parser.parse_args()

    if not args.flow_csv.exists():
        sys.exit(f"ERROR: flow_csv not found: {args.flow_csv}")

    # ── Single file mode ─────────────────────────────────────────────────────
    if args.feature_csv:
        if not args.feature_csv.exists():
            sys.exit(f"ERROR: feature_csv not found: {args.feature_csv}")
        out = args.output or args.feature_csv
        relabel_feature_csv(args.feature_csv, args.flow_csv, out, args.day, args.tolerance)

    else:
        if not args.data_dir.exists():
            sys.exit(f"ERROR: data_dir not found: {args.data_dir}")
        if not args.prefix:
            sys.exit("ERROR: --prefix is required when using --data_dir")

        suffixes = ["kitsune_115", "http_85", "hybrid_200"]
        found_any = False
        for suffix in suffixes:
            csv_path = args.data_dir / f"{args.prefix}_{suffix}.csv"
            if not csv_path.exists():
                _log.info("Skipping %s (not found)", csv_path.name)
                continue
            found_any = True
            _log.info("=" * 60)
            relabel_feature_csv(csv_path, args.flow_csv, csv_path, args.day, args.tolerance)

        if not found_any:
            sys.exit(f"ERROR: No feature CSVs found in {args.data_dir} with prefix '{args.prefix}'")

        _log.info("=" * 60)
        _log.info("All done. You can now run the experiments.")


if __name__ == "__main__":
    main()
