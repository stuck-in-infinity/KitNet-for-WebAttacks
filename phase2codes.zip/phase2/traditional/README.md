# Phase 2 — Experiment A: Traditional KitNET (115-dim)

## What this is

Control experiment. KitNET runs on the **115-dimensional Kitsune network-layer AfterImage features** extracted from raw HTTP packets in the CIC-IDS-2018 web-attack days. This replicates the original Kitsune feature space on Phase 2 traffic so the HTTP-only and Hybrid experiments have a fair baseline to beat.

Attack types evaluated: **Brute Force-Web**, **Brute Force-XSS**, **SQL Injection**
Days: Thursday 22-Feb-2018, Friday 23-Feb-2018

---

## Prerequisites

### 1. Install dependencies
```bash
pip install numpy pandas
# Optional (for plots):
pip install matplotlib
```

### 2. Extract per-packet features from PCAPs

Run the PCAP dual-extractor to produce the `*_kitsune_115.csv` files:

```bash
python phase2/http/pcap_dual_extractor.py \
    --pcap_dir  /path/to/cic-ids-2018-pcaps/web-attack-days \
    --output_dir dataset/cse-cic-ids2018/http_transactions \
    --label_csv  dataset/cse-cic-ids2018/Thursday-22-02-2018_TrafficForML_CICFlowMeter.csv \
    --day        Thursday-22-02-2018
# Repeat for Friday-23-02-2018
```

Each output CSV will contain one row per HTTP request/packet with columns:
`timestamp, src_ip, dst_ip, src_port, dst_port, binary_label, attack_type, day, feat_0 … feat_114`

---

## How to run

Always run from the **project root** directory.

### Default run (both days, default hyper-parameters)
```bash
python phase2/traditional/run_traditional.py
```

### Custom paths
```bash
python phase2/traditional/run_traditional.py \
    --data_dir   dataset/cse-cic-ids2018/http_transactions \
    --output_dir results_phase2/traditional
```

### All options
| Flag | Default | Description |
|------|---------|-------------|
| `--data_dir` | `dataset/cse-cic-ids2018/http_transactions` | Directory with `*_kitsune_115.csv` files |
| `--output_dir` | `results_phase2/traditional` | Where results are saved |
| `--m` | `10` | KitNET max cluster size |
| `--beta` | `0.75` | Feature-mapper decay ratio |
| `--lr` | `0.1` | Autoencoder learning rate |
| `--skip_plots` | off | Pass to skip matplotlib output |

---

## Output files

```
results_phase2/traditional/
    Thursday-22-02-2018/
        scores.csv           — row_index, day, label, score, attack_type
        metrics.json         — AUC, AUPRC, F1, EER, runtime, feature_source
        roc_curve.csv        — fpr, tpr
        pr_curve.csv         — precision, recall
        attack_breakdown.csv — per-subtype detection rates
    Friday-23-02-2018/
        ...same structure...
    summary_metrics.csv
    summary_metrics.json
    _plots/
        ...PNG visualisations...
```

`metrics.json` includes `"feature_source": "kitsune_network_115"` so results are unambiguous when compared with other experiments.

---

## Compare with other experiments

After running all three experiments, use the comparison runner:
```bash
python phase2/comparison/run_comparison.py
```
