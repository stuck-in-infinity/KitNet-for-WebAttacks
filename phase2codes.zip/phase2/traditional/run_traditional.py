"""
from __future__ import annotations

import argparse
import logging
import sys
from pathlib import Path

_project_root = str(Path(__file__).resolve().parent.parent.parent)
if _project_root not in sys.path:
    sys.path.insert(0, _project_root)

from phase2.pipeline import run_experiment

logging.basicConfig(
    format="%(asctime)s | %(levelname)-7s | %(message)s",
    datefmt="%H:%M:%S",
    level=logging.INFO,
)


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Phase 2 Experiment A — Traditional KitNET (115-dim network features)."
    )
    parser.add_argument(
        "--data_dir",
        type=Path,
        default=Path("dataset/cse-cic-ids2018/http_transactions"),
        help="Directory containing *_kitsune_115.csv files produced by the PCAP extractor.",
    )
    parser.add_argument(
        "--output_dir",
        type=Path,
        default=Path("results_phase2/traditional"),
        help="Where to write scores, metrics, curves, and plots.",
    )
    parser.add_argument("--m",    type=int,   default=10,   help="KitNET max cluster size.")
    parser.add_argument("--beta", type=float, default=0.75, help="KitNET beta (feature-map decay).")
    parser.add_argument("--lr",   type=float, default=0.1,  help="Autoencoder learning rate.")
    parser.add_argument("--skip_plots", action="store_true", help="Skip matplotlib plots.")
    args = parser.parse_args()

    run_experiment(
        data_dir=args.data_dir,
        output_dir=args.output_dir,
        csv_suffix="kitsune_115",
        feature_source="kitsune_network_115",
        cluster_limit=args.m,
        beta=args.beta,
        learn_rate=args.lr,
        skip_plots=args.skip_plots,
    )


if __name__ == "__main__":
    main()
