"""
from __future__ import annotations

import numpy as np

try:
    from scipy.cluster.hierarchy import fcluster, linkage
    from scipy.spatial.distance import squareform
except ImportError:
    from core._scipy_shim import fcluster, linkage, squareform  # type: ignore


# ─────────────────────────────────────────────────────────────────────────────
# HTTPFeatureMapper
# ─────────────────────────────────────────────────────────────────────────────

class HTTPFeatureMapper:
    """
    Correlation-based feature clustering, tuned for HTTP AfterImage inputs.

    Parameters
    ----------
    n_features       : int   — width of the input vector (85 for HTTP-only)
    max_cluster_size : int   — hard upper bound on features per cluster (default 5)
    min_clusters     : int   — minimum desired cluster count; largest clusters
                               are split by halving until this is met (default 15)
    """
    """
    def __init__(
        self,
        n_features:       int = 85,
        max_cluster_size: int = 5,
        min_clusters:     int = 15,
    ) -> None:
        self.n = n_features
        self.max_cluster_size = max_cluster_size
        self.min_clusters = min_clusters

        # Running statistics for correlation estimation
        self._c    = np.zeros(self.n, dtype=np.float64)
        self._c_rs = np.zeros(self.n, dtype=np.float64)
        self._C    = np.zeros((self.n, self.n), dtype=np.float64)
        self._t    = 0

        self.mapping:   list[list[int]] | None = None
        self.is_fitted: bool = False

    # ------------------------------------------------------------------
    def update(self, x: np.ndarray) -> None:
        """Accumulate streaming statistics from one feature vector."""
        self._t += 1
        self._c += x
        mu = self._c / self._t
        r = x - mu
        self._c_rs += r ** 2
        self._C += np.outer(r, r)

    # ------------------------------------------------------------------
    def fit(self) -> None:
        """Build pairwise correlation distance matrix and cluster features."""
        D = np.ones((self.n, self.n), dtype=np.float64)
        denom = np.sqrt(np.outer(self._c_rs, self._c_rs))
        nz = denom > 1e-12
        D[nz] = 1.0 - self._C[nz] / denom[nz]
        D = np.clip(D, 0.0, 1.0)
        np.fill_diagonal(D, 0.0)
        D = (D + D.T) / 2.0

        condensed = squareform(D, checks=False)
        Z = linkage(condensed, method="complete")

        self.mapping = self._cut_and_enforce(Z)
        self.is_fitted = True

    # ------------------------------------------------------------------
    def _cut_and_enforce(self, Z: np.ndarray) -> list[list[int]]:
        """
        Cut dendrogram at max_cluster_size, then split the largest groups
        until min_clusters is satisfied.
        """
        """

        # Build initial groups
        groups: dict[int, list[int]] = {}
        for feat_idx, cid in enumerate(labels):
            groups.setdefault(cid, []).append(feat_idx)

        capped: list[list[int]] = []
        for grp in groups.values():
            for i in range(0, len(grp), self.max_cluster_size):
                capped.append(grp[i : i + self.max_cluster_size])

        while len(capped) < self.min_clusters:
            # Find the largest splittable cluster
            splittable = [i for i, g in enumerate(capped) if len(g) > 1]
            if not splittable:
                break
            largest_idx = max(splittable, key=lambda i: len(capped[i]))
            largest = capped.pop(largest_idx)
            mid = len(largest) // 2
            capped.append(largest[:mid])
            capped.append(largest[mid:])

        return capped

    # ------------------------------------------------------------------
    def transform(self, x: np.ndarray) -> list[np.ndarray]:
        if not self.is_fitted:
            raise RuntimeError("HTTPFeatureMapper.fit() must be called first.")
        return [x[idx] for idx in self.mapping]

    @property
    def n_clusters(self) -> int:
        return len(self.mapping) if self.is_fitted else 0

    @property
    def cluster_sizes(self) -> list[int]:
        return [len(g) for g in self.mapping] if self.is_fitted else []


# ─────────────────────────────────────────────────────────────────────────────
# HTTPAutoencoder
# ─────────────────────────────────────────────────────────────────────────────

class HTTPAutoencoder:
    """
    Single sub-autoencoder, tuned for HTTP AfterImage statistics.

    Key differences from Phase 2 Autoencoder:
    • Leaky ReLU hidden layer (prevents dead neurons on sparse HTTP features)
    • EMA-based input normalisation (robust to query-length outliers)
    • Reconstruction target = sigmoid(z_score) so target ∈ [0, 1] matches output
    • Gradient clipping at ±1.0 for numerical stability
    """
    """
    def __init__(
        self,
        n_visible:    int,
        n_hidden:     int,
        lr:           float = 0.1,
        ema_momentum: float = 0.99,
        leaky_alpha:  float = 0.01,
    ) -> None:
        self.n_visible    = n_visible
        self.n_hidden     = n_hidden
        self.lr           = lr
        self.ema_momentum = ema_momentum
        self.leaky_alpha  = leaky_alpha

        bound = 1.0 / max(n_visible, 1)
        rng   = np.random.default_rng()
        self.W_enc = rng.uniform(-bound, bound, (n_hidden, n_visible)).astype(np.float64)
        self.b_enc = np.zeros(n_hidden,  dtype=np.float64)
        self.W_dec = rng.uniform(-bound, bound, (n_visible, n_hidden)).astype(np.float64)
        self.b_dec = np.zeros(n_visible, dtype=np.float64)

        # EMA normalisation state
        self._ema_mean = np.zeros(n_visible, dtype=np.float64)
        self._ema_var  = np.ones(n_visible,  dtype=np.float64)
        self._n_seen   = 0

    # ------------------------------------------------------------------
    # Normalisation
    # ------------------------------------------------------------------

    def _update_ema(self, x: np.ndarray) -> None:
        self._n_seen += 1
        if self._n_seen == 1:
            self._ema_mean = x.copy()
            self._ema_var  = np.ones(self.n_visible, dtype=np.float64)
        else:
            m = self.ema_momentum
            prev_mean      = self._ema_mean.copy()
            self._ema_mean = m * self._ema_mean + (1 - m) * x
            self._ema_var  = m * self._ema_var  + (1 - m) * (x - prev_mean) ** 2

    def _normalise(self, x: np.ndarray) -> np.ndarray:
        std = np.sqrt(self._ema_var + 1e-8)
        return (x - self._ema_mean) / std

    # ------------------------------------------------------------------
    # Activations
    # ------------------------------------------------------------------

    def _leaky_relu(self, z: np.ndarray) -> np.ndarray:
        return np.where(z > 0, z, self.leaky_alpha * z)

    def _leaky_relu_grad(self, z: np.ndarray) -> np.ndarray:
        """Gradient of Leaky ReLU w.r.t. pre-activation z."""
        return np.where(z > 0, 1.0, self.leaky_alpha)

    @staticmethod
    def _sigmoid(z: np.ndarray) -> np.ndarray:
        z = np.clip(z, -500.0, 500.0)
        return np.where(
            z >= 0,
            1.0 / (1.0 + np.exp(-z)),
            np.exp(z) / (1.0 + np.exp(z)),
        )

    @staticmethod
    def _sigmoid_grad(a: np.ndarray) -> np.ndarray:
        return a * (1.0 - a)

    # ------------------------------------------------------------------
    # Forward pass
    # ------------------------------------------------------------------

    def _forward(
        self, x_norm: np.ndarray
    ) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        z_enc  = self.W_enc @ x_norm + self.b_enc
        hidden = self._leaky_relu(z_enc)                   # ← Leaky ReLU
        output = self._sigmoid(self.W_dec @ hidden + self.b_dec)
        return z_enc, hidden, output

    # ------------------------------------------------------------------
    # RMSE helper
    # ------------------------------------------------------------------

    @staticmethod
    def _rmse(a: np.ndarray, b: np.ndarray) -> float:
        return float(np.sqrt(np.mean((a - b) ** 2)))

    # ------------------------------------------------------------------
    # Training step
    # ------------------------------------------------------------------

    def train(self, x: np.ndarray) -> float:
        """
        One online training step.
        Returns the RMSE between sigmoid(z_score(x)) and the reconstruction.
        """
        """
        x_norm = self._normalise(x)
        target = self._sigmoid(x_norm)            # bounded target ∈ [0, 1]

        z_enc, hidden, output = self._forward(x_norm)
        error = self._rmse(target, output)

        # Backprop
        out_delta    = (output - target) * self._sigmoid_grad(output)
        hidden_delta = (self.W_dec.T @ out_delta) * self._leaky_relu_grad(z_enc)

        # Gradient clipping
        out_delta    = np.clip(out_delta,    -1.0, 1.0)
        hidden_delta = np.clip(hidden_delta, -1.0, 1.0)

        self.W_dec -= self.lr * np.outer(out_delta,    hidden)
        self.b_dec -= self.lr * out_delta
        self.W_enc -= self.lr * np.outer(hidden_delta, x_norm)
        self.b_enc -= self.lr * hidden_delta

        return error

    # ------------------------------------------------------------------
    # Inference step
    # ------------------------------------------------------------------

    def execute(self, x: np.ndarray) -> float:
        """Inference only — no weight update."""
        x_norm = self._normalise(x)
        target = self._sigmoid(x_norm)
        _, _, output = self._forward(x_norm)
        return self._rmse(target, output)


# ─────────────────────────────────────────────────────────────────────────────
# HTTPKitNET
# ─────────────────────────────────────────────────────────────────────────────

class HTTPKitNET:
    """
    Ensemble of HTTPAutoencoders with per-cluster RMSE normalisation.

    The key addition over Phase 2 KitNET is cluster-level z-score
    normalisation: during the AD warmup, the running mean and standard
    deviation of each sub-AE's RMSE are tracked.  At inference time, each
    cluster's raw RMSE is normalised to unit variance before being fed into
    the output autoencoder.  This prevents large clusters (many features
    → larger absolute RMSE) from dominating the ensemble score.

    Parameters
    ----------
    cluster_sizes : list[int] — sizes of each feature cluster
    beta          : float     — hidden-layer size ratio (n_hidden = ceil(β·n))
    lr            : float     — SGD learning rate
    """
    """
    def __init__(
        self,
        cluster_sizes: list[int],
        beta:          float = 0.75,
        lr:            float = 0.1,
    ) -> None:
        self.k    = len(cluster_sizes)
        self.beta = beta
        self.lr   = lr

        self.ensemble: list[HTTPAutoencoder] = [
            HTTPAutoencoder(sz, max(1, int(np.ceil(beta * sz))), lr)
            for sz in cluster_sizes
        ]
        self.output_layer = HTTPAutoencoder(
            self.k, max(1, int(np.ceil(beta * self.k))), lr
        )
        self.phi: float = 0.0

        self._rmse_sum = np.zeros(self.k, dtype=np.float64)
        self._rmse_sq  = np.zeros(self.k, dtype=np.float64)
        self._rmse_n   = 0
        self._rmse_mean: np.ndarray = np.zeros(self.k, dtype=np.float64)
        self._rmse_std:  np.ndarray = np.ones(self.k,  dtype=np.float64)

    # ------------------------------------------------------------------
    def _raw_errors(
        self, sub_instances: list[np.ndarray], training: bool
    ) -> np.ndarray:
        errors = np.zeros(self.k, dtype=np.float64)
        for i, (ae, vi) in enumerate(zip(self.ensemble, sub_instances)):
            errors[i] = ae.train(vi) if training else ae.execute(vi)
        return errors

    def _update_rmse_stats(self, errors: np.ndarray) -> None:
        """Welford-like running mean/std for each cluster's RMSE."""
        self._rmse_n   += 1
        self._rmse_sum += errors
        self._rmse_sq  += errors ** 2
        n = self._rmse_n
        self._rmse_mean = self._rmse_sum / n
        var = self._rmse_sq / n - self._rmse_mean ** 2
        self._rmse_std  = np.sqrt(np.maximum(var, 1e-12))

    def _normalise_errors(self, errors: np.ndarray) -> np.ndarray:
        """
        Z-score each cluster's RMSE.  Before any stats are gathered
        (first training step) this returns the raw errors unchanged.
        """
        """
            return errors
        return (errors - self._rmse_mean) / (self._rmse_std + 1e-8)

    # ------------------------------------------------------------------
    def train(self, sub_instances: list[np.ndarray]) -> float:
        """One online training step; returns the output-layer score."""
        errors     = self._raw_errors(sub_instances, training=True)
        self._update_rmse_stats(errors)
        normalised = self._normalise_errors(errors)
        score      = self.output_layer.train(normalised)
        self.phi   = max(self.phi, score)
        return score

    def execute(self, sub_instances: list[np.ndarray]) -> float:
        """Inference only — returns the output-layer anomaly score."""
        errors     = self._raw_errors(sub_instances, training=False)
        normalised = self._normalise_errors(errors)
        return self.output_layer.execute(normalised)

    # ------------------------------------------------------------------
    # Introspection helpers
    # ------------------------------------------------------------------

    def cluster_errors(self, sub_instances: list[np.ndarray]) -> np.ndarray:
        """Raw (un-normalised) per-cluster RMSE — useful for diagnostics."""
        return self._raw_errors(sub_instances, training=False)

    @property
    def output_ae(self) -> HTTPAutoencoder:
        return self.output_layer
