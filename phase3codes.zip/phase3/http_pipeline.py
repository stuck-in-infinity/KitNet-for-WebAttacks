"""
from __future__ import annotations

import json
import logging
import sys
import time
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

_project_root = str(Path(__file__).resolve().parent.parent)
if _project_root not in sys.path:
    sys.path.insert(0, _project_root)

from phase3.http_kitnet import HTTPFeatureMapper, HTTPKitNET
from evaluation.metrics import build_curve_frames, compute_metrics, print_metrics

_log = logging.getLogger(__name__)


# ─────────────────────────────────────────────────────────────────────────────
# Warmup policy
# ─────────────────────────────────────────────────────────────────────────────

def compute_http_warmup(benign_prefix: int) -> Tuple[int, int]:
    """
    HTTP-tuned warmup: larger fractions than Phase 2 to compensate for
    the lower per-second transaction rate of HTTP vs raw packets.

    Phase 2  →  fm = min(5_000, 0.15 * bp)   ad = min(20_000, 0.60 * bp)
    Phase 3  →  fm = min(8_000, 0.20 * bp)   ad = min(40_000, 0.75 * bp)
    """
    """
    ad = min(40_000, int(0.75 * benign_prefix))

    if fm + ad > benign_prefix:
        ratio = benign_prefix / (fm + ad)
        fm = int(fm * ratio)
        ad = int(ad * ratio)

    return fm, ad


# ─────────────────────────────────────────────────────────────────────────────
# Pipeline state machine
# ─────────────────────────────────────────────────────────────────────────────

class HTTPPipeline:
    """
    Three-phase online pipeline: FM warmup → AD warmup → inference.
    Uses HTTPFeatureMapper and HTTPKitNET instead of Phase 2 classes.

    Parameters
    ----------
    fm_grace         : rows used to fit the HTTPFeatureMapper
    ad_grace         : rows used to train the HTTPKitNET autoencoders
    n_features       : width of the input feature vector
    max_cluster_size : passed to HTTPFeatureMapper (default 5)
    min_clusters     : passed to HTTPFeatureMapper (default 15)
    beta             : AE hidden-layer size ratio
    lr               : SGD learning rate
    """
    """
    def __init__(
        self,
        fm_grace:         int,
        ad_grace:         int,
        n_features:       int,
        max_cluster_size: int   = 5,
        min_clusters:     int   = 15,
        beta:             float = 0.75,
        lr:               float = 0.1,
    ) -> None:
        self.fm_grace = fm_grace
        self.ad_grace = ad_grace

        self.feat_mapper = HTTPFeatureMapper(
            n_features       = n_features,
            max_cluster_size = max_cluster_size,
            min_clusters     = min_clusters,
        )
        self.detector: Optional[HTTPKitNET] = None
        self._mapper_ready = False
        self._rows_seen    = 0
        self.peak_train_score = 0.0
        self._beta = beta
        self._lr   = lr

    @property
    def warmup_length(self) -> int:
        return self.fm_grace + self.ad_grace

    def step(
        self, feature_vec: np.ndarray
    ) -> Tuple[Optional[float], str]:
        idx = self._rows_seen
        self._rows_seen += 1

        # Phase 1 — FM warmup
        if idx < self.fm_grace:
            self.feat_mapper.update(feature_vec)
            return None, "fm_train"

        # Transition: fit FeatureMapper, build HTTPKitNET
        if not self._mapper_ready:
            _log.info("Fitting HTTPFeatureMapper on %d rows …", self.fm_grace)
            self.feat_mapper.fit()
            self.detector = HTTPKitNET(
                cluster_sizes = self.feat_mapper.cluster_sizes,
                beta          = self._beta,
                lr            = self._lr,
            )
            self._mapper_ready = True
            _log.info(
                "HTTPFeatureMapper ready — k=%d clusters  sizes=%s",
                self.feat_mapper.n_clusters,
                self.feat_mapper.cluster_sizes,
            )

        sub_vecs = self.feat_mapper.transform(feature_vec)

        # Phase 2 — AD warmup
        if idx < self.warmup_length:
            score = float(self.detector.train(sub_vecs))
            self.peak_train_score = max(self.peak_train_score, score)
            return None, "ad_train"

        # Phase 3 — inference
        return float(self.detector.execute(sub_vecs)), "exec"


# ─────────────────────────────────────────────────────────────────────────────
# Per-attack-type breakdown
# ─────────────────────────────────────────────────────────────────────────────

def build_attack_breakdown(scored_df: pd.DataFrame) -> pd.DataFrame:
    """Per-attack-type detection at 95th-percentile benign threshold (5 % FPR)."""
    benign_scores = scored_df.loc[scored_df["label"] == 0, "score"]
    threshold = float(np.percentile(benign_scores, 95)) if len(benign_scores) else 0.0

    rows = []
    for atype, grp in scored_df.groupby("attack_type"):
        total    = len(grp)
        detected = int((grp["score"] > threshold).sum())
        rows.append({
            "attack_type":    atype,
            "total_rows":     total,
            "attack_rows":    int(grp["label"].sum()),
            "detected":       detected,
            "missed":         total - detected,
            "detection_rate": round(detected / total, 4) if total else 0.0,
            "threshold_p95":  round(threshold, 6),
        })
    return pd.DataFrame(rows).sort_values("attack_type").reset_index(drop=True)


# ─────────────────────────────────────────────────────────────────────────────
# Single-day evaluation
# ─────────────────────────────────────────────────────────────────────────────

def evaluate_http_csv(
    day_name:         str,
    csv_path:         Path,
    output_dir:       Path,
    max_cluster_size: int   = 5,
    min_clusters:     int   = 15,
    beta:             float = 0.75,
    learn_rate:       float = 0.1,
    log_every:        int   = 50_000,
) -> Dict:
    """
    _log.info("Phase 3  |  Day: %s", day_name)

    STREAM_CHUNK = 100_000
    META_COLS    = {"binary_label", "attack_type", "day", "timestamp", "label_source"}

    # Sniff header
    header_df  = pd.read_csv(csv_path, nrows=0)
    feat_cols  = [c for c in header_df.columns if c not in META_COLS]
    n_feats    = len(feat_cols)
    read_cols  = feat_cols + ["binary_label", "attack_type"]

    _log.info("feature_width=%d", n_feats)

    _log.info("Scanning benign prefix …")
    benign_prefix = 0
    total_rows    = 0
    found_attack  = False
    for chunk in pd.read_csv(csv_path, usecols=["binary_label"],
                              chunksize=STREAM_CHUNK,
                              dtype={"binary_label": "int8"}):
        total_rows += len(chunk)
        if not found_attack:
            for lbl in chunk["binary_label"]:
                if int(lbl) == 1:
                    found_attack = True
                    break
                benign_prefix += 1

    fm_grace, ad_grace = compute_http_warmup(benign_prefix)
    _log.info(
        "benign_prefix=%d  fm_grace=%d  ad_grace=%d  (Phase 3 HTTP-tuned)",
        benign_prefix, fm_grace, ad_grace,
    )

    pipeline = HTTPPipeline(
        fm_grace         = fm_grace,
        ad_grace         = ad_grace,
        n_features       = n_feats,
        max_cluster_size = max_cluster_size,
        min_clusters     = min_clusters,
        beta             = beta,
        lr               = learn_rate,
    )

    phase_counts: Dict[str, int] = {"fm_train": 0, "ad_train": 0, "exec": 0}
    scored_rows:  List[Dict]     = []
    t_start   = time.time()
    glob_idx  = 0
    feat_dtype = {c: "float32" for c in feat_cols}

    for chunk in pd.read_csv(csv_path, usecols=read_cols,
                              chunksize=STREAM_CHUNK, dtype=feat_dtype,
                              low_memory=False):
        feat_chunk  = chunk[feat_cols].fillna(0.0).replace([np.inf, -np.inf], 0.0)
        feat_array  = feat_chunk.values.astype(np.float32)
        label_array = chunk["binary_label"].values.astype(int)
        atype_array = chunk["attack_type"].values

        for i in range(len(chunk)):
            feat_vec    = feat_array[i]
            bin_label   = int(label_array[i])
            attack_type = str(atype_array[i])

            if pipeline._rows_seen < pipeline.warmup_length and bin_label == 1:
                scored_rows.append({
                    "row_index":   glob_idx,
                    "day":         day_name,
                    "label":       bin_label,
                    "score":       0.0,
                    "attack_type": attack_type,
                })
                phase_counts["exec"] += 1
                glob_idx += 1
                continue

            score, phase = pipeline.step(feat_vec)
            phase_counts[phase] += 1

            if phase == "exec":
                scored_rows.append({
                    "row_index":   glob_idx,
                    "day":         day_name,
                    "label":       bin_label,
                    "score":       float(score),
                    "attack_type": attack_type,
                })

            glob_idx += 1

        if glob_idx % log_every < STREAM_CHUNK:
            elapsed = time.time() - t_start
            _log.info(
                "Row %d / %d  (%.0f rows/s)",
                glob_idx, total_rows, glob_idx / max(elapsed, 1),
            )

    elapsed = time.time() - t_start

    if not scored_rows:
        return {"dataset": day_name, "error": "no_eval_rows"}

    scored_df = pd.DataFrame(scored_rows)
    score_arr = scored_df["score"].to_numpy(dtype=np.float64)
    label_arr = scored_df["label"].to_numpy(dtype=np.int32)

    metrics = compute_metrics(
        scores       = score_arr,
        labels       = label_arr,
        dataset_name = day_name,
        runtime_sec  = elapsed,
        extra = {
            "feature_source":    "http_afterimage_85_phase3",
            "n_features":        n_feats,
            "total_rows":        total_rows,
            "fm_grace":          fm_grace,
            "ad_grace":          ad_grace,
            "warmup_rows":       pipeline.warmup_length,
            "max_cluster_size":  max_cluster_size,
            "min_clusters":      min_clusters,
            "n_clusters":        pipeline.feat_mapper.n_clusters,
            "cluster_sizes":     pipeline.feat_mapper.cluster_sizes,
            "peak_train_score":  round(pipeline.peak_train_score, 6),
            "architecture":      "HTTPKitNET_v3",
        },
    )
    print_metrics(metrics)

    # Save artefacts
    target_dir = output_dir / day_name.replace(" ", "_")
    target_dir.mkdir(parents=True, exist_ok=True)

    scored_df.to_csv(target_dir / "scores.csv", index=False)
    roc_df, pr_df = build_curve_frames(scores=score_arr, labels=label_arr)
    roc_df.to_csv(target_dir / "roc_curve.csv", index=False)
    pr_df.to_csv(target_dir / "pr_curve.csv",  index=False)

    with open(target_dir / "metrics.json", "w") as fh:
        json.dump(metrics, fh, indent=2)

    breakdown_df = build_attack_breakdown(scored_df)
    breakdown_df.to_csv(target_dir / "attack_breakdown.csv", index=False)
    _log.info("Attack breakdown:\n%s", breakdown_df.to_string(index=False))

    return metrics


# ─────────────────────────────────────────────────────────────────────────────
# Multi-day runner
# ─────────────────────────────────────────────────────────────────────────────

def run_phase3(
    data_dir:         Path,
    output_dir:       Path,
    csv_suffix:       str   = "http_85",
    max_cluster_size: int   = 5,
    min_clusters:     int   = 15,
    beta:             float = 0.75,
    learn_rate:       float = 0.1,
) -> List[Dict]:
    """

    days = sorted(
        (p.stem.replace(f"_{csv_suffix}", ""), p)
        for p in data_dir.glob(f"*_{csv_suffix}.csv")
    )
    if not days:
        _log.error("No *_%s.csv files found in %s", csv_suffix, data_dir)
        return []

    _log.info("Phase 3 — %d day(s): %s", len(days), [d for d, _ in days])

    all_metrics:    List[Dict]          = []
    all_breakdowns: List[pd.DataFrame]  = []

    for day_name, csv_path in days:
        result = evaluate_http_csv(
            day_name         = day_name,
            csv_path         = csv_path,
            output_dir       = output_dir,
            max_cluster_size = max_cluster_size,
            min_clusters     = min_clusters,
            beta             = beta,
            learn_rate       = learn_rate,
        )
        all_metrics.append(result)

        bd_path = output_dir / day_name / "attack_breakdown.csv"
        if bd_path.exists():
            bd = pd.read_csv(bd_path)
            bd.insert(0, "day", day_name)
            all_breakdowns.append(bd)

    # Summary files
    pd.DataFrame(all_metrics).to_csv(output_dir / "summary_metrics.csv", index=False)
    with open(output_dir / "summary_metrics.json", "w") as fh:
        json.dump(all_metrics, fh, indent=2)

    if all_breakdowns:
        combined = pd.concat(all_breakdowns, ignore_index=True)
        combined.to_csv(output_dir / "attack_breakdown_combined.csv", index=False)

    _log.info("Phase 3 complete → %s", output_dir)
    return all_metrics
