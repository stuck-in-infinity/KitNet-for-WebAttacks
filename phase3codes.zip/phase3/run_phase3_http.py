"""
# ══════════════════════════════════════════════════════════════════════════════
# 0.  Imports
# ══════════════════════════════════════════════════════════════════════════════

from __future__ import annotations

import json
import logging
import sys
import time
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

try:
    from scipy.cluster.hierarchy import fcluster, linkage
    from scipy.spatial.distance import squareform
    from scipy.stats import rankdata
    _SCIPY = True
except ImportError:
    _SCIPY = False

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[logging.StreamHandler(sys.stdout)],
)
_log = logging.getLogger(__name__)

# ══════════════════════════════════════════════════════════════════════════════
# ══════════════════════════════════════════════════════════════════════════════

if not _SCIPY:
    _log.warning("scipy not found — using numpy fallback (results may differ slightly)")

    def squareform(X, checks=False):
        n = X.shape[0]
        out = []
        for i in range(n):
            for j in range(i + 1, n):
                out.append(X[i, j])
        return np.array(out)

    def linkage(condensed, method="complete"):
        n = int(round((1 + np.sqrt(1 + 8 * len(condensed))) / 2))
        D = np.zeros((n, n))
        k = 0
        for i in range(n):
            for j in range(i + 1, n):
                D[i, j] = D[j, i] = condensed[k]; k += 1
        clusters = {i: [i] for i in range(n)}
        Z = []
        active = list(range(n))
        next_id = n
        while len(active) > 1:
            best = np.inf; bi = bj = -1
            for ii in range(len(active)):
                for jj in range(ii + 1, len(active)):
                    ci, cj = active[ii], active[jj]
                    if method == "complete":
                        d = max(D[a][b] for a in clusters[ci] for b in clusters[cj])
                    else:
                        d = min(D[a][b] for a in clusters[ci] for b in clusters[cj])
                    if d < best:
                        best = d; bi = ii; bj = jj
            ci, cj = active[bi], active[bj]
            clusters[next_id] = clusters[ci] + clusters[cj]
            Z.append([ci, cj, best, len(clusters[next_id])])
            active.pop(bj); active.pop(bi); active.append(next_id)
            next_id += 1
        return np.array(Z)

    def fcluster(Z, t, criterion="maxclust"):
        n = len(Z) + 1
        parent = {i: i for i in range(2 * n - 1)}
        def find(x):
            while parent[x] != x: x = parent[x]
            return x
        edges = sorted(enumerate(Z), key=lambda x: x[1][2])
        labels = list(range(n))
        # Simple: cut at t clusters
        union = {i: {i} for i in range(n)}
        for idx, row in enumerate(Z):
            a, b = int(row[0]), int(row[1])
            ra, rb = find(a), find(b)
            if ra != rb:
                union[ra] = union.get(ra, {ra}) | union.get(rb, {rb})
                parent[rb] = ra
        return np.array(labels) + 1


# ══════════════════════════════════════════════════════════════════════════════
# 2.  HTTPFeatureMapper
# ══════════════════════════════════════════════════════════════════════════════

class HTTPFeatureMapper:
    def __init__(self, n_features=85, max_cluster_size=5, min_clusters=15):
        self.n = n_features
        self.max_cluster_size = max_cluster_size
        self.min_clusters = min_clusters
        self._c    = np.zeros(self.n, dtype=np.float64)
        self._c_rs = np.zeros(self.n, dtype=np.float64)
        self._C    = np.zeros((self.n, self.n), dtype=np.float64)
        self._t    = 0
        self.mapping:   list[list[int]] | None = None
        self.is_fitted: bool = False

    def update(self, x):
        self._t += 1
        self._c += x
        mu = self._c / self._t
        r = x - mu
        self._c_rs += r ** 2
        self._C += np.outer(r, r)

    def fit(self):
        D = np.ones((self.n, self.n), dtype=np.float64)
        denom = np.sqrt(np.outer(self._c_rs, self._c_rs))
        nz = denom > 1e-12
        D[nz] = 1.0 - self._C[nz] / denom[nz]
        D = np.clip(D, 0.0, 1.0)
        np.fill_diagonal(D, 0.0)
        D = (D + D.T) / 2.0
        condensed = squareform(D, checks=False)
        Z = linkage(condensed, method="complete")
        self.mapping = self._cut_and_enforce(Z)
        self.is_fitted = True

    def _cut_and_enforce(self, Z):
        labels = fcluster(Z, t=self.max_cluster_size, criterion="maxclust")
        groups = {}
        for feat_idx, cid in enumerate(labels):
            groups.setdefault(int(cid), []).append(feat_idx)
        capped = []
        for grp in groups.values():
            for i in range(0, len(grp), self.max_cluster_size):
                capped.append(grp[i: i + self.max_cluster_size])
        # enforce min_clusters
        while len(capped) < self.min_clusters:
            splittable = [i for i, g in enumerate(capped) if len(g) > 1]
            if not splittable:
                break
            li = max(splittable, key=lambda i: len(capped[i]))
            lg = capped.pop(li)
            mid = len(lg) // 2
            capped.append(lg[:mid])
            capped.append(lg[mid:])
        return capped

    def transform(self, x):
        return [x[idx] for idx in self.mapping]

    @property
    def n_clusters(self):
        return len(self.mapping) if self.is_fitted else 0

    @property
    def cluster_sizes(self):
        return [len(g) for g in self.mapping] if self.is_fitted else []


# ══════════════════════════════════════════════════════════════════════════════
# 3.  HTTPAutoencoder
# ══════════════════════════════════════════════════════════════════════════════

class HTTPAutoencoder:
    def __init__(self, n_visible, n_hidden, lr=0.1, ema_momentum=0.99, leaky_alpha=0.01):
        self.n_visible    = n_visible
        self.n_hidden     = n_hidden
        self.lr           = lr
        self.ema_momentum = ema_momentum
        self.leaky_alpha  = leaky_alpha

        bound = 1.0 / max(n_visible, 1)
        rng   = np.random.default_rng()
        self.W_enc = rng.uniform(-bound, bound, (n_hidden, n_visible)).astype(np.float64)
        self.b_enc = np.zeros(n_hidden,  dtype=np.float64)
        self.W_dec = rng.uniform(-bound, bound, (n_visible, n_hidden)).astype(np.float64)
        self.b_dec = np.zeros(n_visible, dtype=np.float64)

        self._ema_mean = np.zeros(n_visible, dtype=np.float64)
        self._ema_var  = np.ones(n_visible,  dtype=np.float64)
        self._n_seen   = 0

    def _update_ema(self, x):
        self._n_seen += 1
        if self._n_seen == 1:
            self._ema_mean = x.copy()
        else:
            m = self.ema_momentum
            prev = self._ema_mean.copy()
            self._ema_mean = m * self._ema_mean + (1 - m) * x
            self._ema_var  = m * self._ema_var  + (1 - m) * (x - prev) ** 2

    def _normalise(self, x):
        return (x - self._ema_mean) / (np.sqrt(self._ema_var + 1e-8))

    def _leaky_relu(self, z):
        return np.where(z > 0, z, self.leaky_alpha * z)

    def _leaky_relu_grad(self, z):
        return np.where(z > 0, 1.0, self.leaky_alpha)

    @staticmethod
    def _sigmoid(z):
        z = np.clip(z, -500.0, 500.0)
        return np.where(z >= 0, 1.0/(1.0+np.exp(-z)), np.exp(z)/(1.0+np.exp(z)))

    @staticmethod
    def _sigmoid_grad(a):
        return a * (1.0 - a)

    @staticmethod
    def _rmse(a, b):
        return float(np.sqrt(np.mean((a - b) ** 2)))

    def _forward(self, x_norm):
        z_enc  = self.W_enc @ x_norm + self.b_enc
        hidden = self._leaky_relu(z_enc)
        output = self._sigmoid(self.W_dec @ hidden + self.b_dec)
        return z_enc, hidden, output

    def train(self, x):
        self._update_ema(x)
        x_norm = self._normalise(x)
        target = self._sigmoid(x_norm)
        z_enc, hidden, output = self._forward(x_norm)
        err = self._rmse(target, output)
        out_d = np.clip((output - target) * self._sigmoid_grad(output), -1.0, 1.0)
        hid_d = np.clip((self.W_dec.T @ out_d) * self._leaky_relu_grad(z_enc), -1.0, 1.0)
        self.W_dec -= self.lr * np.outer(out_d,  hidden)
        self.b_dec -= self.lr * out_d
        self.W_enc -= self.lr * np.outer(hid_d,  x_norm)
        self.b_enc -= self.lr * hid_d
        return err

    def execute(self, x):
        x_norm = self._normalise(x)
        target = self._sigmoid(x_norm)
        _, _, output = self._forward(x_norm)
        return self._rmse(target, output)


# ══════════════════════════════════════════════════════════════════════════════
# 4.  HTTPKitNET
# ══════════════════════════════════════════════════════════════════════════════

class HTTPKitNET:
    def __init__(self, cluster_sizes, beta=0.75, lr=0.1):
        self.k = len(cluster_sizes)
        self.ensemble = [
            HTTPAutoencoder(sz, max(1, int(np.ceil(beta * sz))), lr)
            for sz in cluster_sizes
        ]
        self.output_layer = HTTPAutoencoder(
            self.k, max(1, int(np.ceil(beta * self.k))), lr
        )
        self.phi = 0.0
        self._rmse_sum = np.zeros(self.k, dtype=np.float64)
        self._rmse_sq  = np.zeros(self.k, dtype=np.float64)
        self._rmse_n   = 0
        self._rmse_mean = np.zeros(self.k, dtype=np.float64)
        self._rmse_std  = np.ones(self.k,  dtype=np.float64)

    def _raw_errors(self, sub_instances, training):
        e = np.zeros(self.k, dtype=np.float64)
        for i, (ae, vi) in enumerate(zip(self.ensemble, sub_instances)):
            e[i] = ae.train(vi) if training else ae.execute(vi)
        return e

    def _update_stats(self, errors):
        self._rmse_n   += 1
        self._rmse_sum += errors
        self._rmse_sq  += errors ** 2
        n = self._rmse_n
        self._rmse_mean = self._rmse_sum / n
        var = np.maximum(self._rmse_sq / n - self._rmse_mean ** 2, 1e-12)
        self._rmse_std  = np.sqrt(var)

    def _normalise_errors(self, errors):
        if self._rmse_n == 0:
            return errors
        return (errors - self._rmse_mean) / (self._rmse_std + 1e-8)

    def train(self, sub_instances):
        errors = self._raw_errors(sub_instances, training=True)
        self._update_stats(errors)
        norm   = self._normalise_errors(errors)
        score  = self.output_layer.train(norm)
        self.phi = max(self.phi, score)
        return score

    def execute(self, sub_instances):
        errors = self._raw_errors(sub_instances, training=False)
        norm   = self._normalise_errors(errors)
        return self.output_layer.execute(norm)


# ══════════════════════════════════════════════════════════════════════════════
# 5.  Warmup policy
# ══════════════════════════════════════════════════════════════════════════════

def compute_http_warmup(benign_prefix):
    fm = min(8_000,  int(0.20 * benign_prefix))
    ad = min(40_000, int(0.75 * benign_prefix))
    if fm + ad > benign_prefix:
        ratio = benign_prefix / (fm + ad)
        fm = int(fm * ratio)
        ad = int(ad * ratio)
    return fm, ad


# ══════════════════════════════════════════════════════════════════════════════
# 6.  Pipeline state machine
# ══════════════════════════════════════════════════════════════════════════════

class HTTPPipeline:
    def __init__(self, fm_grace, ad_grace, n_features,
                 max_cluster_size=5, min_clusters=15, beta=0.75, lr=0.1):
        self.fm_grace = fm_grace
        self.ad_grace = ad_grace
        self.feat_mapper = HTTPFeatureMapper(n_features, max_cluster_size, min_clusters)
        self.detector    = None
        self._ready      = False
        self._rows_seen  = 0
        self.peak_train_score = 0.0
        self._beta = beta; self._lr = lr

    @property
    def warmup_length(self):
        return self.fm_grace + self.ad_grace

    def step(self, feat_vec):
        idx = self._rows_seen; self._rows_seen += 1
        if idx < self.fm_grace:
            self.feat_mapper.update(feat_vec)
            return None, "fm_train"
        if not self._ready:
            _log.info("Fitting HTTPFeatureMapper on %d rows …", self.fm_grace)
            self.feat_mapper.fit()
            self.detector = HTTPKitNET(self.feat_mapper.cluster_sizes, self._beta, self._lr)
            self._ready = True
            _log.info("k=%d clusters  sizes=%s",
                      self.feat_mapper.n_clusters, self.feat_mapper.cluster_sizes)
        sub = self.feat_mapper.transform(feat_vec)
        if idx < self.warmup_length:
            score = float(self.detector.train(sub))
            self.peak_train_score = max(self.peak_train_score, score)
            return None, "ad_train"
        return float(self.detector.execute(sub)), "exec"


# ══════════════════════════════════════════════════════════════════════════════
# ══════════════════════════════════════════════════════════════════════════════

def _sorted_cumulative(scores, labels):
    """
    Sort by score descending; return (sorted_labels, tp_cumsum, fp_cumsum,
    pos, neg, sorted_scores).  All subsequent metric functions share this.
    """
    """
    sorted_labels = labels[order].astype(np.int32)
    sorted_scores = scores[order]
    pos           = int(sorted_labels.sum())
    neg           = len(sorted_labels) - pos
    tp            = np.cumsum(sorted_labels)
    fp            = np.cumsum(1 - sorted_labels)
    return sorted_labels, tp, fp, pos, neg, sorted_scores


def _auc_roc(scores, labels):
    """Trapezoidal AUC-ROC.  O(N log N)."""
    _, tp, fp, pos, neg, _ = _sorted_cumulative(scores, labels)
    if pos == 0 or neg == 0:
        return 0.5
    tpr = np.concatenate([[0.0], tp / pos])
    fpr = np.concatenate([[0.0], fp / neg])
    return float(np.trapz(tpr, fpr))


def _auprc(scores, labels):
    """Area under the precision-recall curve.  O(N log N)."""
    _, tp, fp, pos, _, _ = _sorted_cumulative(scores, labels)
    if pos == 0:
        return 0.0
    prec = tp / (tp + fp)
    rec  = tp / pos
    return float(np.trapz(prec, rec))


def _eer(scores, labels):
    """Equal error rate.  O(N log N)."""
    _, tp, fp, pos, neg, _ = _sorted_cumulative(scores, labels)
    if pos == 0 or neg == 0:
        return 0.5
    fnr  = 1.0 - tp / pos
    fpr  = fp / neg
    idx  = int(np.argmin(np.abs(fnr - fpr)))
    return float((fnr[idx] + fpr[idx]) / 2.0)


def _optimal_f1(scores, labels):
    """
    Optimal F1 over all thresholds.  O(N log N) — fully vectorised.
    Previously O(N²) with a Python threshold loop, which hangs on 1M rows.
    """
    """
    if pos == 0:
        return 0.0, 0.0, 0.0, 0, 0, pos, neg

    fn   = pos - tp
    tn   = neg - fp
    prec = np.where((tp + fp) > 0, tp / (tp + fp), 0.0)
    rec  = np.where(pos > 0,       tp / pos,        0.0)
    denom = prec + rec
    f1   = np.where(denom > 0, 2.0 * prec * rec / denom, 0.0)

    idx = int(np.argmax(f1))
    return (float(f1[idx]), float(prec[idx]), float(rec[idx]),
            int(tp[idx]), int(fp[idx]), int(fn[idx]), int(tn[idx]))


def compute_metrics_local(scores, labels, day_name, runtime_sec, extra):
    auc   = _auc_roc(scores, labels)
    auprc = _auprc(scores, labels)
    eer   = _eer(scores, labels)
    f1, prec, rec, tp, fp, fn, tn = _optimal_f1(scores, labels)
    ben = scores[labels == 0]; att = scores[labels == 1]
    m = {
        "dataset": day_name, "AUC": round(auc, 6), "AUPRC": round(auprc, 6),
        "EER": round(eer, 6), "F1_optimal": round(f1, 6),
        "Recall_opt": round(rec, 6), "Precision_opt": round(prec, 6),
        "TP": tp, "FP": fp, "FN": fn, "TN": tn,
        "n_total": len(labels), "n_benign": int((labels==0).sum()),
        "n_malicious": int((labels==1).sum()),
        "attack_rate": round(float((labels==1).mean()), 6),
        "mean_score_benign": round(float(ben.mean()) if len(ben) else 0.0, 6),
        "mean_score_attack": round(float(att.mean()) if len(att) else 0.0, 6),
        "runtime_sec": round(runtime_sec, 2),
    }
    m.update(extra)
    return m


def build_curve_frames_local(scores, labels):
    """Build ROC and PR curve DataFrames.  O(N log N), no Python loops."""
    _, tp, fp, pos, neg, sc_s = _sorted_cumulative(scores, labels)
    tpr  = tp / pos  if pos else np.zeros_like(tp, dtype=np.float64)
    fpr  = fp / neg  if neg else np.zeros_like(fp, dtype=np.float64)
    prec = np.where((tp + fp) > 0, tp / (tp + fp), 0.0)
    rec  = tp / pos  if pos else np.zeros_like(tp, dtype=np.float64)
    roc_df = pd.DataFrame({"fpr": fpr, "tpr": tpr, "threshold": sc_s})
    pr_df  = pd.DataFrame({"precision": prec, "recall": rec, "threshold": sc_s})
    return roc_df, pr_df


# ══════════════════════════════════════════════════════════════════════════════
# 8.  Attack breakdown
# ══════════════════════════════════════════════════════════════════════════════

def build_attack_breakdown(scored_df):
    benign_scores = scored_df.loc[scored_df["label"] == 0, "score"]
    threshold = float(np.percentile(benign_scores, 95)) if len(benign_scores) else 0.0
    rows = []
    for atype, grp in scored_df.groupby("attack_type"):
        total    = len(grp)
        detected = int((grp["score"] > threshold).sum())
        rows.append({
            "attack_type": atype, "total_rows": total,
            "attack_rows": int(grp["label"].sum()),
            "detected": detected, "missed": total - detected,
            "detection_rate": round(detected / total, 4) if total else 0.0,
            "threshold_p95": round(threshold, 6),
        })
    return pd.DataFrame(rows).sort_values("attack_type").reset_index(drop=True)


# ══════════════════════════════════════════════════════════════════════════════
# 9.  Single-day evaluation
# ══════════════════════════════════════════════════════════════════════════════

def evaluate_day(day_name, csv_path, output_dir,
                 max_cluster_size=5, min_clusters=15, beta=0.75, lr=0.1):
    _log.info("=" * 70)
    _log.info("Phase 3  |  Day: %s", day_name)

    CHUNK     = 100_000
    META_COLS = {"binary_label", "attack_type", "day", "timestamp", "label_source"}

    hdr       = pd.read_csv(csv_path, nrows=0)
    feat_cols = [c for c in hdr.columns if c not in META_COLS]
    n_feats   = len(feat_cols)
    read_cols = feat_cols + ["binary_label", "attack_type"]
    _log.info("feature_width=%d", n_feats)

    # Pass 1 — benign prefix scan
    benign_prefix = 0; total_rows = 0; found_attack = False
    for chunk in pd.read_csv(csv_path, usecols=["binary_label"],
                              chunksize=CHUNK, dtype={"binary_label": "int8"}):
        total_rows += len(chunk)
        if not found_attack:
            for lbl in chunk["binary_label"]:
                if int(lbl) == 1: found_attack = True; break
                benign_prefix += 1

    fm_grace, ad_grace = compute_http_warmup(benign_prefix)
    _log.info("benign_prefix=%d  fm=%d  ad=%d", benign_prefix, fm_grace, ad_grace)

    pipeline = HTTPPipeline(fm_grace, ad_grace, n_feats,
                            max_cluster_size, min_clusters, beta, lr)

    scored_rows: list[dict] = []
    t0 = time.time(); glob_idx = 0
    feat_dtype = {c: "float32" for c in feat_cols}

    # Pass 2 — stream through pipeline
    for chunk in pd.read_csv(csv_path, usecols=read_cols, chunksize=CHUNK,
                              dtype=feat_dtype, low_memory=False):
        fa = chunk[feat_cols].fillna(0.0).replace([np.inf, -np.inf], 0.0).values.astype(np.float32)
        la = chunk["binary_label"].values.astype(int)
        aa = chunk["attack_type"].values

        for i in range(len(chunk)):
            fv = fa[i]; bl = int(la[i]); at = str(aa[i])
            if pipeline._rows_seen < pipeline.warmup_length and bl == 1:
                scored_rows.append({"row_index": glob_idx, "day": day_name,
                                    "label": bl, "score": 0.0, "attack_type": at})
                glob_idx += 1; continue
            score, phase = pipeline.step(fv)
            if phase == "exec":
                scored_rows.append({"row_index": glob_idx, "day": day_name,
                                    "label": bl, "score": float(score), "attack_type": at})
            glob_idx += 1

        if glob_idx % 200_000 < CHUNK:
            _log.info("Row %d / %d  %.0f r/s", glob_idx, total_rows,
                      glob_idx / max(time.time()-t0, 1))

    elapsed = time.time() - t0
    if not scored_rows:
        return {"dataset": day_name, "error": "no_eval_rows"}

    scored_df = pd.DataFrame(scored_rows)
    scores = scored_df["score"].to_numpy(np.float64)
    labels = scored_df["label"].to_numpy(np.int32)

    metrics = compute_metrics_local(scores, labels, day_name, elapsed, {
        "feature_source":   "http_afterimage_85_phase3",
        "n_features":       n_feats, "total_rows": total_rows,
        "fm_grace":         fm_grace, "ad_grace": ad_grace,
        "warmup_rows":      pipeline.warmup_length,
        "max_cluster_size": max_cluster_size, "min_clusters": min_clusters,
        "n_clusters":       pipeline.feat_mapper.n_clusters,
        "cluster_sizes":    pipeline.feat_mapper.cluster_sizes,
        "peak_train_score": round(pipeline.peak_train_score, 6),
        "architecture":     "HTTPKitNET_phase3",
    })

    _log.info("[%s] AUC=%.4f  AUPRC=%.4f  EER=%.4f  F1=%.4f",
              day_name, metrics["AUC"], metrics["AUPRC"],
              metrics["EER"], metrics["F1_optimal"])

    out = output_dir / day_name
    out.mkdir(parents=True, exist_ok=True)
    scored_df.to_csv(out / "scores.csv", index=False)
    roc_df, pr_df = build_curve_frames_local(scores, labels)
    roc_df.to_csv(out / "roc_curve.csv", index=False)
    pr_df.to_csv(out / "pr_curve.csv",  index=False)
    with open(out / "metrics.json", "w") as f:
        json.dump(metrics, f, indent=2)
    bd = build_attack_breakdown(scored_df)
    bd.to_csv(out / "attack_breakdown.csv", index=False)
    _log.info("Attack breakdown:\n%s", bd.to_string(index=False))
    return metrics


# ══════════════════════════════════════════════════════════════════════════════
# ══════════════════════════════════════════════════════════════════════════════

def build_comparison(phase2_results_dir: Path, phase3_results_dir: Path) -> pd.DataFrame:
    """
    Load Phase 2 HTTP-only metrics.json files and Phase 3 metrics.json files,
    side-by-side comparison of key metrics per day.
    """
    """
    for day in ["thursday", "friday"]:
        p2_path = phase2_results_dir / "http_only" / day / "metrics.json"
        p3_path = phase3_results_dir / day / "metrics.json"

        p2 = json.loads(p2_path.read_text()) if p2_path.exists() else {}
        p3 = json.loads(p3_path.read_text()) if p3_path.exists() else {}

        for key in ["AUC", "AUPRC", "EER", "F1_optimal"]:
            rows.append({
                "day":    day,
                "metric": key,
                "phase2_http_only": round(p2.get(key, float("nan")), 4),
                "phase3_http_tuned": round(p3.get(key, float("nan")), 4),
                "delta": round(
                    p3.get(key, float("nan")) - p2.get(key, float("nan")), 4
                ),
            })

        # Detection rates
        for bd_day_name, bd_dir in [("phase2", p2_path.parent), ("phase3", p3_path.parent)]:
            bd_file = bd_dir / "attack_breakdown.csv"
            if bd_file.exists():
                bd = pd.read_csv(bd_file)
                for _, r in bd.iterrows():
                    if r["attack_type"] == "Benign":
                        continue
                    rows.append({
                        "day":    day,
                        "metric": f"DetRate_{r['attack_type']}",
                        "phase2_http_only":  round(bd.loc[bd["attack_type"]==r["attack_type"],
                                                    "detection_rate"].values[0], 4)
                                             if bd_day_name == "phase2" else float("nan"),
                        "phase3_http_tuned": round(r["detection_rate"], 4)
                                             if bd_day_name == "phase3" else float("nan"),
                        "delta": float("nan"),
                    })

    return pd.DataFrame(rows)


# ══════════════════════════════════════════════════════════════════════════════
# 11.  Main
# ══════════════════════════════════════════════════════════════════════════════

def main():
    # ── Paths ─────────────────────────────────────────────────────────────────
    COMBINED_DIR   = Path("/kaggle/input/kitnet-phase2-data/combined")
    PHASE3_OUT     = Path("/kaggle/working/results_phase3")
    PHASE2_OUT     = Path("/kaggle/input/kitnet-phase2-data/results_phase2/full")

    # Fallback: try common alternative paths
    if not COMBINED_DIR.exists():
        candidates = list(Path("/kaggle/input").glob("*/combined"))
        if candidates:
            COMBINED_DIR = candidates[0]
            _log.info("Auto-detected COMBINED_DIR: %s", COMBINED_DIR)
        else:
            _log.error("Cannot find combined/ directory. Set COMBINED_DIR manually.")
            sys.exit(1)

    PHASE3_OUT.mkdir(parents=True, exist_ok=True)

    # ── Discover HTTP-85 CSVs ─────────────────────────────────────────────────
    http_csvs = sorted(COMBINED_DIR.glob("*_http_85.csv"))
    if not http_csvs:
        _log.error("No *_http_85.csv files in %s", COMBINED_DIR)
        sys.exit(1)

    _log.info("Found %d HTTP-85 CSV(s): %s", len(http_csvs), [p.name for p in http_csvs])

    # ── Run Phase 3 ───────────────────────────────────────────────────────────
    all_metrics = []
    for csv_path in http_csvs:
        day_name = csv_path.stem.replace("_http_85", "")
        result   = evaluate_day(
            day_name         = day_name,
            csv_path         = csv_path,
            output_dir       = PHASE3_OUT,
            max_cluster_size = 5,
            min_clusters     = 15,
            beta             = 0.75,
            lr               = 0.1,
        )
        all_metrics.append(result)

    # ── Summary ───────────────────────────────────────────────────────────────
    summary_df = pd.DataFrame(all_metrics)
    summary_df.to_csv(PHASE3_OUT / "summary_metrics.csv", index=False)
    with open(PHASE3_OUT / "summary_metrics.json", "w") as f:
        json.dump(all_metrics, f, indent=2)

    # Combine attack breakdowns
    bds = []
    for csv_path in http_csvs:
        day_name = csv_path.stem.replace("_http_85", "")
        bd_file  = PHASE3_OUT / day_name / "attack_breakdown.csv"
        if bd_file.exists():
            bd = pd.read_csv(bd_file); bd.insert(0, "day", day_name)
            bds.append(bd)
    if bds:
        pd.concat(bds).to_csv(PHASE3_OUT / "attack_breakdown_combined.csv", index=False)

    # Phase 2 vs Phase 3 comparison
    if PHASE2_OUT.exists():
        try:
            comp_df = build_comparison(PHASE2_OUT, PHASE3_OUT)
            comp_df.to_csv(PHASE3_OUT / "phase2_vs_phase3_comparison.csv", index=False)
            _log.info("\nPhase 2 vs Phase 3 comparison:\n%s", comp_df.to_string(index=False))
        except Exception as exc:
            _log.warning("Comparison table failed (non-fatal): %s", exc)

    _log.info("\n" + "=" * 70)
    _log.info("Phase 3 complete.  Results in: %s", PHASE3_OUT)
    _log.info("Summary:")
    for m in all_metrics:
        _log.info(
            "  [%s]  AUC=%.4f  AUPRC=%.4f  EER=%.4f  F1=%.4f  k=%s",
            m.get("dataset", "?"), m.get("AUC", 0), m.get("AUPRC", 0),
            m.get("EER", 0), m.get("F1_optimal", 0), m.get("n_clusters", "?"),
        )


if __name__ == "__main__":
    main()
